// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2016 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace gdbserver {
    
    using conversion = utility.conversion;
    
    using logging;
    
    using System.Collections.Generic;
    
    public static class context_facade {
        
        public static object FAULT = new List<object> {
            signals.SIGSTOP,
            signals.SIGSTOP,
            signals.SIGINT,
            signals.SIGSEGV,
            signals.SIGSEGV,
            signals.SIGBUS,
            signals.SIGILL
        };
        
        public class GDBDebugContextFacade
            : object {
            
            public GDBDebugContextFacade(object context) {
                this._context = context;
                this._register_list = this._context.core.register_list;
            }
            
            public object context {
                get {
                    return this._context;
                }
            }
            
            public virtual object set_context(object newContext) {
                this._context = newContext;
            }
            
            // 
            //         return hexadecimal dump of registers as expected by GDB
            //         
            public virtual object getRegisterContext() {
                logging.debug("GDB getting register context");
                var resp = "";
                var reg_num_list = map(reg => reg.reg_num, this._register_list);
                var vals = this._context.readCoreRegistersRaw(reg_num_list);
                //print("Vals: %s" % vals)
                foreach (var _tup_1 in zip(this._register_list, vals)) {
                    var reg = _tup_1.Item1;
                    var regValue = _tup_1.Item2;
                    resp += conversion.u32beToHex8le(regValue);
                    logging.debug("GDB reg: %s = 0x%X", reg.name, regValue);
                }
                return resp;
            }
            
            // 
            //         Set registers from GDB hexadecimal string.
            //         
            public virtual object setRegisterContext(object data) {
                logging.debug("GDB setting register context");
                var reg_num_list = new List<object>();
                var reg_data_list = new List<object>();
                foreach (var reg in this._register_list) {
                    var regValue = conversion.hex8leToU32be(data);
                    reg_num_list.append(reg.reg_num);
                    reg_data_list.append(regValue);
                    logging.debug("GDB reg: %s = 0x%X", reg.name, regValue);
                    data = data[8];
                }
                this._context.writeCoreRegistersRaw(reg_num_list, reg_data_list);
            }
            
            // 
            //         Set single register from GDB hexadecimal string.
            //         reg parameter is the index of register in targetXML sent to GDB.
            //         
            public virtual object setRegister(object reg, object data) {
                if (reg < 0) {
                    return;
                } else if (reg < this._register_list.Count) {
                    var regName = this._register_list[reg].name;
                    var value = conversion.hex8leToU32be(data);
                    logging.debug("GDB: write reg %s: 0x%X", regName, value);
                    this._context.writeCoreRegisterRaw(regName, value);
                }
            }
            
            public virtual object gdbGetRegister(object reg) {
                var resp = "";
                if (reg < this._register_list.Count) {
                    var regName = this._register_list[reg].name;
                    var regValue = this._context.readCoreRegisterRaw(regName);
                    resp = conversion.u32beToHex8le(regValue);
                    logging.debug("GDB reg: %s = 0x%X", regName, regValue);
                }
                return resp;
            }
            
            // 
            //         Returns a GDB T response string.  This includes:
            //             The signal encountered.
            //             The current value of the important registers (sp, lr, pc).
            //         
            public virtual object getTResponse(object forceSignal = null) {
                object response;
                if (forceSignal != null) {
                    response = "T" + conversion.byteToHex2(forceSignal);
                } else {
                    response = "T" + conversion.byteToHex2(this.getSignalValue());
                }
                // Append fp(r7), sp(r13), lr(r14), pc(r15)
                response += this.getRegIndexValuePairs(new List<object> {
                    7,
                    13,
                    14,
                    15
                });
                return response;
            }
            
            public virtual object getSignalValue() {
                object signal;
                if (this._context.core.isDebugTrap()) {
                    return signals.SIGTRAP;
                }
                var fault = this._context.readCoreRegister("xpsr") & 255;
                try {
                    signal = FAULT[fault];
                } catch {
                    // If not a fault then default to SIGSTOP
                    signal = signals.SIGSTOP;
                }
                logging.debug("GDB lastSignal: %d", signal);
                return signal;
            }
            
            // 
            //         Returns a string like NN:MMMMMMMM;NN:MMMMMMMM;...
            //             for the T response string.  NN is the index of the
            //             register to follow MMMMMMMM is the value of the register.
            //         
            public virtual object getRegIndexValuePairs(object regIndexList) {
                var str = "";
                var regList = this._context.readCoreRegistersRaw(regIndexList);
                foreach (var _tup_1 in zip(regIndexList, regList)) {
                    var regIndex = _tup_1.Item1;
                    var reg = _tup_1.Item2;
                    str += conversion.byteToHex2(regIndex) + ":" + conversion.u32beToHex8le(reg) + ";";
                }
                return str;
            }
            
            public virtual object getMemoryMapXML() {
                if (this._context.core.memory_map) {
                    return this._context.core.memory_map.getXML();
                } else {
                    return null;
                }
            }
        }
    }
}
