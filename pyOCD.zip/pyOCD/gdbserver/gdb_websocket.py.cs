// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace gdbserver {
    
    using create_connection = websocket.create_connection;
    
    public static class gdb_websocket {
        
        public class GDBWebSocket
            : object {
            
            public GDBWebSocket(object url) {
                this.url = url;
                this.wss = null;
                return;
            }
            
            public virtual object connect() {
                this.wss = null;
                try {
                    this.wss = create_connection(this.url);
                } catch {
                }
                return this.wss;
            }
            
            public virtual object read() {
                return this.wss.recv();
            }
            
            public virtual object write(object data) {
                return this.wss.send(data);
            }
            
            public virtual object close() {
                return this.wss.close();
            }
            
            public virtual object setBlocking(object blocking) {
                if (blocking != 0) {
                    this.wss.settimeout(null);
                } else {
                    this.wss.settimeout(0);
                }
            }
            
            public virtual object setTimeout(object timeout) {
                this.wss.settimeout(timeout);
            }
        }
    }
}
