// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace gdbserver {
    
    using os;
    
    using logging;
    
    using SemihostIOHandler = debug.semihost.SemihostIOHandler;
    
    using System;
    
    public static class syscall {
        
        public static object O_RDONLY = 0;
        
        public static object O_WRONLY = 1;
        
        public static object O_RDWR = 2;
        
        public static object O_APPEND = 8;
        
        public static object O_CREAT = 512;
        
        public static object O_TRUNC = 1024;
        
        public static object O_EXCL = 2048;
        
        public static object FD_OFFSET = 4;
        
        public class GDBSyscallIOHandler
            : SemihostIOHandler {
            
            public GDBSyscallIOHandler(object server) {
                this._server = server;
            }
            
            public virtual object open(object fnptr, object fnlen, object mode) {
                // Handle standard I/O.
                var _tup_1 = this._std_open(fnptr, fnlen, mode);
                var fd = _tup_1.Item1;
                if (fd != null) {
                    return fd;
                }
                // Convert mode string to flags.
                var modeval = 0;
                var hasplus = mode.Contains("+");
                if (mode.Contains("r")) {
                    if (hasplus) {
                        modeval |= O_RDWR;
                    } else {
                        modeval |= O_RDONLY;
                    }
                } else if (mode.Contains("w")) {
                    if (hasplus) {
                        modeval |= O_RDWR | O_CREAT | O_TRUNC;
                    } else {
                        modeval |= O_WRONLY | O_CREAT | O_TRUNC;
                    }
                } else if (mode.Contains("a")) {
                    if (hasplus) {
                        modeval |= O_RDWR | O_APPEND | O_CREAT;
                    } else {
                        modeval |= O_WRONLY | O_APPEND | O_CREAT;
                    }
                }
                var _tup_2 = this._server.syscall(String.Format("open,%x/%x,%x,%x", fnptr, fnlen + 1, modeval, 777));
                var result = _tup_2.Item1;
                this._errno = _tup_2.Item2;
                if (result != -1) {
                    result += FD_OFFSET;
                }
                return result;
            }
            
            public virtual object close(object fd) {
                fd -= FD_OFFSET;
                var _tup_1 = this._server.syscall(String.Format("close,%x", fd));
                var result = _tup_1.Item1;
                this._errno = _tup_1.Item2;
                return result;
            }
            
            // syscall return: number of bytes written
            // semihost return: 0 is success, or number of bytes not written
            public virtual object write(object fd, object ptr, object length) {
                fd -= FD_OFFSET;
                var _tup_1 = this._server.syscall(String.Format("write,%x,%x,%x", fd, ptr, length));
                var result = _tup_1.Item1;
                this._errno = _tup_1.Item2;
                return length - result;
            }
            
            // syscall return: number of bytes read
            // semihost return: 0 is success, length is EOF, number of bytes not read
            public virtual object read(object fd, object ptr, object length) {
                fd -= FD_OFFSET;
                var _tup_1 = this._server.syscall(String.Format("read,%x,%x,%x", fd, ptr, length));
                var result = _tup_1.Item1;
                this._errno = _tup_1.Item2;
                return length - result;
            }
            
            public virtual object readc() {
                var ptr = this.agent.target.readCoreRegister("sp") - 4;
                var _tup_1 = this._server.syscall(String.Format("read,0,%x,1", ptr));
                var result = _tup_1.Item1;
                this._errno = _tup_1.Item2;
                if (result != -1) {
                    result = this.agent.target.read8(ptr);
                }
                return result;
            }
            
            public virtual object istty(object fd) {
                fd -= FD_OFFSET;
                var _tup_1 = this._server.syscall(String.Format("isatty,%x", fd));
                var result = _tup_1.Item1;
                this._errno = _tup_1.Item2;
                return result;
            }
            
            public virtual object seek(object fd, object pos) {
                fd -= FD_OFFSET;
                var _tup_1 = this._server.syscall(String.Format("lseek,%x,%x,0", fd, pos));
                var result = _tup_1.Item1;
                this._errno = _tup_1.Item2;
                return result != -1 ? 0 : -1;
            }
            
            public virtual object flen(object fd) {
                fd -= FD_OFFSET;
                var ptr = this.agent.target.readCoreRegister("sp") - 64;
                var _tup_1 = this._server.syscall(String.Format("fstat,%x,%x", fd, ptr));
                var result = _tup_1.Item1;
                this._errno = _tup_1.Item2;
                if (result != -1) {
                    // Fields in stat struct are big endian as written by gdb.
                    var size = this.agent.target.readBlockMemoryUnaligned8(ptr, 8);
                    result = size[0] << 56 | size[1] << 48 | size[2] << 40 | size[3] << 32 | size[4] << 24 | size[5] << 16 | size[6] << 8 | size[7];
                }
                return result;
            }
        }
    }
}
