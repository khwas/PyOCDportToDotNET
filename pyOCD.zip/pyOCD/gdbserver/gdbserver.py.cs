// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace gdbserver {
    
    using Target = core.target.Target;
    
    using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    
    using convert_vector_catch = utility.cmdline.convert_vector_catch;
    
    using hexToByteList = utility.conversion.hexToByteList;
    
    using hexEncode = utility.conversion.hexEncode;
    
    using hexDecode = utility.conversion.hexDecode;
    
    using hex8leToU32le = utility.conversion.hex8leToU32le;
    
    using GDBSocket = gdb_socket.GDBSocket;
    
    using GDBWebSocket = gdb_websocket.GDBWebSocket;
    
    using GDBSyscallIOHandler = syscall.GDBSyscallIOHandler;
    
    using semihost = debug.semihost;
    
    using MemoryAccessError = debug.cache.MemoryAccessError;
    
    using GDBDebugContextFacade = context_facade.GDBDebugContextFacade;
    
    using GDBSymbolProvider = symbols.GDBSymbolProvider;
    
    using RTOS = rtos.RTOS;
    
    using signals;
    
    using logging;
    
    using threading;
    
    using socket;
    
    using unpack = @struct.unpack;
    
    using sleep = time.sleep;
    
    using time = time.time;
    
    using sys;
    
    using traceback;
    
    using Queue;
    
    using Element = xml.etree.ElementTree.Element;
    
    using SubElement = xml.etree.ElementTree.SubElement;
    
    using tostring = xml.etree.ElementTree.tostring;
    
    using System.Linq;
    
    using System;
    
    using System.Collections.Generic;
    
    using System.Diagnostics;
    
    public static class gdbserver {
        
        public static object CTRL_C = "\x03";
        
        public static object LOG_MEM = false;
        
        public static object LOG_ACK = false;
        
        public static object LOG_PACKETS = false;
        
        public static object checksum(object data) {
            return String.Format("%02x", data.Select(c => ord(c)).Sum() % 256);
        }
        
        public class ConnectionClosedException
            : Exception {
        }
        
        public class GDBServerPacketIOThread
            : threading.Thread {
            
            public GDBServerPacketIOThread(object abstract_socket) {
                this.log = logging.getLogger(String.Format("gdbpacket.%d", abstract_socket.port));
                this._abstract_socket = abstract_socket;
                this._receive_queue = Queue.Queue();
                this._shutdown_event = threading.Event();
                this.interrupt_event = threading.Event();
                this.send_acks = true;
                this._clear_send_acks = false;
                this._buffer = "";
                this._expecting_ack = false;
                this.drop_reply = false;
                this._last_packet = "";
                this._closed = false;
                this.setDaemon(true);
                this.start();
            }
            
            public virtual object set_send_acks(object ack) {
                if (ack) {
                    this.send_acks = true;
                } else {
                    this._clear_send_acks = true;
                }
            }
            
            public virtual object stop() {
                this._shutdown_event.set();
            }
            
            public virtual object send(object packet) {
                if (this._closed || !packet) {
                    return;
                }
                if (!this.drop_reply) {
                    this._last_packet = packet;
                    this._write_packet(packet);
                } else {
                    this.drop_reply = false;
                    this.log.debug("GDB dropped reply %s", packet);
                }
            }
            
            public virtual object receive(object block = true) {
                if (this._closed) {
                    throw ConnectionClosedException();
                }
                while (true) {
                    try {
                        // If block is false, we'll get an Empty exception immediately if there
                        // are no packets in the queue. Same if block is true and it times out
                        // waiting on an empty queue.
                        return this._receive_queue.get(block, 0.1);
                    } catch {
                        // Only exit the loop if block is false or connection closed.
                        if (!block) {
                            return null;
                        }
                        if (this._closed) {
                            throw ConnectionClosedException();
                        }
                    }
                }
            }
            
            public virtual object run() {
                this._abstract_socket.setTimeout(0.01);
                while (!this._shutdown_event.is_set()) {
                    try {
                        var data = this._abstract_socket.read();
                        // Handle closed connection
                        if (data.Count == 0) {
                            this.log.debug("GDB packet thread: other side closed connection");
                            this._closed = true;
                            break;
                        }
                        if (LOG_PACKETS) {
                            this.log.debug("-->>>>>>>>>>>> GDB read %d bytes: %s", data.Count, data);
                        }
                        this._buffer += data;
                    } catch {
                    }
                    if (this._shutdown_event.is_set()) {
                        break;
                    }
                    this._process_data();
                }
                this.log.debug("GDB packet thread stopping");
            }
            
            public virtual object _write_packet(object packet) {
                if (LOG_PACKETS) {
                    this.log.debug("--<<<<<<<<<<<< GDB send %d bytes: %s", packet.Count, packet);
                }
                // Make sure the entire packet is sent.
                var remaining = packet.Count;
                while (remaining) {
                    var written = this._abstract_socket.write(packet);
                    remaining -= written;
                    if (remaining) {
                        packet = packet[written];
                    }
                }
                if (this.send_acks) {
                    this._expecting_ack = true;
                }
            }
            
            public virtual object _check_expected_ack() {
                // Handle expected ack.
                var c = this._buffer[0];
                if (Tuple.Create("+", "-").Contains(c)) {
                    this._buffer = this._buffer[1];
                    if (LOG_ACK) {
                        this.log.debug("got ack: %s", c);
                    }
                    if (c == "-") {
                        // Handle nack from gdb
                        this._write_packet(this._last_packet);
                        return;
                    }
                    // Handle disabling of acks.
                    if (this._clear_send_acks) {
                        this.send_acks = false;
                        this._clear_send_acks = false;
                    }
                } else {
                    this.log.debug("GDB: expected n/ack but got '%s'", c);
                }
            }
            
            public virtual object _process_data() {
                // Process all incoming data until there are no more complete packets.
                while (this._buffer.Count) {
                    if (this._expecting_ack) {
                        this._expecting_ack = false;
                        this._check_expected_ack();
                    }
                    // Check for a ctrl-c.
                    if (this._buffer.Count && this._buffer[0] == CTRL_C) {
                        this.interrupt_event.set();
                        this._buffer = this._buffer[1];
                    }
                    try {
                        // Look for complete packet and extract from buffer.
                        var pkt_begin = this._buffer.index("$");
                        var pkt_end = this._buffer.index("#") + 2;
                        if (pkt_begin >= 0 && pkt_end < this._buffer.Count) {
                            var pkt = this._buffer[pkt_begin::(pkt_end  +  1)];
                            this._buffer = this._buffer[pkt_end + 1];
                            this._handling_incoming_packet(pkt);
                        } else {
                            break;
                        }
                    } catch (ValueError) {
                        // No complete packet received yet.
                        break;
                    }
                }
            }
            
            public virtual object _handling_incoming_packet(object packet) {
                // Compute checksum
                var _tup_1 = packet[1].split("#");
                var data = _tup_1.Item1;
                var cksum = _tup_1.Item2;
                var computedCksum = checksum(data);
                var goodPacket = computedCksum.lower() == cksum.lower();
                if (this.send_acks) {
                    var ack = goodPacket ? "+" : "-";
                    this._abstract_socket.write(ack);
                    if (LOG_ACK) {
                        this.log.debug(ack);
                    }
                }
                if (goodPacket) {
                    this._receive_queue.put(packet);
                }
            }
        }
        
        // 
        //     This class start a GDB server listening a gdb connection on a specific port.
        //     It implements the RSP (Remote Serial Protocol).
        //     
        public class GDBServer
            : threading.Thread {
            
            public GDBServer(object board, object port_urlWSS, object options = new Dictionary<object, object> {
            }) {
                object semihost_io_handler;
                this.board = board;
                this.target = board.target;
                this.log = logging.getLogger("gdbserver");
                this.flash = board.flash;
                this.abstract_socket = null;
                this.wss_server = null;
                this.port = 0;
                if (port_urlWSS is str == true) {
                    this.wss_server = port_urlWSS;
                } else {
                    this.port = port_urlWSS;
                }
                this.vector_catch = options.get("vector_catch", Target.CATCH_HARD_FAULT);
                this.board.target.setVectorCatch(this.vector_catch);
                this.step_into_interrupt = options.get("step_into_interrupt", false);
                this.persist = options.get("persist", false);
                this.soft_bkpt_as_hard = options.get("soft_bkpt_as_hard", false);
                this.chip_erase = options.get("chip_erase", null);
                this.hide_programming_progress = options.get("hide_programming_progress", false);
                this.fast_program = options.get("fast_program", false);
                this.enable_semihosting = options.get("enable_semihosting", false);
                this.telnet_port = options.get("telnet_port", 4444);
                this.semihost_use_syscalls = options.get("semihost_use_syscalls", false);
                this.server_listening_callback = options.get("server_listening_callback", null);
                this.serve_local_only = options.get("serve_local_only", true);
                this.packet_size = 2048;
                this.packet_io = null;
                this.gdb_features = new List<object>();
                this.non_stop = false;
                this.is_target_running = this.target.getState() == Target.TARGET_RUNNING;
                this.flashBuilder = null;
                this.lock = threading.Lock();
                this.shutdown_event = threading.Event();
                this.detach_event = threading.Event();
                this.target_context = this.target.getTargetContext();
                this.target_facade = GDBDebugContextFacade(this.target_context);
                this.thread_provider = null;
                this.did_init_thread_providers = false;
                this.current_thread_id = 0;
                if (this.wss_server == null) {
                    this.abstract_socket = GDBSocket(this.port, this.packet_size);
                    if (this.serve_local_only) {
                        this.abstract_socket.host = "localhost";
                    }
                } else {
                    this.abstract_socket = GDBWebSocket(this.wss_server);
                }
                // Init semihosting and telnet console.
                if (this.semihost_use_syscalls) {
                    semihost_io_handler = GDBSyscallIOHandler(this);
                } else {
                    // Use internal IO handler.
                    semihost_io_handler = semihost.InternalSemihostIOHandler();
                }
                this.telnet_console = semihost.TelnetSemihostIOHandler(this.telnet_port, this.serve_local_only);
                this.semihost = semihost.SemihostAgent(this.target_context, io_handler: semihost_io_handler, console: this.telnet_console);
                // Command handler table.
                //
                // The dict keys are the first character of the incoming command from gdb. Values are a
                // bi-tuple. The first element is the handler method, and the second element is the start
                // offset of the command string passed to the handler.
                //
                // Start offset values:
                //  0 - Special case: handler method does not take any parameters.
                //  1 - Strip off leading "$" from command.
                //  2 - Strip leading "$" plus character matched through this table.
                //  3+ - Supported, but not very useful.
                //
                this.COMMANDS = new Dictionary<object, object> {
                    {
                        "?",
                        Tuple.Create(this.stopReasonQuery, 0)},
                    {
                        "C",
                        Tuple.Create(this.resume, 1)},
                    {
                        "c",
                        Tuple.Create(this.resume, 1)},
                    {
                        "D",
                        Tuple.Create(this.detach, 1)},
                    {
                        "g",
                        Tuple.Create(this.getRegisters, 0)},
                    {
                        "G",
                        Tuple.Create(this.setRegisters, 2)},
                    {
                        "H",
                        Tuple.Create(this.setThread, 2)},
                    {
                        "k",
                        Tuple.Create(this.kill, 0)},
                    {
                        "m",
                        Tuple.Create(this.getMemory, 2)},
                    {
                        "M",
                        Tuple.Create(this.writeMemoryHex, 2)},
                    {
                        "p",
                        Tuple.Create(this.readRegister, 2)},
                    {
                        "P",
                        Tuple.Create(this.writeRegister, 2)},
                    {
                        "q",
                        Tuple.Create(this.handleQuery, 2)},
                    {
                        "Q",
                        Tuple.Create(this.handleGeneralSet, 2)},
                    {
                        "s",
                        Tuple.Create(this.step, 1)},
                    {
                        "S",
                        Tuple.Create(this.step, 1)},
                    {
                        "T",
                        Tuple.Create(this.isThreadAlive, 1)},
                    {
                        "v",
                        Tuple.Create(this.vCommand, 2)},
                    {
                        "X",
                        Tuple.Create(this.writeMemory, 2)},
                    {
                        "z",
                        Tuple.Create(this.breakpoint, 1)},
                    {
                        "Z",
                        Tuple.Create(this.breakpoint, 1)}};
                // Commands that kill the connection to gdb.
                this.DETACH_COMMANDS = Tuple.Create("D", "k");
                this.setDaemon(true);
                this.start();
            }
            
            public virtual object restart() {
                if (this.isAlive()) {
                    this.detach_event.set();
                }
            }
            
            public virtual object stop() {
                if (this.isAlive()) {
                    this.shutdown_event.set();
                    while (this.isAlive()) {
                    }
                    this.log.info("GDB server thread killed");
                }
                this.board.uninit();
            }
            
            public virtual object setBoard(object board, object stop = true) {
                this.lock.acquire();
                if (stop) {
                    this.restart();
                }
                this.board = board;
                this.target = board.target;
                this.flash = board.flash;
                this.lock.release();
                return;
            }
            
            public virtual object _cleanup() {
                this.log.debug("GDB server cleaning up");
                if (this.packet_io) {
                    this.packet_io.stop();
                    this.packet_io = null;
                }
                if (this.semihost) {
                    this.semihost.cleanup();
                    this.semihost = null;
                }
                if (this.telnet_console) {
                    this.telnet_console.stop();
                    this.telnet_console = null;
                }
            }
            
            public virtual object _cleanup_for_next_connection() {
                this.non_stop = false;
                this.thread_provider = null;
                this.did_init_thread_providers = false;
                this.current_thread_id = 0;
            }
            
            public virtual object run() {
                this.log.info("GDB server started at port:%d", this.port);
                while (true) {
                    try {
                        this.detach_event.clear();
                        // Inform callback that the server is running.
                        if (this.server_listening_callback) {
                            this.server_listening_callback(this);
                        }
                        while (!this.shutdown_event.isSet() && !this.detach_event.isSet()) {
                            var connected = this.abstract_socket.connect();
                            if (connected != null) {
                                this.packet_io = GDBServerPacketIOThread(this.abstract_socket);
                                break;
                            }
                        }
                        if (this.shutdown_event.isSet()) {
                            this._cleanup();
                            return;
                        }
                        if (this.detach_event.isSet()) {
                            continue;
                        }
                        this.log.info("One client connected!");
                        this._run_connection();
                    } catch (Exception) {
                        this.log.error("Unexpected exception: %s", e);
                        traceback.print_exc();
                    }
                }
            }
            
            public virtual object _run_connection() {
                while (true) {
                    try {
                        if (this.shutdown_event.isSet()) {
                            this._cleanup();
                            return;
                        }
                        if (this.detach_event.isSet()) {
                            break;
                        }
                        if (this.packet_io.interrupt_event.isSet()) {
                            if (this.non_stop) {
                                this.target.halt();
                                this.is_target_running = false;
                                this.sendStopNotification();
                            } else {
                                this.log.error("Got unexpected ctrl-c, ignoring");
                            }
                            this.packet_io.interrupt_event.clear();
                        }
                        if (this.non_stop && this.is_target_running) {
                            try {
                                if (this.target.getState() == Target.TARGET_HALTED) {
                                    this.log.debug("state halted");
                                    this.is_target_running = false;
                                    this.sendStopNotification();
                                }
                            } catch (Exception) {
                                this.log.error("Unexpected exception: %s", e);
                                traceback.print_exc();
                            }
                        }
                        // read command
                        try {
                            var packet = this.packet_io.receive(block: !this.non_stop);
                        } catch (ConnectionClosedException) {
                            break;
                        }
                        if (this.shutdown_event.isSet()) {
                            this._cleanup();
                            return;
                        }
                        if (this.detach_event.isSet()) {
                            break;
                        }
                        if (this.non_stop && packet == null) {
                            sleep(0.1);
                            continue;
                        }
                        this.lock.acquire();
                        if (packet.Count != 0) {
                            // decode and prepare resp
                            var _tup_1 = this.handleMsg(packet);
                            var resp = _tup_1.Item1;
                            var detach = _tup_1.Item2;
                            if (resp != null) {
                                // send resp
                                this.packet_io.send(resp);
                            }
                            if (detach) {
                                this.abstract_socket.close();
                                this.packet_io.stop();
                                this.packet_io = null;
                                this.lock.release();
                                if (this.persist) {
                                    this._cleanup_for_next_connection();
                                    break;
                                } else {
                                    this.shutdown_event.set();
                                    return;
                                }
                            }
                        }
                        this.lock.release();
                    } catch (Exception) {
                        this.log.error("Unexpected exception: %s", e);
                        traceback.print_exc();
                    }
                }
            }
            
            public virtual object handleMsg(object msg) {
                object reply;
                try {
                    Debug.Assert(msg[0] == "$");
                    Debug.Assert("invalid first char of message (!= $");
                    try {
                        var _tup_1 = this.COMMANDS[msg[1]];
                        var handler = _tup_1.Item1;
                        var msgStart = _tup_1.Item2;
                        if (msgStart == 0) {
                            reply = handler();
                        } else {
                            reply = handler(msg[msgStart]);
                        }
                        var detach = this.DETACH_COMMANDS.Contains(msg[1]) ? 1 : 0;
                        return Tuple.Create(reply, detach);
                    } catch {
                        this.log.error("Unknown RSP packet: %s", msg);
                        return Tuple.Create(this.createRSPPacket(""), 0);
                    }
                } catch (Exception) {
                    this.log.error("Unhandled exception in handleMsg: %s", e);
                    traceback.print_exc();
                    return Tuple.Create(this.createRSPPacket("E01"), 0);
                }
            }
            
            public virtual object detach(object data) {
                this.log.info("Client detached");
                var resp = "OK";
                return this.createRSPPacket(resp);
            }
            
            public virtual object kill() {
                this.log.debug("GDB kill");
                // Keep target halted and leave vector catches if in persistent mode.
                if (!this.persist) {
                    this.board.target.setVectorCatch(Target.CATCH_NONE);
                    this.board.target.resume();
                }
                return this.createRSPPacket("");
            }
            
            public virtual object breakpoint(object data) {
                // handle breakpoint/watchpoint commands
                var split = data.split("#")[0].split(",");
                var addr = Convert.ToInt32(split[1], 16);
                this.log.debug(String.Format("GDB breakpoint %s%d @ %x", data[0], Convert.ToInt32(data[1]), addr));
                // handle software breakpoint Z0/z0
                if (data[1] == "0" && !this.soft_bkpt_as_hard) {
                    if (data[0] == "Z") {
                        if (!this.target.setBreakpoint(addr, Target.BREAKPOINT_SW)) {
                            return this.createRSPPacket("E01");
                        }
                    } else {
                        this.target.removeBreakpoint(addr);
                    }
                    return this.createRSPPacket("OK");
                }
                // handle hardware breakpoint Z1/z1
                if (data[1] == "1" || this.soft_bkpt_as_hard && data[1] == "0") {
                    if (data[0] == "Z") {
                        if (this.target.setBreakpoint(addr, Target.BREAKPOINT_HW) == false) {
                            return this.createRSPPacket("E01");
                        }
                    } else {
                        this.target.removeBreakpoint(addr);
                    }
                    return this.createRSPPacket("OK");
                }
                // handle hardware watchpoint Z2/z2/Z3/z3/Z4/z4
                if (data[1] == "2") {
                    // Write-only watch
                    var watchpoint_type = Target.WATCHPOINT_WRITE;
                } else if (data[1] == "3") {
                    // Read-only watch
                    watchpoint_type = Target.WATCHPOINT_READ;
                } else if (data[1] == "4") {
                    // Read-Write watch
                    watchpoint_type = Target.WATCHPOINT_READ_WRITE;
                } else {
                    return this.createRSPPacket("E01");
                }
                var size = Convert.ToInt32(split[2], 16);
                if (data[0] == "Z") {
                    if (this.target.setWatchpoint(addr, size, watchpoint_type) == false) {
                        return this.createRSPPacket("E01");
                    }
                } else {
                    this.target.removeWatchpoint(addr, size, watchpoint_type);
                }
                return this.createRSPPacket("OK");
            }
            
            public virtual object setThread(object data) {
                object thread;
                if (!this.is_threading_enabled()) {
                    return this.createRSPPacket("OK");
                }
                this.log.debug("setThread:%s", data);
                var op = data[0];
                var thread_id = Convert.ToInt32(data[1:: - 3], 16);
                if (!(Tuple.Create(0, -1).Contains(thread_id) || this.thread_provider.is_valid_thread_id(thread_id))) {
                    return this.createRSPPacket("E01");
                }
                if (op == "c") {
                } else if (op == "g") {
                    if (thread_id == -1) {
                        this.target_facade.set_context(this.target_context);
                    } else {
                        if (thread_id == 0) {
                            thread = this.thread_provider.current_thread;
                            thread_id = thread.unique_id;
                        } else {
                            thread = this.thread_provider.get_thread(thread_id);
                        }
                        this.target_facade.set_context(thread.context);
                    }
                } else {
                    return this.createRSPPacket("E01");
                }
                this.current_thread_id = thread_id;
                return this.createRSPPacket("OK");
            }
            
            public virtual object isThreadAlive(object data) {
                object isAlive;
                var threadId = Convert.ToInt32(data[1:: - 3], 16);
                if (this.is_threading_enabled()) {
                    isAlive = this.thread_provider.is_valid_thread_id(threadId);
                } else {
                    isAlive = threadId == 1;
                }
                if (isAlive) {
                    return this.createRSPPacket("OK");
                } else {
                    this.validateDebugContext();
                    return this.createRSPPacket("E00");
                }
            }
            
            public virtual object validateDebugContext() {
                if (this.is_threading_enabled()) {
                    var currentThread = this.thread_provider.current_thread;
                    if (this.current_thread_id != currentThread.unique_id) {
                        this.target_facade.set_context(currentThread.context);
                        this.current_thread_id = currentThread.unique_id;
                    }
                } else if (this.current_thread_id != 1) {
                    this.log.debug("Current thread %x is no longer valid, switching context to target", this.current_thread_id);
                    this.target_facade.set_context(this.target_context);
                    this.current_thread_id = 1;
                }
            }
            
            public virtual object stopReasonQuery() {
                // In non-stop mode, if no threads are stopped we need to reply with OK.
                if (this.non_stop && this.is_target_running) {
                    return this.createRSPPacket("OK");
                }
                return this.createRSPPacket(this.getTResponse());
            }
            
            public virtual object _get_resume_step_addr(object data) {
                object addr;
                if (data == null) {
                    return null;
                }
                data = data.split("#")[0];
                if (!data.Contains(";")) {
                    return null;
                }
                // c[;addr]
                if (Tuple.Create("c", "s").Contains(data[0])) {
                    addr = Convert.ToInt32(data[2], @base: 16);
                } else if (Tuple.Create("C", "S").Contains(data[0])) {
                    // Csig[;addr]
                    addr = Convert.ToInt32(data[1].split(";")[1], @base: 16);
                }
                return addr;
            }
            
            public virtual object resume(object data) {
                var addr = this._get_resume_step_addr(data);
                this.target.resume();
                this.log.debug("target resumed");
                var val = "";
                while (true) {
                    if (this.shutdown_event.isSet()) {
                        this.packet_io.interrupt_event.clear();
                        return this.createRSPPacket(val);
                    }
                    // Wait for a ctrl-c to be received.
                    if (this.packet_io.interrupt_event.wait(0.01)) {
                        this.log.debug("receive CTRL-C");
                        this.packet_io.interrupt_event.clear();
                        this.target.halt();
                        val = this.getTResponse(forceSignal: signals.SIGINT);
                        break;
                    }
                    try {
                        if (this.target.getState() == Target.TARGET_HALTED) {
                            // Handle semihosting
                            if (this.enable_semihosting) {
                                var was_semihost = this.semihost.check_and_handle_semihost_request();
                                if (was_semihost) {
                                    this.target.resume();
                                    continue;
                                }
                            }
                            var pc = this.target_context.readCoreRegister("pc");
                            this.log.debug("state halted; pc=0x%08x", pc);
                            val = this.getTResponse();
                            break;
                        }
                    } catch (Exception) {
                        try {
                            this.target.halt();
                        } catch {
                        }
                        traceback.print_exc();
                        this.log.debug("Target is unavailable temporarily.");
                        val = String.Format("S%02x", this.target_facade.getSignalValue());
                        break;
                    }
                }
                return this.createRSPPacket(val);
            }
            
            public virtual object step(object data) {
                var addr = this._get_resume_step_addr(data);
                this.log.debug("GDB step: %s", data);
                this.target.step(!this.step_into_interrupt);
                return this.createRSPPacket(this.getTResponse());
            }
            
            public virtual object halt() {
                this.target.halt();
                return this.createRSPPacket(this.getTResponse());
            }
            
            public virtual object sendStopNotification(object forceSignal = null) {
                var data = this.getTResponse(forceSignal: forceSignal);
                var packet = "%Stop:" + data + "#" + checksum(data);
                this.packet_io.send(packet);
            }
            
            public virtual object vCommand(object data) {
                var cmd = data.split("#")[0];
                // Flash command.
                if (cmd.startswith("Flash")) {
                    return this.flashOp(data);
                } else if ("Cont?" == cmd) {
                    // vCont capabilities query.
                    return this.createRSPPacket("vCont;c;C;s;S;t");
                } else if (cmd.startswith("Cont")) {
                    // vCont, thread action command.
                    return this.vCont(cmd);
                } else if (cmd.Contains("Stopped")) {
                    // vStopped, part of thread stop state notification sequence.
                    // Because we only support one thread for now, we can just reply OK to vStopped.
                    return this.createRSPPacket("OK");
                }
                return this.createRSPPacket("");
            }
            
            // Example: $vCont;s:1;c#c1
            public virtual object vCont(object cmd) {
                object currentThread;
                object thread_actions;
                var ops = cmd.split(";")[1];
                if (!ops) {
                    return this.createRSPPacket("OK");
                }
                if (this.is_threading_enabled()) {
                    thread_actions = new Dictionary<object, object> {
                    };
                    var threads = this.thread_provider.get_threads();
                    foreach (var k in threads) {
                        thread_actions[k.unique_id] = null;
                    }
                    currentThread = this.thread_provider.get_current_thread_id();
                } else {
                    thread_actions = new Dictionary<object, object> {
                        {
                            1,
                            null}};
                    currentThread = 1;
                }
                object default_action = null;
                foreach (var op in ops) {
                    var args = op.split(":");
                    var action = args[0];
                    if (args.Count > 1) {
                        var thread_id = Convert.ToInt32(args[1], 16);
                        if (thread_id == -1 || thread_id == 0) {
                            thread_id = currentThread;
                        }
                        thread_actions[thread_id] = action;
                    } else {
                        default_action = action;
                    }
                }
                this.log.debug("thread_actions=%s; default_action=%s", repr(thread_actions), default_action);
                // Only the current thread is supported at the moment.
                if (thread_actions[currentThread] == null) {
                    if (default_action == null) {
                        return this.createRSPPacket("E01");
                    }
                    thread_actions[currentThread] = default_action;
                }
                if (Tuple.Create("c", "C").Contains(thread_actions[currentThread][0])) {
                    if (this.non_stop) {
                        this.target.resume();
                        this.is_target_running = true;
                        return this.createRSPPacket("OK");
                    } else {
                        return this.resume(null);
                    }
                } else if (Tuple.Create("s", "S").Contains(thread_actions[currentThread][0])) {
                    if (this.non_stop) {
                        this.target.step(!this.step_into_interrupt);
                        this.packet_io.send(this.createRSPPacket("OK"));
                        this.sendStopNotification();
                        return null;
                    } else {
                        return this.step(null);
                    }
                } else if (thread_actions[currentThread] == "t") {
                    // Must ignore t command in all-stop mode.
                    if (!this.non_stop) {
                        return this.createRSPPacket("");
                    }
                    this.packet_io.send(this.createRSPPacket("OK"));
                    this.target.halt();
                    this.is_target_running = false;
                    this.sendStopNotification(forceSignal: 0);
                } else {
                    this.log.error(String.Format("Unsupported vCont action '%s'", thread_actions[1]));
                }
            }
            
            public virtual object flashOp(object data) {
                object progress_cb;
                var ops = data.split(":")[0];
                this.log.debug("flash op: %s", ops);
                if (ops == "FlashErase") {
                    return this.createRSPPacket("OK");
                } else if (ops == "FlashWrite") {
                    var write_addr = Convert.ToInt32(data.split(":")[1], 16);
                    this.log.debug("flash write addr: 0x%x", write_addr);
                    // search for second ':' (beginning of data encoded in the message)
                    var second_colon = 0;
                    var idx_begin = 0;
                    while (second_colon != 2) {
                        if (data[idx_begin] == ":") {
                            second_colon += 1;
                        }
                        idx_begin += 1;
                    }
                    // Get flash builder if there isn't one already
                    if (this.flashBuilder == null) {
                        this.flashBuilder = this.flash.getFlashBuilder();
                    }
                    // Add data to flash builder
                    this.flashBuilder.addData(write_addr, this.unescape(data[idx_begin::(len(data)  -  3)]));
                    return this.createRSPPacket("OK");
                } else if (ops.Contains("FlashDone")) {
                    // we need to flash everything
                    if (this.hide_programming_progress) {
                        progress_cb = null;
                    } else {
                        progress_cb = print_progress;
                    }
                    this.flashBuilder.program(chip_erase: this.chip_erase, progress_cb: progress_cb, fast_verify: this.fast_program);
                    // Set flash builder to None so that on the next flash command a new
                    // object is used.
                    this.flashBuilder = null;
                    return this.createRSPPacket("OK");
                }
                Func<object, object> print_progress = progress => {
                    // Reset state on 0.0
                    if (progress == 0.0) {
                        print_progress.done = false;
                    }
                    // print progress bar
                    if (!print_progress.done) {
                        sys.stdout.write("\r");
                        var i = Convert.ToInt32(progress * 20.0);
                        sys.stdout.write(String.Format("[%-20s] %3d%%", "=" * i, round(progress * 100)));
                        sys.stdout.flush();
                    }
                    // Finish on 1.0
                    if (progress >= 1.0) {
                        if (!print_progress.done) {
                            print_progress.done = true;
                            sys.stdout.write("\r\n");
                            sys.stdout.flush();
                        }
                    }
                };
                return null;
            }
            
            public virtual object unescape(object data) {
                var data_idx = 0;
                // unpack the data into binary array
                var str_unpack = str(data.Count) + "B";
                data = unpack(str_unpack, data);
                data = data.ToList();
                // check for escaped characters
                while (data_idx < data.Count) {
                    if (data[data_idx] == 125) {
                        data.pop(data_idx);
                        data[data_idx] = data[data_idx] ^ 32;
                    }
                    data_idx += 1;
                }
                return data;
            }
            
            public virtual object escape(object data) {
                var result = "";
                foreach (var c in data) {
                    if ("#$}*".Contains(c)) {
                        result += "}" + chr(ord(c) ^ 32);
                    } else {
                        result += c;
                    }
                }
                return result;
            }
            
            public virtual object getMemory(object data) {
                var split = data.split(",");
                var addr = Convert.ToInt32(split[0], 16);
                var length = split[1].split("#")[0];
                length = Convert.ToInt32(length, 16);
                if (LOG_MEM) {
                    this.log.debug("GDB getMem: addr=%x len=%x", addr, length);
                }
                try {
                    var val = "";
                    var mem = this.target_context.readBlockMemoryUnaligned8(addr, length);
                    // Flush so an exception is thrown now if invalid memory was accesses
                    this.target_context.flush();
                    foreach (var x in mem) {
                        if (x >= 16) {
                            val += hex(x)[2::4];
                        } else {
                            val += "0" + hex(x)[2::3];
                        }
                    }
                } catch {
                    this.log.debug(String.Format("getMemory failed at 0x%x", addr));
                    val = "E01";
                } catch (MemoryAccessError) {
                    logging.debug("getMemory failed at 0x%x: %s", addr, str(e));
                    val = "E01";
                }
                return this.createRSPPacket(val);
            }
            
            public virtual object writeMemoryHex(object data) {
                object resp;
                var split = data.split(",");
                var addr = Convert.ToInt32(split[0], 16);
                split = split[1].split(":");
                var length = Convert.ToInt32(split[0], 16);
                split = split[1].split("#");
                data = hexToByteList(split[0]);
                if (LOG_MEM) {
                    this.log.debug("GDB writeMemHex: addr=%x len=%x", addr, length);
                }
                try {
                    if (length > 0) {
                        this.target_context.writeBlockMemoryUnaligned8(addr, data);
                        // Flush so an exception is thrown now if invalid memory was accessed
                        this.target_context.flush();
                    }
                    resp = "OK";
                } catch {
                    this.log.debug(String.Format("writeMemory failed at 0x%x", addr));
                    resp = "E01";
                } catch (MemoryAccessError) {
                    logging.debug("getMemory failed at 0x%x: %s", addr, str(e));
                    var val = "E01";
                }
                return this.createRSPPacket(resp);
            }
            
            public virtual object writeMemory(object data) {
                object resp;
                var split = data.split(",");
                var addr = Convert.ToInt32(split[0], 16);
                var length = Convert.ToInt32(split[1].split(":")[0], 16);
                if (LOG_MEM) {
                    this.log.debug("GDB writeMem: addr=%x len=%x", addr, length);
                }
                var idx_begin = 0;
                foreach (var i in range(data.Count)) {
                    if (data[i] == ":") {
                        idx_begin += 1;
                        break;
                    }
                    idx_begin += 1;
                }
                data = data[idx_begin::(len(data)  -  3)];
                data = this.unescape(data);
                try {
                    if (length > 0) {
                        this.target_context.writeBlockMemoryUnaligned8(addr, data);
                        // Flush so an exception is thrown now if invalid memory was accessed
                        this.target_context.flush();
                    }
                    resp = "OK";
                } catch {
                    this.log.debug(String.Format("writeMemory failed at 0x%x", addr));
                    resp = "E01";
                } catch (MemoryAccessError) {
                    logging.debug("getMemory failed at 0x%x: %s", addr, str(e));
                    var val = "E01";
                }
                return this.createRSPPacket(resp);
            }
            
            public virtual object readRegister(object which) {
                return this.createRSPPacket(this.target_facade.gdbGetRegister(which));
            }
            
            public virtual object writeRegister(object data) {
                var reg = Convert.ToInt32(data.split("=")[0], 16);
                var val = data.split("=")[1].split("#")[0];
                this.target_facade.setRegister(reg, val);
                return this.createRSPPacket("OK");
            }
            
            public virtual object getRegisters() {
                return this.createRSPPacket(this.target_facade.getRegisterContext());
            }
            
            public virtual object setRegisters(object data) {
                this.target_facade.setRegisterContext(data);
                return this.createRSPPacket("OK");
            }
            
            public virtual object handleQuery(object msg) {
                var query = msg.split(":");
                this.log.debug("GDB received query: %s", query);
                if (query == null) {
                    this.log.error("GDB received query packet malformed");
                    return null;
                }
                if (query[0] == "Supported") {
                    // Save features sent by gdb.
                    this.gdb_features = query[1].split(";");
                    // Build our list of features.
                    var features = new List<object> {
                        "qXfer:features:read+",
                        "QStartNoAckMode+",
                        "qXfer:threads:read+",
                        "QNonStop+"
                    };
                    features.append("PacketSize=" + hex(this.packet_size)[2]);
                    if (this.target_facade.getMemoryMapXML() != null) {
                        features.append("qXfer:memory-map:read+");
                    }
                    var resp = ";".join(features);
                    return this.createRSPPacket(resp);
                } else if (query[0] == "Xfer") {
                    if (query[1] == "features" && query[2] == "read" && query[3] == "target.xml") {
                        var data = query[4].split(",");
                        resp = this.handleQueryXML("read_feature", Convert.ToInt32(data[0], 16), Convert.ToInt32(data[1].split("#")[0], 16));
                        return this.createRSPPacket(resp);
                    } else if (query[1] == "memory-map" && query[2] == "read") {
                        data = query[4].split(",");
                        resp = this.handleQueryXML("memory_map", Convert.ToInt32(data[0], 16), Convert.ToInt32(data[1].split("#")[0], 16));
                        return this.createRSPPacket(resp);
                    } else if (query[1] == "threads" && query[2] == "read") {
                        data = query[4].split(",");
                        resp = this.handleQueryXML("threads", Convert.ToInt32(data[0], 16), Convert.ToInt32(data[1].split("#")[0], 16));
                        return this.createRSPPacket(resp);
                    } else {
                        this.log.debug("Unsupported qXfer request: %s:%s:%s:%s", query[1], query[2], query[3], query[4]);
                        return null;
                    }
                } else if (query[0].startswith("C")) {
                    if (!this.is_threading_enabled()) {
                        return this.createRSPPacket("QC1");
                    } else {
                        this.validateDebugContext();
                        return this.createRSPPacket(String.Format("QC%x", this.current_thread_id));
                    }
                } else if (query[0].find("Attached") != -1) {
                    return this.createRSPPacket("1");
                } else if (query[0].find("TStatus") != -1) {
                    return this.createRSPPacket("");
                } else if (query[0].find("Tf") != -1) {
                    return this.createRSPPacket("");
                } else if (query[0].Contains("Offsets")) {
                    resp = "Text=0;Data=0;Bss=0";
                    return this.createRSPPacket(resp);
                } else if (query[0].Contains("Symbol")) {
                    if (this.did_init_thread_providers) {
                        return this.createRSPPacket("OK");
                    }
                    return this.initThreadProviders();
                } else if (query[0].startswith("Rcmd,")) {
                    var cmd = hexDecode(query[0][5].split("#")[0]);
                    return this.handleRemoteCommand(cmd);
                } else {
                    return this.createRSPPacket("");
                }
            }
            
            public virtual object initThreadProviders() {
                var symbol_provider = GDBSymbolProvider(this);
                foreach (var _tup_1 in RTOS) {
                    var rtosName = _tup_1.Item1;
                    var rtosClass = _tup_1.Item2;
                    try {
                        this.log.info("Attempting to load %s", rtosName);
                        var rtos = rtosClass(this.target);
                        if (rtos.init(symbol_provider)) {
                            this.log.info("%s loaded successfully", rtosName);
                            this.thread_provider = rtos;
                            break;
                        }
                    } catch (RuntimeError) {
                        this.log.error("Error during symbol lookup: " + str(e));
                        traceback.print_exc();
                    }
                }
                this.did_init_thread_providers = true;
                // Done with symbol processing.
                return this.createRSPPacket("OK");
            }
            
            public virtual object getSymbol(object name) {
                // Send the symbol request.
                var request = this.createRSPPacket("qSymbol:" + hexEncode(name));
                this.packet_io.send(request);
                // Read a packet.
                var packet = this.packet_io.receive();
                // Parse symbol value reply packet.
                packet = packet[1:: - 3];
                if (!packet.startswith("qSymbol:")) {
                    throw RuntimeError("Got unexpected response from gdb when asking for symbol value");
                }
                packet = packet[8];
                var _tup_1 = packet.split(":");
                var symValue = _tup_1.Item1;
                var symName = _tup_1.Item2;
                symName = hexDecode(symName);
                if (symName != name) {
                    throw RuntimeError("Symbol value reply from gdb has unexpected symbol name");
                }
                if (symValue) {
                    symValue = hex8leToU32le(symValue);
                } else {
                    return null;
                }
                return symValue;
            }
            
            // TODO rewrite the remote command handler
            public virtual object handleRemoteCommand(object cmd) {
                this.log.debug("Remote command: %s", cmd);
                var safecmd = new Dictionary<object, object> {
                    {
                        "init",
                        new List<object> {
                            "Init reset sequence",
                            1
                        }},
                    {
                        "reset",
                        new List<object> {
                            "Reset and halt the target",
                            2
                        }},
                    {
                        "halt",
                        new List<object> {
                            "Halt target",
                            4
                        }},
                    {
                        "help",
                        new List<object> {
                            "Display this help",
                            128
                        }}};
                var cmdList = cmd.split();
                var resp = "OK";
                if (cmd == "help") {
                    resp = "".join(safecmd.items().Select(Tuple.Create(k, v) => String.Format("%s\t%s\n", k, v[0])));
                    resp = hexEncode(resp);
                } else if (cmd.startswith("arm semihosting")) {
                    this.enable_semihosting = cmd.Contains("enable");
                    this.log.info("Semihosting %s", this.enable_semihosting ? "enabled" : "disabled");
                } else if (cmdList[0] == "set") {
                    if (cmdList.Count < 3) {
                        resp = hexEncode("Error: invalid set command");
                    } else if (cmdList[1] == "vector-catch") {
                        try {
                            this.board.target.setVectorCatch(convert_vector_catch(cmdList[2]));
                        } catch (ValueError) {
                            resp = hexEncode("Error: " + str(e));
                        }
                    } else if (cmdList[1] == "step-into-interrupt") {
                        this.step_into_interrupt = Tuple.Create("true", "on", "yes", "1").Contains(cmdList[2].lower());
                    } else {
                        resp = hexEncode("Error: invalid set option");
                    }
                } else {
                    var resultMask = 0;
                    if (cmdList[0] == "help") {
                        // a 'help' is only valid as the first cmd, and only
                        // gives info on the second cmd if it is valid
                        resultMask |= 128;
                        cmdList.Remove(0);
                    }
                    foreach (var cmd_sub in cmdList) {
                        if (!safecmd.Contains(cmd_sub)) {
                            this.log.warning("Invalid mon command '%s'", cmd_sub);
                            resp = String.Format("Invalid Command: \"%s\"\n", cmd_sub);
                            resp = hexEncode(resp);
                            return this.createRSPPacket(resp);
                        } else if (resultMask == 128) {
                            // if the first command was a 'help', we only need
                            // to return info about the first cmd after it
                            resp = hexEncode(safecmd[cmd_sub][0] + "\n");
                            return this.createRSPPacket(resp);
                        }
                        resultMask |= safecmd[cmd_sub][1];
                    }
                    // Run cmds in proper order
                    if (resultMask & 1) {
                    }
                    if ((resultMask & 6) == 6) {
                        this.target.resetStopOnReset();
                    } else if (resultMask & 2) {
                        // on 'reset' still do a reset halt
                        this.target.resetStopOnReset();
                        // self.target.reset()
                    } else if (resultMask & 4) {
                        this.target.halt();
                        // if resultMask & 0x8:
                        //     self.target.resume()
                    }
                }
                return this.createRSPPacket(resp);
            }
            
            public virtual object handleGeneralSet(object msg) {
                var feature = msg.split("#")[0];
                this.log.debug("GDB general set: %s", feature);
                if (feature == "StartNoAckMode") {
                    // Disable acks after the reply and ack.
                    this.packet_io.set_send_acks(false);
                    return this.createRSPPacket("OK");
                } else if (feature.startswith("NonStop")) {
                    var enable = feature.split(":")[1];
                    this.non_stop = enable == "1";
                    return this.createRSPPacket("OK");
                } else {
                    return this.createRSPPacket("");
                }
            }
            
            public virtual object handleQueryXML(object query, object offset, object size) {
                this.log.debug("GDB query %s: offset: %s, size: %s", query, offset, size);
                var xml = "";
                if (query == "memory_map") {
                    xml = this.target_facade.getMemoryMapXML();
                } else if (query == "read_feature") {
                    xml = this.target.getTargetXML();
                } else if (query == "threads") {
                    xml = this.getThreadsXML();
                } else {
                    throw RuntimeError(String.Format("Invalid XML query (%s)", query));
                }
                var size_xml = xml.Count;
                var prefix = "m";
                if (offset > size_xml) {
                    this.log.error("GDB: xml offset > size for %s!", query);
                    return;
                }
                if (size > this.packet_size - 4) {
                    size = this.packet_size - 4;
                }
                var nbBytesAvailable = size_xml - offset;
                if (size > nbBytesAvailable) {
                    prefix = "l";
                    size = nbBytesAvailable;
                }
                var resp = prefix + this.escape(xml[offset::(offset  +  size)]);
                return resp;
            }
            
            public virtual object createRSPPacket(object data) {
                var resp = "$" + data + "#" + checksum(data);
                return resp;
            }
            
            public virtual object syscall(object op) {
                this.log.debug("GDB server syscall: %s", op);
                var request = this.createRSPPacket("F" + op);
                this.packet_io.send(request);
                while (!this.packet_io.interrupt_event.is_set()) {
                    // Read a packet.
                    var packet = this.packet_io.receive(false);
                    if (packet == null) {
                        sleep(0.1);
                        continue;
                    }
                    // Check for file I/O response.
                    if (packet[0] == "$" && packet[1] == "F") {
                        this.log.debug("Syscall: got syscall response " + packet);
                        var args = packet[2::packet.index("#")].split(",");
                        var result = Convert.ToInt32(args[0], @base: 16);
                        var errno = args.Count > 1 ? Convert.ToInt32(args[1], @base: 16) : 0;
                        var ctrl_c = args.Count > 2 ? args[2] : "";
                        if (ctrl_c == "C") {
                            this.packet_io.interrupt_event.set();
                            this.packet_io.drop_reply = true;
                        }
                        return Tuple.Create(result, errno);
                    }
                    // decode and prepare resp
                    var _tup_1 = this.handleMsg(packet);
                    var resp = _tup_1.Item1;
                    var detach = _tup_1.Item2;
                    if (resp != null) {
                        // send resp
                        this.packet_io.send(resp);
                    }
                    if (detach) {
                        this.detach_event.set();
                        this.log.warning("GDB server received detach request while waiting for file I/O completion");
                        break;
                    }
                }
                return Tuple.Create(-1, 0);
            }
            
            public virtual object getTResponse(object forceSignal = null) {
                this.validateDebugContext();
                var response = this.target_facade.getTResponse(forceSignal);
                // Append thread and core
                if (!this.is_threading_enabled()) {
                    response += "thread:1;core:0;";
                } else if (Tuple.Create(-1, 0, 1).Contains(this.current_thread_id)) {
                    response += String.Format("thread:%x;core:0;", this.thread_provider.current_thread.unique_id);
                } else {
                    response += String.Format("thread:%x;core:0;", this.current_thread_id);
                }
                this.log.debug("Tresponse=%s", response);
                return response;
            }
            
            public virtual object getThreadsXML() {
                object t;
                var root = Element("threads");
                if (!this.is_threading_enabled()) {
                    t = SubElement(root, "thread", id: "1", core: "0");
                    t.text = "Thread mode";
                } else {
                    var threads = this.thread_provider.get_threads();
                    foreach (var thread in threads) {
                        var hexId = String.Format("%x", thread.unique_id);
                        t = SubElement(root, "thread", id: hexId, core: "0");
                        var desc = thread.description;
                        if (desc) {
                            desc = thread.name + "; " + desc;
                        } else {
                            desc = thread.name;
                        }
                        t.text = desc;
                    }
                }
                return "<?xml version=\"1.0\"?><!DOCTYPE feature SYSTEM \"threads.dtd\">" + tostring(root);
            }
            
            public virtual object is_threading_enabled() {
                return this.thread_provider != null && this.thread_provider.is_enabled && this.thread_provider.current_thread != null;
            }
        }
    }
}
