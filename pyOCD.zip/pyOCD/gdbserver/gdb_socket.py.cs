// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace gdbserver {
    
    using socket;
    
    using select;
    
    using System.Collections.Generic;
    
    public static class gdb_socket {
        
        public class GDBSocket
            : object {
            
            public GDBSocket(object port, object packet_size) {
                this.packet_size = packet_size;
                this.s = null;
                this.conn = null;
                this.port = port;
                this.host = "";
            }
            
            public virtual object init() {
                if (this.s == null) {
                    this.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
                    this.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1);
                    this.s.bind(Tuple.Create(this.host, this.port));
                    this.s.listen(5);
                }
            }
            
            public virtual object connect() {
                this.conn = null;
                this.init();
                var _tup_1 = select.select(new List<object> {
                    this.s
                }, new List<object>(), new List<object>(), 0.5);
                var rr = _tup_1.Item1;
                if (rr) {
                    var _tup_2 = this.s.accept();
                    this.conn = _tup_2.Item1;
                }
                return this.conn;
            }
            
            public virtual object read() {
                return this.conn.recv(this.packet_size);
            }
            
            public virtual object write(object data) {
                return this.conn.send(data);
            }
            
            public virtual object close() {
                if (this.conn != null) {
                    this.conn.close();
                    this.conn = null;
                }
                object return_value = null;
                if (this.s != null) {
                    return_value = this.s.close();
                    this.s = null;
                }
                return return_value;
            }
            
            public virtual object setBlocking(object blocking) {
                this.conn.setblocking(blocking);
            }
            
            public virtual object setTimeout(object timeout) {
                this.conn.settimeout(timeout);
            }
        }
    }
}
