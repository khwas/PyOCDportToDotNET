// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace debug
{

    using os;

    using sys;

    using io;

    using logging;

    using time;

    using datetime;

    using threading;

    using socket;

    using traceback;

    using pyOCD;

    using GDBSocket = gdbserver.gdb_socket.GDBSocket;

    using GDBWebSocket = gdbserver.gdb_websocket.GDBWebSocket;

    using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;

    using System.Collections.Generic;

    using System;
    using System.Diagnostics;

    public static class semihost
    {

        public static object LOG_SEMIHOST = true;

        // ## bkpt #0xab instruction
        public const UInt16 BKPT_INSTR = 0xbeab;

        public const byte TARGET_SYS_OPEN = 1;
        public const byte TARGET_SYS_CLOSE = 2;
        public const byte TARGET_SYS_WRITEC = 3;
        public const byte TARGET_SYS_WRITE0 = 4;
        public const byte TARGET_SYS_WRITE = 5;
        public const byte TARGET_SYS_READ = 6;
        public const byte TARGET_SYS_READC = 7;
        public const byte TARGET_SYS_ISERROR = 8;
        public const byte TARGET_SYS_ISTTY = 9;
        public const byte TARGET_SYS_SEEK = 10;
        public const byte TARGET_SYS_FLEN = 12;
        public const byte TARGET_SYS_TMPNAM = 13;
        public const byte TARGET_SYS_REMOVE = 14;
        public const byte TARGET_SYS_RENAME = 15;
        public const byte TARGET_SYS_CLOCK = 16;
        public const byte TARGET_SYS_TIME = 17;
        public const byte TARGET_SYS_SYSTEM = 18;
        public const byte TARGET_SYS_ERRNO = 19;
        public const byte TARGET_SYS_GET_CMDLINE = 21;
        public const byte TARGET_SYS_HEAPINFO = 22;
        public const byte angel_SWIreason_EnterSVC = 23;
        public const byte TARGET_SYS_EXIT = 24;
        public const byte TARGET_SYS_ELAPSED = 48;
        public const byte TARGET_SYS_TICKFREQ = 49;
        public const byte STDIN_FD = 1;
        public const byte STDOUT_FD = 2;
        public const byte STDERR_FD = 3;

        public const UInt16 MAX_STRING_LENGTH = 2048;

        public class SemihostIOHandler
        {

            internal object agent;
            internal Exception _errno;

            public SemihostIOHandler()
            {
                this.agent = null;
                this._errno = null;
            }

            public virtual void cleanup()
            {
            }

            public Exception errno
            {
                get
                {
                    return this._errno;
                }
            }

            // Helper for standard I/O open requests.
            //
            // In the ARM semihosting spec, standard I/O files are opened using a filename of ":tt"
            // with the open mode specifying which standard I/O file to open. This method takes care
            // of these special open requests, and is intended to be used by concrete I/O handler
            // subclasses.
            //
            // @return A 2-tuple of the file descriptor and filename. The filename is returned so it
            //   only has to be read from target memory once if the request is not for standard I/O.
            //   The returned file descriptor may be one of 0, 1, or 2 for the standard I/O files,
            //   -1 if an invalid combination was requested, or None if the request was not for
            //   a standard I/O file (i.e., the filename was not ":tt"). If None is returned for the
            //   file descriptor, the caller must handle the open request.
            public virtual object _std_open(object fnptr, object fnlen, object mode)
            {
                var filename = this.agent._get_string(fnptr, fnlen);
                Trace.TraceInformation("Semihost: open '%s' mode %s", filename, mode);
                // Handle standard I/O.
                if (filename == ":tt")
                {
                    if (mode == "r")
                    {
                        var fd = STDIN_FD;
                    }
                    else if (mode == "w")
                    {
                        fd = STDOUT_FD;
                    }
                    else if (mode == "a")
                    {
                        fd = STDERR_FD;
                    }
                    else
                    {
                        Trace.TraceWarning("Unrecognized semihosting console open file combination: mode=%s", mode);
                        return Tuple.Create(-1, filename);
                    }
                    return Tuple.Create(fd, filename);
                }
                return Tuple.Create(null, filename);
            }

            public virtual object open(object fnptr, object fnlen, object mode)
            {
                throw new NotImplementedException();
            }

            public virtual object close(object fd)
            {
                throw new NotImplementedException();
            }

            public virtual object write(object fd, object ptr, object length)
            {
                throw new NotImplementedException();
            }

            public virtual object read(object fd, object ptr, object length)
            {
                throw new NotImplementedException();
            }

            public virtual object readc()
            {
                throw new NotImplementedException();
            }

            public virtual object istty(object fd)
            {
                throw new NotImplementedException();
            }

            public virtual object seek(object fd, object pos)
            {
                throw new NotImplementedException();
            }

            public virtual object flen(object fd)
            {
                throw new NotImplementedException();
            }

            public virtual object remove(object ptr, object length)
            {
                throw new NotImplementedException();
            }

            public virtual object rename(object oldptr, object oldlength, object newptr, object newlength)
            {
                throw new NotImplementedException();
            }
        }

        public class InternalSemihostIOHandler
            : SemihostIOHandler
        {

            public InternalSemihostIOHandler()
            {
                this.next_fd = STDERR_FD + 1;
                // Go ahead and connect standard I/O.
                this.open_files = new Dictionary<object, object> {
                    {
                        STDIN_FD,
                        sys.stdin},
                    {
                        STDOUT_FD,
                        sys.stdout},
                    {
                        STDERR_FD,
                        sys.stderr}};
            }

            public virtual object _is_valid_fd(object fd)
            {
                return this.open_files.ContainsKey(fd) && this.open_files[fd] != null;
            }

            public virtual object cleanup()
            {
                foreach (var f in this.open_files.Where(k => k > STDERR_FD).Select(k => this.open_files[k]))
                {
                    f.close();
                }
            }

            public virtual object open(object fnptr, object fnlen, object mode)
            {
                var _tup_1 = this._std_open(fnptr, fnlen, mode);
                var fd = _tup_1.Item1;
                var filename = _tup_1.Item2;
                if (fd != null)
                {
                    return fd;
                }
                try
                {
                    fd = this.next_fd;
                    this.next_fd += 1;
                    var f = io.open(filename, mode);
                    this.open_files[fd] = f;
                    return fd;
                }
                catch //(IOError)
                {
                    this._errno = e.errno;
                    Trace.TraceError("Semihost: failed to open file '%s'", filename);
                    traceback.print_exc();
                    return -1;
                }
            }

            public virtual object close(object fd)
            {
                if (fd > STDERR_FD)
                {
                    if (!this._is_valid_fd(fd))
                    {
                        return -1;
                    }
                    var f = this.open_files.pop(fd);
                    try
                    {
                        f.close();
                    }
                    catch (OSError)
                    {
                        // Ignore errors closing files.
                    }
                }
                return 0;
            }

            public virtual object write(object fd, object ptr, object length)
            {
                if (!this._is_valid_fd(fd))
                {
                    // Return byte count not written.
                    return length;
                }
                var data = this.agent._get_string(ptr, length);
                try
                {
                    var f = this.open_files[fd];
                    if (!f.mode.Contains("b"))
                    {
                        data = unicode(data);
                    }
                    f.write(data);
                    f.flush();
                    return 0;
                }
                catch (IOError)
                {
                    this._errno = e.errno;
                    Trace.TraceInformation("Semihost: exception: %s", e);
                    return -1;
                }
            }

            public virtual object read(object fd, object ptr, object length)
            {
                object data;
                if (!this._is_valid_fd(fd))
                {
                    // Return byte count not read.
                    return length;
                }
                try
                {
                    var f = this.open_files[fd];
                    data = f.read(length);
                    if (!f.mode.Contains("b"))
                    {
                        data = data.encode();
                    }
                }
                catch (IOError)
                {
                    this._errno = e.errno;
                    Trace.TraceInformation("Semihost: exception: %s", e);
                    return -1;
                }
                data = bytearray(data);
                this.agent.context.writeBlockMemoryUnaligned8(ptr, data);
                return length - data.Count;
            }

            public virtual object readc()
            {
                try
                {
                    var f = this.open_files[STDIN_FD];
                    if (f != null)
                    {
                        var data = f.read(1);
                        if (!f.mode.Contains("b"))
                        {
                            data = data.encode();
                        }
                        return data;
                    }
                    else
                    {
                        return 0;
                    }
                }
                catch (OSError)
                {
                    this._errno = e.errno;
                    return 0;
                }
            }

            public virtual object istty(object fd)
            {
                if (!this._is_valid_fd(fd))
                {
                    return -1;
                }
                // Just assume that stdio is a terminal and other files aren't.
                return Convert.ToInt32(!(fd > STDERR_FD));
            }

            public virtual object seek(object fd, object pos)
            {
                if (!this._is_valid_fd(fd))
                {
                    return -1;
                }
                try
                {
                    this.open_files[fd].seek(pos);
                    return 0;
                }
                catch (IOError)
                {
                    this._errno = e.errno;
                    return -1;
                }
            }

            public virtual object flen(object fd)
            {
                if (!this._is_valid_fd(fd))
                {
                    return -1;
                }
                try
                {
                    var info = os.fstat(this.open_files[fd].fileno());
                    return info.st_size;
                }
                catch (OSError)
                {
                    this._errno = e.errno;
                    return -1;
                }
            }
        }

        public class TelnetSemihostIOHandler
            : SemihostIOHandler
        {

            public TelnetSemihostIOHandler(object port_or_url, object serve_local_only = true)
            {
                this._abstract_socket = null;
                this._wss_server = null;
                this._port = 0;
                if (port_or_url is str == true)
                {
                    this._wss_server = port_or_url;
                    this._abstract_socket = GDBWebSocket(this._wss_server);
                }
                else
                {
                    this._port = port_or_url;
                    this._abstract_socket = GDBSocket(this._port, 4096);
                    if (serve_local_only)
                    {
                        this._abstract_socket.host = "localhost";
                    }
                }
                this._buffer = bytearray();
                this._buffer_lock = threading.Lock();
                this.connected = null;
                this._shutdown_event = threading.Event();
                this._thread = threading.Thread(target: this._server, name: "semihost-telnet");
                this._thread.daemon = true;
                this._thread.start();
            }

            public virtual object stop()
            {
                this._shutdown_event.set();
                this._thread.join();
            }

            public virtual object _server()
            {
                Trace.TraceInformation("Telnet: server started on port %s", str(this._port));
                this.connected = null;
                try
                {
                    while (!this._shutdown_event.is_set())
                    {
                        // Wait for a client to connect.
                        // TODO support multiple client connections
                        while (!this._shutdown_event.is_set())
                        {
                            this.connected = this._abstract_socket.connect();
                            if (this.connected != null)
                            {
                                Trace.TraceInformation("Telnet: client connected");
                                break;
                            }
                        }
                        if (this._shutdown_event.is_set())
                        {
                            break;
                        }
                        // Set timeout on new connection.
                        this._abstract_socket.setTimeout(0.1);
                        // Keep reading from the client until we either get a shutdown event, or
                        // the client disconnects. The incoming data is appended to our read buffer.
                        while (!this._shutdown_event.is_set())
                        {
                            try
                            {
                                var data = this._abstract_socket.read();
                                if (data.Count == 0)
                                {
                                    // Client disconnected.
                                    this._abstract_socket.close();
                                    this.connected = null;
                                    break;
                                }
                                this._buffer_lock.acquire();
                                this._buffer += bytearray(data);
                                this._buffer_lock.release();
                            }
                            catch
                            {
                            }
                        }
                    }
                }
                finally
                {
                    this._abstract_socket.close();
                }
                Trace.TraceInformation("Telnet: server stopped");
            }

            public virtual object write(object fd, object ptr, object length)
            {
                // If nobody is connected, act like all data was written anyway.
                if (this.connected == null)
                {
                    return 0;
                }
                var data = this.agent._get_string(ptr, length);
                var remaining = data.Count;
                while (remaining)
                {
                    var count = this._abstract_socket.write(data);
                    remaining -= count;
                    if (remaining)
                    {
                        data = data[count];
                    }
                }
                return 0;
            }

            // Extract requested amount of data from the read buffer.
            public virtual object _get_input(object length)
            {
                object data;
                this._buffer_lock.acquire();
                try
                {
                    var actualLength = min(length, this._buffer.Count);
                    if (actualLength)
                    {
                        data = this._buffer[::actualLength];
                        this._buffer = this._buffer[actualLength];
                    }
                    else
                    {
                        data = bytearray();
                    }
                    return data;
                }
                finally
                {
                    this._buffer_lock.release();
                }
            }

            public virtual object read(object fd, object ptr, object length)
            {
                if (this.connected == null)
                {
                    return -1;
                }
                // Extract requested amount of data from the read buffer.
                var data = this._get_input(length);
                // Stuff data into provided buffer.
                if (data)
                {
                    this.agent.context.writeBlockMemoryUnaligned8(ptr, data);
                }
                var result = length - data.Count;
                if (!data)
                {
                    this._errno = 5;
                    return -1;
                }
                return result;
            }

            public virtual object readc()
            {
                if (this.connected == null)
                {
                    return -1;
                }
                var data = this._get_input(1);
                if (data)
                {
                    return data[0];
                }
                else
                {
                    return -1;
                }
            }
        }

        public class SemihostAgent
        {

            public object OPEN_MODES = new List<object> {
                "r",
                "rb",
                "r+",
                "r+b",
                "w",
                "wb",
                "w+",
                "w+b",
                "a",
                "ab",
                "a+",
                "a+b"
            };

            public object EPOCH = datetime.datetime(1970, 1, 1);

            public SemihostAgent(object context, object io_handler = null, object console = null)
            {
                this.context = context;
                this.start_time = time.time();
                this.io_handler = io_handler || SemihostIOHandler();
                this.io_handler.agent = this;
                this.console = console || this.io_handler;
                this.console.agent = this;
                this.request_map = new Dictionary<object, object> {
                    {
                        TARGET_SYS_OPEN,
                        this.handle_sys_open},
                    {
                        TARGET_SYS_CLOSE,
                        this.handle_sys_close},
                    {
                        TARGET_SYS_WRITEC,
                        this.handle_sys_writec},
                    {
                        TARGET_SYS_WRITE0,
                        this.handle_sys_write0},
                    {
                        TARGET_SYS_WRITE,
                        this.handle_sys_write},
                    {
                        TARGET_SYS_READ,
                        this.handle_sys_read},
                    {
                        TARGET_SYS_READC,
                        this.handle_sys_readc},
                    {
                        TARGET_SYS_ISERROR,
                        this.handle_sys_iserror},
                    {
                        TARGET_SYS_ISTTY,
                        this.handle_sys_istty},
                    {
                        TARGET_SYS_SEEK,
                        this.handle_sys_seek},
                    {
                        TARGET_SYS_FLEN,
                        this.handle_sys_flen},
                    {
                        TARGET_SYS_TMPNAM,
                        this.handle_sys_tmpnam},
                    {
                        TARGET_SYS_REMOVE,
                        this.handle_sys_remove},
                    {
                        TARGET_SYS_RENAME,
                        this.handle_sys_rename},
                    {
                        TARGET_SYS_CLOCK,
                        this.handle_sys_clock},
                    {
                        TARGET_SYS_TIME,
                        this.handle_sys_time},
                    {
                        TARGET_SYS_SYSTEM,
                        this.handle_sys_system},
                    {
                        TARGET_SYS_ERRNO,
                        this.handle_sys_errno},
                    {
                        TARGET_SYS_GET_CMDLINE,
                        this.handle_sys_get_cmdline},
                    {
                        TARGET_SYS_HEAPINFO,
                        this.handle_sys_heapinfo},
                    {
                        TARGET_SYS_EXIT,
                        this.handle_sys_exit},
                    {
                        TARGET_SYS_ELAPSED,
                        this.handle_sys_elapsed},
                    {
                        TARGET_SYS_TICKFREQ,
                        this.handle_sys_tickfreq}};
            }

            // Handle a semihosting request.
            //
            // This method should be called after the target has halted, to check if the halt was
            // due to a semihosting request. It first checks to see if the target halted because
            // of a breakpoint. If so, it reads the instruction at PC to make sure it is a 'bkpt #0xAB'
            // instruction. If so, the target is making a semihosting request. If not, nothing more is done.
            //
            // After the request is handled, the PC is advanced to the next instruction after the 'bkpt'.
            // A boolean is return indicating whether a semihosting request was handled. If True, the
            // caller should resume the target immediately.
            //
            // @retval True A semihosting request was handled.
            // @retval False The target halted for a reason other than semihosting, i.e. a user-installed
            //   debugging breakpoint.
            public virtual object check_and_handle_semihost_request()
            {
                object result;
                // Nothing to do if this is not a bkpt.
                if ((this.context.read32(pyOCD.coresight.cortex_m.CortexM.DFSR) & pyOCD.coresight.cortex_m.CortexM.DFSR_BKPT) == 0)
                {
                    return false;
                }
                var pc = this.context.readCoreRegister("pc");
                // Are we stopped due to one of our own breakpoints?
                var bp = this.context.core.findBreakpoint(pc);
                if (bp)
                {
                    return false;
                }
                // Get the instruction at the breakpoint.
                var instr = this.context.read16(pc);
                // Check for semihost bkpt.
                if (instr != BKPT_INSTR)
                {
                    return false;
                }
                // Advance PC beyond the bkpt instruction.
                this.context.writeCoreRegister("pc", pc + 2);
                // Get args
                var op = this.context.readCoreRegister("r0");
                var args = this.context.readCoreRegister("r1");
                // Handle request
                var handler = this.request_map.get(op, null);
                if (handler)
                {
                    try
                    {
                        result = handler(args);
                    }
                    catch (NotImplementedException)
                    {
                        Trace.TraceWarning("Semihost: unimplemented request pc=%x r0=%x r1=%x", pc, op, args);
                        result = -1;
                    }
                    catch (Exception)
                    {
                        Trace.TraceWarning("Exception while handling semihost request: %s", e);
                        traceback.print_exc(e);
                        result = -1;
                    }
                }
                else
                {
                    result = -1;
                }
                // Set return value.
                this.context.writeCoreRegister("r0", result);
                return true;
            }

            // Clean up any resources allocated by semihost requests.
            //
            // @note May be called more than once.
            public virtual object cleanup()
            {
                this.io_handler.cleanup();
                if (this.console != this.io_handler)
                {
                    this.console.cleanup();
                }
            }

            public virtual object _get_args(object args, object count)
            {
                args = this.context.readBlockMemoryAligned32(args, count);
                if (count == 1)
                {
                    return args[0];
                }
                else
                {
                    return args;
                }
            }

            public virtual object _get_string(object ptr, object length = null)
            {
                object data;
                if (length != null)
                {
                    data = this.context.readBlockMemoryUnaligned8(ptr, length);
                    return str(bytearray(data));
                }
                var target_str = "";
                // TODO - use memory map to make sure we don't try to read off the end of memory
                // Limit string size in case it isn't terminated.
                while (target_str.Count < MAX_STRING_LENGTH)
                {
                    try
                    {
                        // Read 32 bytes at a time for efficiency.
                        data = this.context.readBlockMemoryUnaligned8(ptr, 32);
                        var terminator = data.index(0);
                        // Found a null terminator, append data up to but not including the null
                        // and then exit the loop.
                        target_str += str(bytearray(data[::terminator]));
                        break;
                    }
                    catch
                    {
                        // Failed to read some or all of the string.
                        break;
                    }
                    catch (ArgumentOutOfRangeException)
                    {
                        // No null terminator was found. Append all of data.
                        target_str += str(bytearray(data));
                        ptr += 32;
                    }
                }
                return target_str;
            }

            public virtual object handle_sys_open(object args)
            {
                var _tup_1 = this._get_args(args, 3);
                var fnptr = _tup_1.Item1;
                var mode = _tup_1.Item2;
                var fnlen = _tup_1.Item3;
                if (mode >= this.OPEN_MODES.Count)
                {
                    return -1;
                }
                mode = this.OPEN_MODES[mode];
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: open %x/%x, mode %s", fnptr, fnlen, mode);
                }
                return this.io_handler.open(fnptr, fnlen, mode);
            }

            public virtual object handle_sys_close(object args)
            {
                var fd = this._get_args(args, 1);
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: close fd=%d", fd);
                }
                return this.io_handler.close(fd);
            }

            public virtual object handle_sys_writec(object args)
            {
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: writec %x", args);
                }
                return this.console.write(STDOUT_FD, args, 1);
            }

            public virtual object handle_sys_write0(object args)
            {
                var msg = this._get_string(args);
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: write0 msg='%s'", msg);
                }
                return this.console.write(STDOUT_FD, args, msg.Count);
            }

            public virtual object handle_sys_write(object args)
            {
                var _tup_1 = this._get_args(args, 3);
                var fd = _tup_1.Item1;
                var data_ptr = _tup_1.Item2;
                var length = _tup_1.Item3;
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: write fd=%d ptr=%x len=%d", fd, data_ptr, length);
                }
                if (Tuple.Create(STDOUT_FD, STDERR_FD).Contains(fd))
                {
                    return this.console.write(fd, data_ptr, length);
                }
                else
                {
                    return this.io_handler.write(fd, data_ptr, length);
                }
            }

            public virtual object handle_sys_read(object args)
            {
                var _tup_1 = this._get_args(args, 3);
                var fd = _tup_1.Item1;
                var ptr = _tup_1.Item2;
                var length = _tup_1.Item3;
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: read fd=%d ptr=%x len=%d", fd, ptr, length);
                }
                if (fd == STDIN_FD)
                {
                    return this.console.read(fd, ptr, length);
                }
                else
                {
                    return this.io_handler.read(fd, ptr, length);
                }
            }

            public virtual object handle_sys_readc(object args)
            {
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: readc");
                }
                return this.console.readc();
            }

            public virtual object handle_sys_iserror(object args)
            {
                throw new NotImplementedException();
            }

            public virtual object handle_sys_istty(object args)
            {
                var fd = this._get_args(args, 1);
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: istty fd=%d", fd);
                }
                return this.io_handler.istty(fd);
            }

            public virtual object handle_sys_seek(object args)
            {
                var _tup_1 = this._get_args(args, 2);
                var fd = _tup_1.Item1;
                var pos = _tup_1.Item2;
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: seek fd=%d pos=%d", fd, pos);
                }
                return this.io_handler.seek(fd, pos);
            }

            public virtual object handle_sys_flen(object args)
            {
                var fd = this._get_args(args, 1);
                if (LOG_SEMIHOST)
                {
                    Trace.TraceInformation("Semihost: flen fd=%d", fd);
                }
                return this.io_handler.flen(fd);
            }

            public virtual object handle_sys_tmpnam(object args)
            {
                throw new NotImplementedException();
            }

            public virtual object handle_sys_remove(object args)
            {
                var _tup_1 = this._get_args(args, 2);
                var ptr = _tup_1.Item1;
                var length = _tup_1.Item2;
                return this.io_handler.remove(ptr, length);
            }

            public virtual object handle_sys_rename(object args)
            {
                var _tup_1 = this._get_args(args, 4);
                var oldptr = _tup_1.Item1;
                var oldlength = _tup_1.Item2;
                var newptr = _tup_1.Item3;
                var newlength = _tup_1.Item4;
                return this.io_handler.rename(oldptr, oldlength, newptr, newlength);
            }

            public virtual object handle_sys_clock(object args)
            {
                var now = time.time();
                var delta = now - this.start_time;
                return Convert.ToInt32(delta * 100);
            }

            public virtual object handle_sys_time(object args)
            {
                var now = datetime.datetime.now();
                var delta = now - this.EPOCH;
                var seconds = delta.days * 86400 + delta.seconds;
                return seconds;
            }

            public virtual object handle_sys_system(object args)
            {
                throw new NotImplementedException();
            }

            public virtual object handle_sys_errno(object args)
            {
                return this.io_handler.errno;
            }

            public virtual object handle_sys_get_cmdline(object args)
            {
                throw new NotImplementedException();
            }

            public virtual object handle_sys_heapinfo(object args)
            {
                throw new NotImplementedException();
            }

            public virtual object handle_sys_exit(object args)
            {
                throw new NotImplementedException();
            }

            public virtual object handle_sys_elapsed(object args)
            {
                throw new NotImplementedException();
            }

            public virtual object handle_sys_tickfreq(object args)
            {
                throw new NotImplementedException();
            }
        }
    }
}
