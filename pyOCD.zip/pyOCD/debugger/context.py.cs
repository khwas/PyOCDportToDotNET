// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2016 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace debug {

    using coresight;
    using System;

    //using CORE_REGISTER = coresight.cortex_m.CORE_REGISTER;

    //using register_name_to_index = coresight.cortex_m.register_name_to_index;

    //using conversion = utility.conversion;

    //using logging;

    using System.Collections.Generic;
    
    public static class context {
        
        public class DebugContext
            {
            internal readonly core.target.Target _core;
            public DebugContext(core.target.Target core) {
                this._core = core;
            }
            
            public core.target.Target core {
                get {
                    return this._core;
                }
            }
            
            public virtual object writeMemory(UInt32 addr, object value, byte transfer_size = 32) {
                return this._core.writeMemory(addr, value, transfer_size);
            }
            
            public virtual object readMemory(UInt32 addr, byte transfer_size = 32, bool now = true) {
                return this._core.readMemory(addr, transfer_size, now);
            }
            
            public virtual object writeBlockMemoryUnaligned8(UInt32 addr, object value) {
                return this._core.writeBlockMemoryUnaligned8(addr, value);
            }
            
            public virtual object writeBlockMemoryAligned32(UInt32 addr, object data) {
                return this._core.writeBlockMemoryAligned32(addr, data);
            }
            
            public virtual List<byte> readBlockMemoryUnaligned8(UInt32 addr, UInt32 size) {
                return this._core.readBlockMemoryUnaligned8(addr, size);
            }
            
            public virtual List<UInt32> readBlockMemoryAligned32(UInt32 addr, UInt32 size) {
                return this._core.readBlockMemoryAligned32(addr, size);
            }
            
            // @brief Shorthand to write a 32-bit word.
            public virtual void write32(UInt32 addr, object value) {
                this.writeMemory(addr, value, 32);
            }
            
            // @brief Shorthand to write a 16-bit halfword.
            public virtual void write16(UInt32 addr, object value) {
                this.writeMemory(addr, value, 16);
            }
            
            // @brief Shorthand to write a byte.
            public virtual void write8(UInt32 addr, object value) {
                this.writeMemory(addr, value, 8);
            }
            
            // @brief Shorthand to read a 32-bit word.
            public virtual object read32(UInt32 addr, bool now = true) {
                return this.readMemory(addr, 32, now);
            }
            
            // @brief Shorthand to read a 16-bit halfword.
            public virtual object read16(UInt32 addr, bool now = true) {
                return this.readMemory(addr, 16, now);
            }
            
            // @brief Shorthand to read a byte.
            public virtual object read8(UInt32 addr, bool now = true) {
                return this.readMemory(addr, 8, now);
            }
            
            // 
            //         read CPU register
            //         Unpack floating point register values
            //         
            public virtual object readCoreRegister(string reg) {
                var regIndex = cortex_m.register_name_to_index(reg);
                var regValue = this.readCoreRegisterRaw(regIndex);
                // Convert int to float.
                if (regIndex >= 64) {
                    regValue = utility.conversion.u32BEToFloat32BE(regValue);
                }
                return regValue;
            }
            
            // 
            //         read a core register (r0 .. r16).
            //         If reg is a string, find the number associated to this register
            //         in the lookup table CORE_REGISTER
            //         
            public virtual object readCoreRegisterRaw(sbyte reg) {
                var vals = this.readCoreRegistersRaw(new List<sbyte> {
                    reg
                });
                return vals[0];
            }
            
            public virtual List<object> readCoreRegistersRaw(List<sbyte> reg_list) {
                return this._core.readCoreRegistersRaw(reg_list);
            }
            
            // 
            //         write a CPU register.
            //         Will need to pack floating point register values before writing.
            //         
            public virtual void writeCoreRegister(string reg, UInt32 data) {
                sbyte regIndex = cortex_m.register_name_to_index(reg);
                // Convert float to int.
                if (regIndex >= 64) {
                    data = utility.conversion.float32beToU32be((float)data);
                }
                this.writeCoreRegisterRaw(regIndex, data);
            }
            
            // 
            //         write a core register (r0 .. r16)
            //         If reg is a string, find the number associated to this register
            //         in the lookup table CORE_REGISTER
            //         
            public virtual void writeCoreRegisterRaw(sbyte reg, UInt32 data) {
                this.writeCoreRegistersRaw(new List<sbyte> {
                    reg
                }, new List<UInt32> {
                    data
                });
            }
            
            public virtual void writeCoreRegistersRaw(List<sbyte> reg_list, List<UInt32> data_list) {
                this._core.writeCoreRegistersRaw(reg_list, data_list);
            }
            
            public virtual void flush() {
                this._core.flush();
            }
        }
    }
}
