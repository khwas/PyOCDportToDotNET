// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace debug
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Xml.Serialization;

    //using threading;

    //using logging;

    using cmsis_svd;

    public static class svd
    {

        public static bool isCmsisSvdAvailable = true;

        // public static object isCmsisSvdAvailable = false;

        public class SVDFile
        {
            internal string filename;
            internal string vendor;
            internal bool is_local;
            internal cmsis_svd.device device;

            public SVDFile(string filename = null, string vendor = null, bool is_local = false)
            {
                this.filename = filename;
                this.vendor = vendor;
                this.is_local = is_local;
                this.device = null;
            }

            public virtual void load()
            {
                if (!isCmsisSvdAvailable)
                {
                    return;
                }
                if (this.is_local)
                {
                    XmlSerializer xs = new XmlSerializer(typeof(cmsis_svd.device));
                    StreamReader sr = new StreamReader(this.filename);
                    this.device = (cmsis_svd.device)xs.Deserialize(sr); // SVDParser.for_xml_file(this.filename).get_device();
                }
                else
                {
                    throw new NotImplementedException();
                    //this.device = SVDParser.for_packaged_svd(this.vendor, this.filename).get_device();
                }
            }
        }

        public class SVDLoader
            //: threading.Thread
        {

            internal bool daemon;
            internal SVDFile _svd_location;
            internal cmsis_svd.device _svd_device;
            internal Action<cmsis_svd.device> _callback;

            public SVDLoader(SVDFile svdFile, Action<cmsis_svd.device> completionCallback)
            {
                this.daemon = true;
                this._svd_location = svdFile;
                this._svd_device = null;
                this._callback = completionCallback;
            }

            public cmsis_svd.device device
            {
                get
                {
                    if (this._svd_device == null)
                    {
                        // this.join(); // Threading
                        run();
                    }
                    return this._svd_device;
                }
            }

            public virtual void load()
            {
                if ((this._svd_device == null) && !String.IsNullOrWhiteSpace(this._svd_location.filename))
                {
                    // this.start(); // Threading
                    throw new NotImplementedException();
                }
            }

            public virtual void run()
            {
                try
                {
                    this._svd_location.load();
                    this._svd_device = this._svd_location.device;
                    if (this._callback != null)
                    {
                        this._callback(this._svd_device);
                    }
                }
                catch // (IOError)
                {
                    Trace.TraceWarning("Failed to load SVD file {0}", this._svd_location.filename);
                }
            }
        }
    }
}
