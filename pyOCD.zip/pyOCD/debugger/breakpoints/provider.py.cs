// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015-2017 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace debug.breakpoints
{

    using Target = core.target.Target;

    using System;
    using System.Collections.Generic;

    public static class provider
    {

        public class Breakpoint
        {
            internal byte type;
            internal bool enabled;
            internal UInt32 addr;
            internal byte func;
            internal UInt16 original_instr;
            internal BreakpointProvider provider;
            public Breakpoint(BreakpointProvider provider)
            {
                this.type = Target.BREAKPOINT_HW;
                this.enabled = false;
                this.addr = 0;
                this.original_instr = 0;
                this.provider = provider;
            }

            public virtual object @__repr__()
            {
                return String.Format("<{0}@0x%{1:X8} type={2} addr=0x{3:X8}>", this.GetType().Name, "?", //id(this), 
                    this.type, this.addr);
            }
        }

        public class BreakpointProvider
        {

            public virtual void init()
            {
                throw new NotImplementedException();
            }

            public virtual byte bp_type()
            {
                return 0;
            }

            public virtual bool do_filter_memory
            {
                get
                {
                    return false;
                }
            }

            public virtual int available_breakpoints()
            {
                throw new NotImplementedException();
            }

            public virtual object find_breakpoint(object addr)
            {
                throw new NotImplementedException();
            }

            public virtual Breakpoint set_breakpoint(object addr)
            {
                throw new NotImplementedException();
            }

            public virtual object remove_breakpoint(object bp)
            {
                throw new NotImplementedException();
            }

            public virtual object filter_memory(UInt32 addr, byte size, object data)
            {
                return data;
            }

            public virtual void flush()
            {
            }
        }
    }
}
