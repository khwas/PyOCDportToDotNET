// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015-2017 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace debug.breakpoints
{

    using Breakpoint = provider.Breakpoint;

    using BreakpointProvider = provider.BreakpointProvider;

    using Target = core.target.Target;

    using pyDAPAccess;

    //using logging;

    using System.Collections.Generic;

    using System.Diagnostics;

    using System;

    public static class software
    {

        public class SoftwareBreakpoint
            : Breakpoint
        {

            public SoftwareBreakpoint(SoftwareBreakpointProvider provider) : base(provider)
            {
                this.type = Target.BREAKPOINT_SW;
            }
        }

        public class SoftwareBreakpointProvider
            : BreakpointProvider
        {

            // BKPT #0 instruction.
            UInt16 BKPT_INSTR = 0xbe00;

            internal readonly Target _core;
            internal readonly Dictionary<UInt32, SoftwareBreakpoint> _breakpoints;

            public SoftwareBreakpointProvider(Target core)
            {
                this._core = core;
                this._breakpoints = new Dictionary<UInt32, SoftwareBreakpoint>()
                {
                };
            }

            public override void init()
            {
            }

            public virtual object bp_type()
            {
                return Target.BREAKPOINT_SW;
            }

            public override bool do_filter_memory
            {
                get
                {
                    return true;
                }
            }

            public override int available_breakpoints()
            {
                return -1;
            }

            public virtual SoftwareBreakpoint find_breakpoint(UInt32 addr)
            {
                return this._breakpoints.ContainsKey(addr) ? this._breakpoints[addr] : null;
            }

            public virtual SoftwareBreakpoint set_breakpoint(UInt32 addr)
            {
                Debug.Assert(this._core.memory_map.getRegionForAddress(addr).isRam);
                Debug.Assert((addr & 1) == 0);
                try
                {
                    // Read original instruction.
                    UInt16 instr = this._core.read16(addr);
                    // Insert BKPT #0 instruction.
                    this._core.write16(addr, this.BKPT_INSTR);
                    // Create bp object.
                    var bp = new SoftwareBreakpoint(this);
                    bp.enabled = true;
                    bp.addr = addr;
                    bp.original_instr = instr;
                    // Save this breakpoint.
                    this._breakpoints[addr] = bp;
                    return bp;
                }
                catch
                {
                    Trace.TraceInformation(String.Format("Failed to set sw bp at 0x%x", addr));
                    return null;
                }
            }

            public virtual void remove_breakpoint(SoftwareBreakpoint bp)
            {
                Debug.Assert(bp != null && bp is Breakpoint);
                try
                {
                    // Restore original instruction.
                    this._core.write16(bp.addr, bp.original_instr);
                    // Remove from our list.
                    this._breakpoints.Remove(bp.addr);
                }
                catch
                {
                    Trace.TraceInformation(String.Format("Failed to remove sw bp at 0x%x", bp.addr));
                }
            }

            public override object filter_memory(UInt32 addr, byte size, object data)
            {
                foreach (var bp in this._breakpoints.Values)
                {
                    if (size == 8)
                    {
                        Debug.Assert(data is Byte);
                        if (bp.addr == addr)
                        {
                            data = bp.original_instr & 0xFF;
                        }
                        else if (bp.addr + 1 == addr)
                        {
                            data = bp.original_instr >> 8;
                        }
                    }
                    else if (size == 16)
                    {
                        Debug.Assert(data is UInt16);
                        if (bp.addr == addr)
                        {
                            data = bp.original_instr;
                        }
                    }
                    else if (size == 32)
                    {
                        Debug.Assert(data is UInt32);
                        if (bp.addr == addr)
                        {
                            data = ((UInt32)data & 0xffff0000) | bp.original_instr;
                        }
                        else if (bp.addr == addr + 2)
                        {
                            data = ((UInt32)data & 0xffff) | (bp.original_instr << 16);
                        }
                    }
                    return data;
                }
                throw new Exception();
            }
        }
    }
}
