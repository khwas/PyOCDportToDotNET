// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015-2017 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace debug.breakpoints
{

    //using Target = core.target.Target;

    //using DAPAccess = pyDAPAccess.DAPAccess;

    //using logging;

    using System.Collections.Generic;

    using System;

    using System.Diagnostics;
    using coresight;
    using System.Linq;

    public static class manager
    {

        public class BreakpointManager
        {

            public byte MIN_HW_BREAKPOINTS = 0;

            private core.target.Target _core;
            private provider.BreakpointProvider _fpb;
            private Dictionary<UInt32, provider.Breakpoint> _breakpoints;
            private Dictionary<byte, provider.BreakpointProvider> _providers;

            public BreakpointManager(core.target.Target core)
            {
                this._breakpoints = new Dictionary<UInt32, provider.Breakpoint>
                {
                };
                this._core = core;
                this._fpb = null;
                this._providers = new Dictionary<byte, provider.BreakpointProvider>
                {
                };
            }

            public virtual void add_provider(provider.BreakpointProvider provider, byte type)
            {
                this._providers[type] = provider;
                if (type == core.target.Target.BREAKPOINT_HW)
                {
                    this._fpb = provider;
                }
            }

            public virtual provider.Breakpoint find_breakpoint(UInt32 addr)
            {
                return this._breakpoints[addr] ?? null;
            }

            // Set a hardware or software breakpoint at a specific location in memory.
            //
            // @retval True Breakpoint was set.
            // @retval False Breakpoint could not be set.
            public virtual bool set_breakpoint(UInt32 addr, byte type = core.target.Target.BREAKPOINT_AUTO)
            {
                Trace.TraceInformation("set bkpt type %d at 0x%x", type, addr);
                // Clear Thumb bit in case it is set.
                addr = (UInt32)(addr & ~1);
                var in_hw_bkpt_range = addr < 0x20000000;
                var fbp_available = this._fpb != null && this._fpb.available_breakpoints() > 0;
                var fbp_below_min = this._fpb == null || this._fpb.available_breakpoints() <= this.MIN_HW_BREAKPOINTS;
                // Check for an existing breakpoint at this address.
                provider.Breakpoint bp = this.find_breakpoint(addr);
                if (bp != null)
                {
                    return true;
                }
                bool is_flash;
                bool is_ram;
                if (this._core.memory_map == null)
                {
                    // No memory map - fallback to hardware breakpoints.
                    type = core.target.Target.BREAKPOINT_HW;
                    is_flash = false;
                    is_ram = false;
                }
                else
                {
                    // Look up the memory type for the requested address.
                    core.memory_map.MemoryRegion region = this._core.memory_map.getRegionForAddress(addr);
                    if (region != null)
                    {
                        is_flash = region.isFlash;
                        is_ram = region.isRam;
                    }
                    else
                    {
                        // No memory region - fallback to hardware breakpoints.
                        type = core.target.Target.BREAKPOINT_HW;
                        is_flash = false;
                        is_ram = false;
                    }
                }
                // Determine best type to use if auto.
                if (type == core.target.Target.BREAKPOINT_AUTO)
                {
                    // Use sw breaks for:
                    //  1. Addresses outside the supported FPBv1 range of 0-0x1fffffff
                    //  2. RAM regions by default.
                    //  3. Number of remaining hw breaks are at or less than the minimum we want to keep.
                    //
                    // Otherwise use hw.
                    if (!in_hw_bkpt_range || is_ram || fbp_below_min)
                    {
                        type = core.target.Target.BREAKPOINT_SW;
                    }
                    else
                    {
                        type = core.target.Target.BREAKPOINT_HW;
                    }
                    Trace.TraceInformation("using type %d for auto bp", type);
                }
                // Revert to sw bp if out of hardware breakpoint range.
                if (type == core.target.Target.BREAKPOINT_HW && !in_hw_bkpt_range)
                {
                    if (is_ram)
                    {
                        Trace.TraceInformation("using sw bp instead because of unsupported addr");
                        type = core.target.Target.BREAKPOINT_SW;
                    }
                    else
                    {
                        Trace.TraceInformation("could not fallback to software breakpoint");
                        return false;
                    }
                }
                // Revert to hw bp if region is flash.
                if (is_flash)
                {
                    if (in_hw_bkpt_range && fbp_available)
                    {
                        Trace.TraceInformation("using hw bp instead because addr is flash");
                        type = core.target.Target.BREAKPOINT_HW;
                    }
                    else
                    {
                        Trace.TraceInformation("could not fallback to hardware breakpoint");
                        return false;
                    }
                }
                // Set the bp.
                try
                {
                    var provider = this._providers[type];
                    bp = provider.set_breakpoint(addr);
                }
                catch (KeyNotFoundException)
                {
                    throw new Exception(String.Format("Unknown breakpoint type %d", type));
                }
                if (bp == null)
                {
                    return false;
                }
                // Save the bp.
                this._breakpoints[addr] = bp;
                return true;
            }

            // Remove a breakpoint at a specific location.
            public virtual void remove_breakpoint(UInt32 addr)
            {
                try
                {
                    Trace.TraceInformation("remove bkpt at 0x%x", addr);
                    // Clear Thumb bit in case it is set.
                    addr = (UInt32)(addr & ~1);
                    // Get bp and remove from dict.
                    provider.Breakpoint bp = this._breakpoints[addr];
                    this._breakpoints.Remove(addr);
                    Debug.Assert(bp.provider != null);
                    bp.provider.remove_breakpoint(bp);
                }
                catch (KeyNotFoundException)
                {
                    Trace.TraceInformation(String.Format("Tried to remove breakpoint 0x%08x that wasn't set", addr));
                }
            }

            public virtual byte? get_breakpoint_type(UInt32 addr)
            {
                provider.Breakpoint bp = this.find_breakpoint(addr);
                return bp != null ? (byte?) bp.type : null;
            }

            public virtual object filter_memory(UInt32 addr, byte transfer_size, object data)
            {
                foreach (var provider in this._providers.Values.Where(p => p.do_filter_memory))
                {
                    data = provider.filter_memory(addr, transfer_size, data);
                }
                return data;
            }

            public virtual List<byte> filter_memory_unaligned_8(UInt32 addr, UInt32 size, List<byte> data)
            {
                Debug.Assert(size == data.Count);
                foreach (var provider in this._providers.Values.Where(p => p.do_filter_memory))
                {
                    foreach (var _tup_1 in data.Select((_p_1, _p_2) => Tuple.Create(_p_2, _p_1)))
                    {
                        var i = _tup_1.Item1;
                        var d = _tup_1.Item2;
                        data[i] = (byte)provider.filter_memory((UInt32)(addr + i), 8, d);
                    }
                }
                return data;
            }

            public virtual List<UInt32> filter_memory_aligned_32(UInt32 addr, UInt32 size, List<UInt32> data)
            {
                Debug.Assert(size == data.Count);
                foreach (var provider in this._providers.Values.Where(p => p.do_filter_memory))
                {
                    foreach (var _tup_1 in data.Select((_p_1, _p_2) => Tuple.Create(_p_2, _p_1)))
                    {
                        var i = _tup_1.Item1;
                        var d = _tup_1.Item2;
                        data[i] = (UInt32)provider.filter_memory((UInt32)(addr + i), 32, d);
                    }
                }
                return data;
            }

            public virtual void remove_all_breakpoints()
            {
                foreach (provider.Breakpoint bp in this._breakpoints.Values)
                {
                    bp.provider.remove_breakpoint(bp);
                }
                this._breakpoints.Clear();
                this._flush_all();
            }

            public virtual void _flush_all()
            {
                // Flush all providers.
                foreach (var provider in this._providers.Values)
                {
                    provider.flush();
                }
            }

            public virtual void flush()
            {
                try
                {
                    // Flush all providers.
                    this._flush_all();
                }
                catch
                {
                }
            }
        }
    }
}
