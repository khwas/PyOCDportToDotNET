// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace flash
{

    using target;

    using FlashBuilder = flash_builder.FlashBuilder;

    using System.Collections.Generic;

    using System.Diagnostics;

    using System;

    public static class flash
    {

        public const double DEFAULT_PAGE_PROGRAM_WEIGHT = 0.13;
        public const double DEFAULT_PAGE_ERASE_WEIGHT = 0.048;
        public const double DEFAULT_CHIP_ERASE_WEIGHT = 0.174;

        // Program to compute the CRC of sectors.  This works on cortex-m processors.
        // Code is relocatable and only needs to be on a 4 byte boundary.
        // 200 bytes of executable data below + 1024 byte crc table = 1224 bytes
        // Usage requirements:
        // -In memory reserve 0x600 for code & table
        // -Make sure data buffer is big enough to hold 4 bytes for each page that could be checked (ie.  >= num pages * 4)
        public static UInt32[] analyzer = new UInt32[]
            {
                0x2180468c, 0x2600b5f0, 0x4f2c2501, 0x447f4c2c, 0x1c2b0049, 0x425b4033, 0x40230872, 0x085a4053,
                0x425b402b, 0x40534023, 0x402b085a, 0x4023425b, 0x085a4053, 0x425b402b, 0x40534023, 0x402b085a,
                0x4023425b, 0x085a4053, 0x425b402b, 0x40534023, 0x402b085a, 0x4023425b, 0x085a4053, 0x425b402b,
                0x40534023, 0xc7083601, 0xd1d2428e, 0x2b004663, 0x4663d01f, 0x46b4009e, 0x24ff2701, 0x44844d11,
                0x1c3a447d, 0x88418803, 0x4351409a, 0xd0122a00, 0x22011856, 0x780b4252, 0x40533101, 0x009b4023,
                0x0a12595b, 0x42b1405a, 0x43d2d1f5, 0x4560c004, 0x2000d1e7, 0x2200bdf0, 0x46c0e7f8, 0x000000b6,
                0xedb88320, 0x00000044,
            };

        public static byte _msb(UInt32 n)
        {
            byte ndx = 0;
            while (1 < n)
            {
                n = n >> 1;
                ndx += 1;
            }
            return ndx;
        }

        public static object _same(List<object> d1, List<object> d2)
        {
            if (d1.Count != d2.Count)
            {
                return false;
            }
            for (int i=0; i<d1.Count; i++)
            {
                if (d1[i] != d2[i])
                {
                    return false;
                }
            }
            return true;
        }

        public class PageInfo
        {
            public bool? crc_supported;
            internal double? erase_weight;
            internal double? program_weight;
            internal UInt32? size;
            internal UInt32? base_addr;

            public PageInfo()
            {
                this.base_addr = null;
                this.erase_weight = null;
                this.program_weight = null;
                this.size = null;
                this.crc_supported = null;
            }
        }

        public class FlashInfo
        {
            public UInt32? rom_start;
            public double? erase_weight;
            public bool? crc_supported;
            public FlashInfo()
            {
                this.rom_start = null;
                this.erase_weight = null;
            }
        }

        // 
        //     This class is responsible to flash a new binary in a target
        //     
        public class Flash
        {

            public readonly core.target.Target target;
            private Dictionary<string, object> flash_algo;
            private bool flash_algo_debug;
            private UInt32? end_flash_algo;
            private UInt32? begin_stack;
            private UInt32? begin_data;
            private UInt32? static_base;
            private UInt32? min_program_length;
            private List<UInt32> page_buffers;
            private bool double_buffer_supported;
            private UInt32 _saved_vector_catch;

            public Flash(core.target.Target target, Dictionary<string, object> flash_algo)
            {
                this.target = target;
                this.flash_algo = flash_algo;
                this.flash_algo_debug = false;
                if (flash_algo != null)
                {
                    this.end_flash_algo = (UInt32)((UInt32)flash_algo["load_address"] + flash_algo.Count * 4);
                    this.begin_stack = (UInt32)flash_algo["begin_stack"];
                    this.begin_data = (UInt32)flash_algo["begin_data"];
                    this.static_base = (UInt32)flash_algo["static_base"];
                    this.min_program_length = flash_algo.ContainsKey("min_program_length")?(UInt32)flash_algo["min_program_length"]: 0;
                    // Check for double buffering support.
                    if (flash_algo.ContainsKey("page_buffers"))
                    {
                        this.page_buffers = (List<UInt32>)flash_algo["page_buffers"];
                    }
                    else
                    {
                        this.page_buffers = new List<UInt32> {
                            (UInt32)this.begin_data
                        };
                    }
                    this.double_buffer_supported = this.page_buffers.Count > 1;
                }
                else
                {
                    this.end_flash_algo = null;
                    this.begin_stack = null;
                    this.begin_data = null;
                    this.static_base = null;
                }
            }

            public object minimumProgramLength
            {
                get
                {
                    return this.min_program_length;
                }
            }

            // 
            //         Download the flash algorithm in RAM
            //         
            public virtual void init()
            {
                this.target.halt();
                this.target.setTargetState("PROGRAM");
                // update core register to execute the init subroutine
                UInt32 result = this.callFunctionAndWait((UInt32)this.flash_algo["pc_init"], init: true);
                // check the return code
                if (result != 0)
                {
                    Trace.TraceError("init error: %i", result);
                }
            }

            public virtual List<UInt32> computeCrcs(IEnumerable<Tuple<UInt32, UInt32>> sectors)
            {
                List<UInt32> data = new List<UInt32>();
                // Convert address, size pairs into commands
                // for the crc computation algorithm to preform
                foreach (var _tup_1 in sectors)
                {
                    var addr = _tup_1.Item1;
                    var size = _tup_1.Item2;
                    byte size_val = _msb(size);
                    UInt32 addr_val = addr / size;
                    // Size must be a power of 2
                    Debug.Assert(1 << size_val == size);
                    // Address must be a multiple of size
                    Debug.Assert(addr % size == 0);
                    UInt32 val = (UInt32)((UInt32)(size_val << 0) | (UInt32)(addr_val << 16));
                    data.Add(val);
                }
                this.target.writeBlockMemoryAligned32(this.begin_data, data);
                // update core register to execute the subroutine
                var result = this.callFunctionAndWait((UInt32)this.flash_algo["analyzer_address"], this.begin_data, (UInt32)data.Count);
                // Read back the CRCs for each section
                data = this.target.readBlockMemoryAligned32((UInt32)this.begin_data, (UInt32)data.Count);
                return data;
            }

            // 
            //         Erase all the flash
            //         
            public virtual void eraseAll()
            {
                // update core register to execute the eraseAll subroutine
                UInt32 result = this.callFunctionAndWait((UInt32)this.flash_algo["pc_eraseAll"]);
                // check the return code
                if (result != 0)
                {
                    Trace.TraceError("eraseAll error: %i", result);
                }
            }

            // 
            //         Erase one page
            //         
            public virtual void erasePage(UInt32 flashPtr)
            {
                // update core register to execute the erasePage subroutine
                UInt32 result = this.callFunctionAndWait((UInt32)this.flash_algo["pc_erase_sector"], flashPtr);
                // check the return code
                if (result != 0)
                {
                    Trace.TraceError("erasePage(0x%x) error: %i", flashPtr, result);
                }
            }

            // 
            //         Flash one page
            //         
            public virtual void programPage(UInt32 flashPtr, List<byte> bytes)
            {
                // prevent security settings from locking the device
                bytes = this.overrideSecurityBits(flashPtr, bytes);
                // first transfer in RAM
                this.target.writeBlockMemoryUnaligned8(this.begin_data, bytes);
                // get info about this page
                var page_info = this.getPageInfo(flashPtr);
                // update core register to execute the program_page subroutine
                UInt32 result = this.callFunctionAndWait((UInt32)this.flash_algo["pc_program_page"], flashPtr, (UInt32)bytes.Count, this.begin_data);
                // check the return code
                if (result != 0)
                {
                    Trace.TraceError("programPage(0x%x) error: %i", flashPtr, result);
                }
            }

            public virtual UInt32 getPageBufferCount()
            {
                return (UInt32)this.page_buffers.Count;
            }

            public virtual bool isDoubleBufferingSupported()
            {
                return this.double_buffer_supported;
            }

            // 
            //         Flash one page
            //         
            public virtual void startProgramPageWithBuffer(UInt32 bufferNumber, UInt32 flashPtr)
            {
                Debug.Assert(bufferNumber < this.page_buffers.Count, "Invalid buffer number");
                // get info about this page
                var page_info = this.getPageInfo(flashPtr);
                // update core register to execute the program_page subroutine
                //var result = 
                this.callFunction((UInt32)this.flash_algo["pc_program_page"], flashPtr, page_info.size, this.page_buffers[(int)bufferNumber]);
            }

            public virtual void loadPageBuffer(UInt32 bufferNumber, UInt32 flashPtr, List<byte> bytes)
            {
                Debug.Assert(bufferNumber < this.page_buffers.Count, "Invalid buffer number");
                // prevent security settings from locking the device
                bytes = this.overrideSecurityBits(flashPtr, bytes);
                // transfer the buffer to device RAM
                this.target.writeBlockMemoryUnaligned8(this.page_buffers[(int)bufferNumber], bytes);
            }

            // 
            //         Flash a portion of a page.
            //         
            public virtual void programPhrase(UInt32 flashPtr, List<byte> bytes)
            {
                UInt32 min_len;
                // Get min programming length. If one was not specified, use the page size.
                if (this.min_program_length != null)
                {
                    min_len = (UInt32)this.min_program_length;
                }
                else
                {
                    min_len = (UInt32)(this.getPageInfo(flashPtr).size);
                }
                // Require write address and length to be aligned to min write size.
                if (flashPtr % min_len != 0)
                {
                    throw new Exception("unaligned flash write address");
                }
                if (bytes.Count % min_len != 0)
                {
                    throw new Exception("phrase length is unaligned or too small");
                }
                // prevent security settings from locking the device
                bytes = this.overrideSecurityBits(flashPtr, bytes);
                // first transfer in RAM
                this.target.writeBlockMemoryUnaligned8(this.begin_data, bytes);
                // update core register to execute the program_page subroutine
                UInt32 result = this.callFunctionAndWait((UInt32)this.flash_algo["pc_program_page"], flashPtr, (UInt32)bytes.Count, this.begin_data);
                // check the return code
                if (result != 0)
                {
                    Trace.TraceError("programPhrase(0x%x) error: %i", flashPtr, result);
                }
            }

            // 
            //         Get info about the page that contains this address
            // 
            //         Override this function if variable page sizes are supported
            //         
            public virtual PageInfo getPageInfo(UInt32 addr)
            {
                core.memory_map.MemoryRegion region = this.target.getMemoryMap().getRegionForAddress(addr);
                if (region == null)
                {
                    return null;
                }
                PageInfo info = new PageInfo();
                info.erase_weight = DEFAULT_PAGE_ERASE_WEIGHT;
                info.program_weight = DEFAULT_PAGE_PROGRAM_WEIGHT;
                info.size = region.blocksize;
                info.base_addr = addr - addr % info.size;
                return info;
            }

            // 
            //         Get info about the flash
            // 
            //         Override this function to return differnt values
            //         
            public virtual FlashInfo getFlashInfo()
            {
                core.memory_map.MemoryRegion boot_region = this.target.getMemoryMap().getBootMemory();
                FlashInfo info = new FlashInfo();
                info.rom_start = boot_region != null ? boot_region.start : 0;
                info.erase_weight = DEFAULT_CHIP_ERASE_WEIGHT;
                info.crc_supported = (bool)this.flash_algo["analyzer_supported"];
                return info;
            }

            public virtual FlashBuilder getFlashBuilder()
            {
                return new FlashBuilder(this, (UInt32)this.getFlashInfo().rom_start);
            }

            // 
            //         Flash a block of data
            //         
            public virtual object flashBlock(
                UInt32 addr,
                List<byte> data,
                bool smart_flash = true,
                bool? chip_erase = null,
                Action<double> progress_cb = null,
                bool fast_verify = false)
            {
                UInt32 flash_start = (UInt32)this.getFlashInfo().rom_start;
                FlashBuilder fb = new FlashBuilder(this, flash_start);
                fb.addData(addr, data);
                var info = fb.program(chip_erase, progress_cb, smart_flash, fast_verify);
                return info;
            }

            // 
            //         Flash a binary
            //         
            public virtual void flashBinary(
                string path_file,
                UInt32? flashPtr = null,
                bool smart_flash = true,
                object chip_erase = null,
                object progress_cb = null,
                bool fast_verify = false)
            {
                if (flashPtr == null)
                {
                    flashPtr = this.getFlashInfo().rom_start;
                }
                var f = open(path_file, "rb");
                using (var f = open(path_file, "rb"))
                {
                    data = f.read();
                }
                var data = unpack(str(data.Count) + "B", data);
                this.flashBlock(flashPtr, data, smart_flash, chip_erase, progress_cb, fast_verify);
            }

            public virtual void callFunction(
                UInt32 pc,
                UInt32? r0 = null,
                UInt32? r1 = null,
                UInt32? r2 = null,
                UInt32? r3 = null,
                bool init = false)
            {
                List<string> reg_list = new List<string>();
                List<UInt32> data_list = new List<UInt32>();
                if (this.flash_algo_debug)
                {
                    // Save vector catch state for use in waitForCompletion()
                    this._saved_vector_catch = this.target.getVectorCatch();
                    this.target.setVectorCatch(core.target.Target.CATCH_ALL);
                }
                if (init)
                {
                    // download flash algo in RAM
                    this.target.writeBlockMemoryAligned32(this.flash_algo["load_address"], this.flash_algo["instructions"]);
                    if ((bool)this.flash_algo["analyzer_supported"])
                    {
                        this.target.writeBlockMemoryAligned32(this.flash_algo["analyzer_address"], analyzer);
                    }
                }
                reg_list.Add("pc");
                data_list.Add(pc);
                if (r0 != null)
                {
                    reg_list.Add("r0");
                    data_list.Add((UInt32)r0);
                }
                if (r1 != null)
                {
                    reg_list.Add("r1");
                    data_list.Add((UInt32)r1);
                }
                if (r2 != null)
                {
                    reg_list.Add("r2");
                    data_list.Add((UInt32)r2);
                }
                if (r3 != null)
                {
                    reg_list.Add("r3");
                    data_list.Add((UInt32)r3);
                }
                if (init)
                {
                    reg_list.Add("r9");
                    data_list.Add((UInt32)this.static_base);
                }
                if (init)
                {
                    reg_list.Add("sp");
                    data_list.Add((UInt32)this.begin_stack);
                }
                reg_list.Add("lr");
                data_list.Add((UInt32)this.flash_algo["load_address"] + 1);
                this.target.writeCoreRegistersRaw(reg_list, data_list);
                // resume target
                this.target.resume();
            }

            // Wait until the breakpoint is hit.
            public virtual UInt32 waitForCompletion()
            {
                while (this.target.getState() == core.target.Target.TARGET_RUNNING)
                {
                }
                if (this.flash_algo_debug)
                {
                    bool analyzer_supported = (bool)this.flash_algo["analyzer_supported"];
                    UInt32 expected_fp = (UInt32)this.flash_algo["static_base"];
                    UInt32 expected_sp = (UInt32)this.flash_algo["begin_stack"];
                    UInt32 expected_pc = (UInt32)this.flash_algo["load_address"];
                    var expected_flash_algo = this.flash_algo["instructions"];
                    if (analyzer_supported)
                    {
                        var expected_analyzer = analyzer;
                    }
                    var final_fp = this.target.readCoreRegister("r9");
                    var final_sp = this.target.readCoreRegister("sp");
                    var final_pc = this.target.readCoreRegister("pc");
                    //TODO - uncomment if Read/write and zero init sections can be moved into a separate flash algo section
                    //final_flash_algo = self.target.readBlockMemoryAligned32(self.flash_algo['load_address'], len(self.flash_algo['instructions']))
                    //if analyzer_supported:
                    //    final_analyzer = self.target.readBlockMemoryAligned32(self.flash_algo['analyzer_address'], len(analyzer))
                    var error = false;
                    if (final_fp != expected_fp)
                    {
                        // Frame pointer should not change
                        Trace.TraceError(String.Format("Frame pointer should be 0x%x but is 0x%x", expected_fp, final_fp));
                        error = true;
                    }
                    if (final_sp != expected_sp)
                    {
                        // Stack pointer should return to original value after function call
                        Trace.TraceError(String.Format("Stack pointer should be 0x%x but is 0x%x", expected_sp, final_sp));
                        error = true;
                    }
                    if (final_pc != expected_pc)
                    {
                        // PC should be pointing to breakpoint address
                        Trace.TraceError(String.Format("PC should be 0x%x but is 0x%x", expected_pc, final_pc));
                        error = true;
                    }
                    //TODO - uncomment if Read/write and zero init sections can be moved into a separate flash algo section
                    //if not _same(expected_flash_algo, final_flash_algo):
                    //    Trace.TraceError("Flash algorithm overwritten!")
                    //    error = True
                    //if analyzer_supported and not _same(expected_analyzer, final_analyzer):
                    //    Trace.TraceError("Analyzer overwritten!")
                    //    error = True
                    Debug.Assert(error == false);
                    this.target.setVectorCatch(this._saved_vector_catch);
                }
                return this.target.readCoreRegister("r0");
            }

            public virtual UInt32 callFunctionAndWait(
                UInt32 pc,
                UInt32? r0 = null,
                UInt32? r1 = null,
                UInt32? r2 = null,
                UInt32? r3 = null,
                bool init = false)
            {
                this.callFunction(pc, r0, r1, r2, r3, init);
                return this.waitForCompletion();
            }

            // 
            //         Turn on extra flash algorithm checking
            // 
            //         When set this will greatly slow down flash algo performance
            //         
            public virtual void setFlashAlgoDebug(bool enable)
            {
                this.flash_algo_debug = enable;
            }

            public virtual List<byte> overrideSecurityBits(UInt32 flashPtr, List<byte> data)
            {
                return data;
            }
        }
    }
}
