// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace board
{

    using target;

    //using TARGET = target.TARGET;

    //using FLASH = target.FLASH;

    //using logging;

    //using traceback;
    using System;
    using System.Diagnostics;

    public static class board
    {

        // 
        //     This class associates a target, a flash and a link to create a board
        //     
        public class Board
        {
            internal pyDAPAccess.dap_access_api.DAPAccessIntf link;
            internal core.target.Target target;
            internal flash.flash.Flash flash;
            internal bool closed;
            internal UInt32 debug_clock_frequency;

            public Board(string target, pyDAPAccess.dap_access_api.DAPAccessIntf link, UInt32 frequency = 1000000)
            {
                this.link = link;
                Type tagetType = init_.TARGET[target.ToLower()];
                this.target = (core.target.Target)Activator.CreateInstance(tagetType, this.link);
                Type flashType = init_.FLASH[target.ToLower()];
                this.flash = (flash.flash.Flash)Activator.CreateInstance(flashType, this.target);
                this.target.setFlash(this.flash);
                this.debug_clock_frequency = frequency;
                this.closed = false;
                return;
            }

            public virtual object @__enter__()
            {
                return this;
            }

            public virtual object @__exit__(object type, object value, object traceback)
            {
                this.uninit();
                return false;
            }

            // 
            //         Initialize the board
            //         
            public virtual void init()
            {
                Trace.TraceInformation("init board {0}", this);
                this.link.set_clock(this.debug_clock_frequency);
                this.link.set_deferred_transfer(true);
                this.target.init();
            }

            // 
            //         Uninitialize the board: link and target.
            //         This function resumes the target
            //         
            public virtual void uninit(bool resume = true)
            {
                if (this.closed)
                {
                    return;
                }
                this.closed = true;
                Trace.TraceInformation("uninit board %s", this);
                if (resume)
                {
                    try
                    {
                        this.target.resume();
                    }
                    catch (Exception e)
                    {
                        Trace.TraceError("target exception during uninit:");
                        Trace.TraceError(e.StackTrace);
                    }
                }
                try
                {
                    this.target.disconnect();
                }
                catch (Exception e)
                {
                    Trace.TraceError("link exception during target disconnect:");
                    Trace.TraceError(e.StackTrace);
                }
                try
                {
                    this.link.disconnect();
                }
                catch (Exception e)
                {
                    Trace.TraceError("link exception during link disconnect:");
                    Trace.TraceError(e.StackTrace);
                }
                try
                {
                    this.link.close();
                }
                catch (Exception e)
                {
                    Trace.TraceError("link exception during uninit:");
                    Trace.TraceError(e.StackTrace);
                }
            }

            public virtual string getInfo()
            {
                return "";
            }
        }
    }
}
