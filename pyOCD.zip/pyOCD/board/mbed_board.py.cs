// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace board
{

    //using sys;

    //using os;

    //using logging;

    //using array;

    //using sleep = time.sleep;

    //using board;

    //using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    using pyDAPAccess;

    using System.Collections.Generic;

    using System;

    using System.Diagnostics;
    using System.Threading;

    public static class mbed_board
    {

        public class BoardInfo
        {
            public string name { get; private set; }
            public string target { get; private set; }
            public string binary { get; private set; }

            public BoardInfo(string name, string target, string binary)
            {
                this.name = name;
                this.target = target;
                this.binary = binary;
            }
        }

        public static Dictionary<string, BoardInfo> BOARD_ID_TO_INFO = new Dictionary<string, BoardInfo>()
        {
{"0200", new BoardInfo(  "FRDM-KL25Z",           "kl25z",            "l1_kl25z.bin"         )},
{"0201", new BoardInfo(  "FRDM-KW41Z",           "kw41z4",           "l1_kw41z4.bin"        )},
{"0202", new BoardInfo(  "USB-KW41Z",            "kw41z4",           "l1_kw41z4.bin"        )},
{"0203", new BoardInfo(  "TWR-KL28Z72M",         "kl28z",            "l1_kl28z.bin"         )},
{"0204", new BoardInfo(  "FRDM-KL02Z",           "kl02z",            "l1_kl02z.bin"         )},
{"0205", new BoardInfo(  "FRDM-KL28Z",           "kl28z",            "l1_kl28z.bin"         )},
{"0215", new BoardInfo(  "FRDM-KL28ZEM",         "kl28z",            "l1_kl28z.bin"         )},
{"0206", new BoardInfo(  "TWR-KE18F",            "ke18f16",          "l1_ke18f16.bin"       )},
{"0210", new BoardInfo(  "FRDM-KL05Z",           "kl05z",            "l1_kl05z.bin"         )},
{"0213", new BoardInfo(  "FRDM-KE15Z",           "ke15z7",           "l1_ke15z7.bin"        )},
{"0214", new BoardInfo(  "Hexiwear",             "k64f",             "l1_k64f.bin"          )},
{"0216", new BoardInfo(  "HVP-KE18F",            "ke18f16",          "l1_ke18f16.bin"       )},
{"0217", new BoardInfo(  "FRDM-K82F",            "k82f25615",        "l1_k82f.bin"          )},
{"0218", new BoardInfo(  "FRDM-KL82Z",           "kl82z7",           "l1_kl82z.bin"         )},
{"0220", new BoardInfo(  "FRDM-KL46Z",           "kl46z",            "l1_kl46z.bin"         )},
{"0224", new BoardInfo(  "FRDM-K28F",            "k28f15",           "l1_k28f.bin"          )},
{"0230", new BoardInfo(  "FRDM-K20D50M",         "k20d50m",          "l1_k20d50m.bin"       )},
{"0231", new BoardInfo(  "FRDM-K22F",            "k22f",             "l1_k22f.bin"          )},
{"0240", new BoardInfo(  "FRDM-K64F",            "k64f",             "l1_k64f.bin"          )},
{"0260", new BoardInfo(  "FRDM-KL26Z",           "kl26z",            "l1_kl26z.bin"         )},
{"0261", new BoardInfo(  "FRDM-KL27Z",           "kl27z4",           "l1_kl27z.bin"         )},
{"0262", new BoardInfo(  "FRDM-KL43Z",           "kl43z4",           "l1_kl26z.bin"         )},
{"0290", new BoardInfo(  "FRDM-KW40Z",           "kw40z4",           "l1_kw40z.bin"         )},
{"0298", new BoardInfo(  "FRDM-KV10Z",           "kv10z7",           "l1_kl25z.bin"         )},
{"0300", new BoardInfo(  "TWR-KV11Z75M",         "kv11z7",           "l1_kl25z.bin"         )},
{"0311", new BoardInfo(  "FRDM-K66F",            "k66f18",           "l1_k66f.bin"          )},
{"0320", new BoardInfo(  "FRDM-KW01Z9032",       "kw01z4",           "l1_kl26z.bin"         )},
{"0321", new BoardInfo(  "USB-KW01Z",            "kw01z4",           "l1_kl25z.bin"         )},
{"0324", new BoardInfo(  "USB-KW40Z",            "kw40z4",           "l1_kl25z.bin"         )},
{"0400", new BoardInfo(  "maxwsnenv",            "maxwsnenv",        "l1_maxwsnenv.bin"     )},
{"0405", new BoardInfo(  "max32600mbed",         "max32600mbed",     "l1_max32600mbed.bin"  )},
{"0824", new BoardInfo(  "LPCXpresso824-MAX",    "lpc824",           "l1_lpc824.bin"        )},
{"1054", new BoardInfo(  "LPCXpresso54114-MAX",  "lpc54114",         "l1_lpc54114.bin"      )},
{"1010", new BoardInfo(  "mbed NXP LPC1768",     "lpc1768",          "l1_lpc1768.bin"       )},
{"1017", new BoardInfo(  "mbed HRM1017",         "nrf51",            "l1_nrf51.bin"         )},
{"1018", new BoardInfo(  "Switch-Science-mbed-LPC824", "lpc824",     "l1_lpc824.bin"        )},
{"1019", new BoardInfo(  "mbed TY51822r3",       "nrf51",            "l1_nrf51.bin"         )},
{"1040", new BoardInfo(  "mbed NXP LPC11U24",    "lpc11u24",         "l1_lpc11u24.bin"      )},
{"1050", new BoardInfo(  "NXP LPC800-MAX",       "lpc800",           "l1_lpc800.bin"        )},
{"1060", new BoardInfo(  "EA-LPC4088",           "lpc4088qsb",       "l1_lpc4088qsb.bin"    )},
{"1062", new BoardInfo(  "EA-LPC4088-Display-Module", "lpc4088dm",   "l1_lpc4088dm.bin"     )},
{"1070", new BoardInfo(  "nRF51822-mKIT",        "nrf51",            "l1_nrf51.bin"         )},
{"1080", new BoardInfo(  "DT01 + MB2001",        "stm32f103rc",      "l1_stm32f103rc.bin"   )},
{"1090", new BoardInfo(  "DT01 + MB00xx",        "stm32f051",        "l1_stm32f051.bin"     )},
{"1090", new BoardInfo(  "RedBearLab-nRF51822",  "nrf51",            "l1_nrf51.bin"         )},
{"1095", new BoardInfo(  "RedBearLab-BLE-Nano",  "nrf51",            "l1_nrf51.bin"         )},
{"1100", new BoardInfo(  "nRF51-DK",             "nrf51",            "l1_nrf51-dk.bin"      )},
{"1101", new BoardInfo(  "nRF52-DK",             "nrf52",            "l1_nrf52-dk.bin"      )},
{"1200", new BoardInfo(  "NCS36510-EVK",         "ncs36510",         "l1_ncs36510-evk.bin"  )},
{"1114", new BoardInfo(  "mbed LPC1114FN28",     "lpc11xx_32",      "l1_mbed_LPC1114FN28.bin")},
{"1120", new BoardInfo(  "nRF51-Dongle",         "nrf51",            "l1_nrf51.bin"         )},
{"1234", new BoardInfo(  "u-blox-C027",          "lpc1768",          "l1_lpc1768.bin"       )},
{"1600", new BoardInfo(  "Bambino 210",          "lpc4330",          "l1_lpc4330.bin"       )},
{"1605", new BoardInfo(  "Bambino 210E",         "lpc4330",          "l1_lpc4330.bin"       )},
{"2201", new BoardInfo(  "WIZwik_W7500",         "w7500",            "l1_w7500mbed.bin"     )},
{"4600", new BoardInfo(  "Realtek RTL8195AM",    "rtl8195am",        "l1_rtl8195am.bin"     )},
{"7402", new BoardInfo(  "mbed 6LoWPAN Border Router HAT", "k64f",   "l1_k64f.bin"          )},
{"9004", new BoardInfo(  "Arch Pro",             "lpc1768",          "l1_lpc1768.bin"       )},
{"9009", new BoardInfo(  "Arch BLE",             "nrf51",            "l1_nrf51.bin"         )},
{"9012", new BoardInfo(  "Seeed Tiny BLE",       "nrf51",            "l1_nrf51.bin"         )},
{"9900", new BoardInfo(  "Microbit",             "nrf51",            "l1_microbit.bin"      )},
{"C004", new BoardInfo(  "tinyK20",              "k20d50m",          "l1_k20d50m.bin"       )},
{"C006", new BoardInfo(  "VBLUno51",             "nrf51",            "l1_nrf51.bin"         )},
        };

        public static UInt16 mbed_vid = 0x0d28;
        public static UInt16 mbed_pid = 0x0204;

        // 
        //     This class inherits from Board and is specific to mbed boards.
        //     Particularly, this class allows you to dynamically determine
        //     the type of all boards connected based on the id board
        //     
        public class MbedBoard
            : board.Board
        {
            internal string native_target;
            internal object test_binary;
            internal string name;
            internal string target_type;
            internal string unique_id;

            public MbedBoard(dap_access_api.DAPAccessIntf link, string target = null, UInt32 frequency = 1000000)
                : base(target, link, frequency)
            {
                this.native_target = null;
                this.test_binary = null;
                string unique_id = link.get_unique_id();
                var board_id = unique_id.Substring(0, 4);
                this.name = "Unknown Board";
                if (BOARD_ID_TO_INFO.ContainsKey(board_id))
                {
                    BoardInfo board_info = BOARD_ID_TO_INFO[board_id];
                    this.name = board_info.name;
                    this.native_target = board_info.target;
                    this.test_binary = board_info.binary;
                }
                // Unless overridden use the native target
                if (target == null)
                {
                    target = this.native_target;
                }
                if (target == null)
                {
                    Trace.TraceWarning("Unsupported board found %s", board_id);
                    target = "cortex_m";
                }
                ;
                this.unique_id = unique_id;
                this.target_type = target;
            }

            // 
            //         Return the unique id of the board
            //         
            public virtual object getUniqueID()
            {
                return this.unique_id;
            }

            // 
            //         Return the type of the board
            //         
            public virtual object getTargetType()
            {
                return this.target_type;
            }

            // 
            //         Return name of test binary file
            //         
            public virtual object getTestBinary()
            {
                return this.test_binary;
            }

            // 
            //         Return board name
            //         
            public virtual string getBoardName()
            {
                return this.name;
            }

            // 
            //         Return info on the board
            //         
            public override string getInfo()
            {
                return this.name + " [" + this.target_type + "]";
            }

            // 
            //         List the connected board info
            //         
            // [staticmethod]
            public static void listConnectedBoards(Type dap_class = null)
            {
                dap_class = dap_class ?? pyDAPAccess.@__init__.DAPAccess;
                List<MbedBoard> all_mbeds = MbedBoard.getAllConnectedBoards(dap_class, close: true, blocking: false);
                var index = 0;
                if (all_mbeds.Count > 0)
                {
                    foreach (var mbed in all_mbeds)
                    {
                        Console.WriteLine(String.Format("{0} => {1} boardId => {2}", 
                            index, 
                            mbed.getInfo(), //.encode("ascii", "ignore"), 
                            mbed.unique_id));
                        index += 1;
                    }
                }
                else
                {
                    Console.WriteLine("No available boards are connected");
                }
            }

            // 
            //         Return an array of all mbed boards connected
            //         
            // [staticmethod]
            public static List<MbedBoard> getAllConnectedBoards(
                Type dap_class = null,
                bool close = false,
                bool blocking = true,
                string target_override = null,
                UInt32 frequency = 1000000)
            {
                dap_class = dap_class ?? pyDAPAccess.@__init__.DAPAccess;
                List<MbedBoard> mbed_list = new List<MbedBoard>();
                while (true)
                {
                    Debug.Assert(dap_class.Equals(typeof(dap_access_cmsis_dap.DAPAccessCMSISDAP)));
                    var connected_daps = dap_access_cmsis_dap.DAPAccessCMSISDAP.get_connected_devices();
                    foreach (var dap_access in connected_daps)
                    {
                        MbedBoard new_mbed = new MbedBoard(dap_access, target_override, frequency);
                        mbed_list.Add(new_mbed);
                    }
                    //TODO - handle exception on open
                    if (!close)
                    {
                        foreach (var dap_access in connected_daps)
                        {
                            dap_access.open();
                        }
                    }
                    if (!blocking)
                    {
                        break;
                    }
                    else if (mbed_list.Count > 0)
                    {
                        break;
                    }
                    else
                    {
                        Thread.Sleep(10);
                    }
                    Debug.Assert(mbed_list.Count == 0);
                }
                return mbed_list;
            }

            // 
            //         Allow you to select a board among all boards connected
            //         
            // [staticmethod]
            public static object chooseBoard(
                Type dap_class = null,
                bool blocking = true,
                bool return_first = false,
                string board_id = null,
                string target_override = null,
                UInt32 frequency = 1000000,
                bool init_board = true)
            {
                dap_class = dap_class ?? pyDAPAccess.@__init__.DAPAccess;
                List<MbedBoard> all_mbeds = MbedBoard.getAllConnectedBoards(dap_class, true, blocking, target_override, frequency);
                // If a board ID is specified remove all other boards
                if (board_id != null)
                {
                    List<MbedBoard> new_mbed_list = new List<MbedBoard>();
                    foreach (MbedBoard mbb in all_mbeds)
                    {
                        if (mbb.unique_id == board_id)
                        {
                            new_mbed_list.Add(mbb);
                        }
                    }
                    Debug.Assert(new_mbed_list.Count <= 1);
                    all_mbeds = new_mbed_list;
                }
                // Return if no boards are connected
                if (all_mbeds == null || all_mbeds.Count <= 0)
                {
                    if (board_id == null)
                    {
                        Console.WriteLine("No connected boards");
                    }
                    else
                    {
                        Console.WriteLine(String.Format("Board %s is not connected", board_id));
                    }
                    return null;
                }
                // Select first board
                if (return_first)
                {
                    all_mbeds = all_mbeds.GetRange(0,1);
                }
                // Ask use to select boards if there is more than 1 left
                if (all_mbeds.Count > 1)
                {
                    var index = 0;
                    Console.WriteLine("id => usbinfo | boardname");
                    foreach (MbedBoard mbb in all_mbeds)
                    {
                        Console.WriteLine(String.Format("{0} => {1}", index, mbb.getInfo())); //.encode("ascii", "ignore")));
                        index += 1;
                    }
                    int ch = 0;
                    while (true)
                    {
                        Console.WriteLine("input id num to choice your board want to connect");
                        string line = Console.ReadLine();
                        var valid = false;
                        try
                        {
                            ch = Convert.ToInt32(line);
                            valid = (0 <= ch) && (ch < all_mbeds.Count);
                        }
                        catch (FormatException)
                        {
                        }
                        if (!valid)
                        {
                            Trace.TraceInformation("BAD CHOICE: {0}", line);
                            index = 0;
                            foreach (MbedBoard mbb in all_mbeds)
                            {
                                Console.WriteLine(String.Format("{0} => {1}", index, mbb.getInfo()));
                                index += 1;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    all_mbeds = new List<MbedBoard>() { all_mbeds[ch] };
                }
                Debug.Assert(all_mbeds.Count == 1);
                var mbed = all_mbeds[0];
                mbed.link.open();
                if (init_board)
                {
                    try
                    {
                        mbed.init();
                    }
                    catch
                    {
                        mbed.link.close();
                        throw;
                    }
                }
                return mbed;
            }
        }
    }
}
