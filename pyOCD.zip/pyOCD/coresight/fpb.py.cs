// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015-2017 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace coresight {
    
    using Target = core.target.Target;
    
    using Breakpoint = debug.breakpoints.provider.Breakpoint;
    
    using BreakpointProvider = debug.breakpoints.provider.BreakpointProvider;
    
    using System.Collections.Generic;
    using System;
    using System.Diagnostics;
    using static coresight.ap;

    public static class fpb {
        
        public class HardwareBreakpoint
            : Breakpoint {

            internal readonly UInt32 comp_register_addr;

            public HardwareBreakpoint(UInt32 comp_register_addr, BreakpointProvider provider): base(provider) {
                this.comp_register_addr = comp_register_addr;
                this.type = Target.BREAKPOINT_HW;
            }
        }
        
        public class FPB: BreakpointProvider {

            public const UInt32 FP_CTRL = 0xE0002000;
            public const byte FP_CTRL_KEY = 1 << 1;
            public const UInt32 FP_COMP0 = 0xE0002008;

            internal List<HardwareBreakpoint> hw_breakpoints;
            internal bool enabled;
            internal MEM_AP ap;
            internal int num_hw_breakpoint_used;

            public FPB(MEM_AP ap) {
                this.ap = ap;
                this.hw_breakpoints = new List<HardwareBreakpoint>();
                this.nb_code = 0;
                this.nb_lit = 0;
                this.num_hw_breakpoint_used = 0;
                this.enabled = false;
            }
            
            // Inits the FPB.
            //
            // Reads the number of hardware breakpoints available on the core and disable the FPB
            // (Flash Patch and Breakpoint Unit), which will be enabled when the first breakpoint is set.
            public override void init() {
                // setup FPB (breakpoint)
                UInt32 fpcr = this.ap.readMemory(FPB.FP_CTRL);
                this.nb_code = ((fpcr >> 8) & 0x70) | ((fpcr >> 4) & 0xF);
                this.nb_lit = (fpcr >> 7) & 0xf;
                    Trace.TraceInformation("%d hardware breakpoints, %d literal comparators", this.nb_code, this.nb_lit);
                foreach (var i in range(this.nb_code)) {
                    this.hw_breakpoints.Add(new HardwareBreakpoint(FPB.FP_COMP0 + 4 * i, this));
                }
                // disable FPB (will be enabled on first bp set)
                this.disable();
                foreach (var bp in this.hw_breakpoints) {
                    this.ap.writeMemory(bp.comp_register_addr, 0);
                }
            }
            
            public override byte bp_type() {
                return Target.BREAKPOINT_HW;
            }
            
            public virtual void enable() {
                this.ap.writeMemory(FPB.FP_CTRL, FPB.FP_CTRL_KEY | 1);
                this.enabled = true;
                Trace.TraceInformation("fpb has been enabled");
                return;
            }
            
            public virtual void disable() {
                this.ap.writeMemory(FPB.FP_CTRL, FPB.FP_CTRL_KEY | 0);
                this.enabled = false;
                Trace.TraceInformation("fpb has been disabled");
                return;
            }
            
            public override int available_breakpoints() {
                return this.hw_breakpoints.Count - this.num_hw_breakpoint_used;
            }
            
            // Set a hardware breakpoint at a specific location in flash.
            public virtual HardwareBreakpoint set_breakpoint(UInt32 addr) {
                if (!this.enabled) {
                    this.enable();
                }
                if (addr >= 0x20000000) {
                    // Hardware breakpoints are only supported in the range
                    // 0x00000000 - 0x1fffffff on cortex-m devices
                    Trace.TraceError("Breakpoint out of range 0x%X", addr);
                    return null;
                }
                if (this.available_breakpoints() == 0) {
                    Trace.TraceError("No more available breakpoint!!, dropped bp at 0x%X", addr);
                    return null;
                }
                foreach (HardwareBreakpoint bp in this.hw_breakpoints) {
                    if (!bp.enabled) {
                        bp.enabled = true;
                        UInt32 bp_match = 1 << 30;
                        if ((addr & 2) != 0) {
                            bp_match = (UInt32)2 << 30;
                        }
                        this.ap.writeMemory(bp.comp_register_addr, addr & 0x1ffffffc | bp_match | 1);
                        bp.addr = addr;
                        this.num_hw_breakpoint_used += 1;
                        return bp;
                    }
                }
                return null;
            }
            
            // Remove a hardware breakpoint at a specific location in flash.
            public virtual void remove_breakpoint(HardwareBreakpoint bp) {
                foreach (var hwbp in this.hw_breakpoints) {
                    if (hwbp.enabled && hwbp.addr == bp.addr) {
                        hwbp.enabled = false;
                        this.ap.writeMemory(hwbp.comp_register_addr, 0);
                        this.num_hw_breakpoint_used -= 1;
                        return;
                    }
                }
            }
        }
    }
}
