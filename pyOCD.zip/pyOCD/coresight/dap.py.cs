// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace coresight
{

    using pyDAPAccess;

    //using logging;

    //using logging.handlers;

    //using os;

    //using os.path;

    //using six;

    using System.Collections.Generic;

    using System.Diagnostics;
    using System;
    //using static pyDAPAccess.dap_access_api;

    public static class dap
    {

        public static Dictionary<string, dap_access_api.DAPAccessIntf.REG> DP_REG = new Dictionary<string, dap_access_api.DAPAccessIntf.REG>()
        {
            {"IDCODE", dap_access_api.DAPAccessIntf.REG.DP_0x0},
            {"ABORT", dap_access_api.DAPAccessIntf.REG.DP_0x0},
            {"CTRL_STAT", dap_access_api.DAPAccessIntf.REG.DP_0x4},
            {"SELECT", dap_access_api.DAPAccessIntf.REG.DP_0x8}}
        ;

        public static Dictionary<string, byte> AP_REG = new Dictionary<string, byte>()
        {
            {"CSW", 0},
            {"TAR", 4},
            {"DRW", 12},
            {"IDR", 252}
        };

        public const byte CTRLSTAT_STICKYORUN = 2;
        public const byte CTRLSTAT_STICKYCMP = 16;
        public const byte CTRLSTAT_STICKYERR = 32;
        public const byte IDCODE = 0 << 2;
        public const byte AP_ACC = 1 << 0;
        public const byte DP_ACC = 0 << 0;
        public const byte READ = 1 << 1;
        public const byte WRITE = 0 << 1;
        public const byte VALUE_MATCH = 1 << 4;
        public const byte MATCH_MASK = 1 << 5;
        public const int A32 = 12;
        public const int APSEL_SHIFT = 24;
        public const UInt32 APSEL = 0xFF000000; // -16777216;
        public const byte APBANKSEL = 240;
        public const byte APREG_MASK = 252;
        public const int DPIDR_MIN_MASK = 65536;
        public const int DPIDR_VERSION_MASK = 61440;
        public const int DPIDR_VERSION_SHIFT = 12;
        public const int CSYSPWRUPACK = -2147483648;
        public const int CDBGPWRUPACK = 536870912;
        public const int CSYSPWRUPREQ = 1073741824;
        public const int CDBGPWRUPREQ = 268435456;
        public const int TRNNORMAL = 0;
        public const int MASKLANE = 3840;
        public const bool LOG_DAP = false;

        public static dap_access_api.DAPAccessIntf.REG _ap_addr_to_reg(UInt32 addr)
        {
            dap_access_api.DAPAccessIntf.REG result = (dap_access_api.DAPAccessIntf.REG)(4 + ((addr & A32) >> 2));
            Debug.Assert(Enum.IsDefined(typeof(dap_access_api.DAPAccessIntf.REG), result));
            return result;
        }

        public class DebugPort
        {

            public readonly dap_access_api.DAPAccessIntf link;
            private int _dp_select;
            private int _access_number;
            public UInt32 dpidr { get; private set; }
            private UInt32 dp_version;
            private bool is_mindp;
            private Dictionary<UInt32, UInt32> _csw;

            public object DAP_LOG_FILE = "pyocd_dap.log";

            public DebugPort(dap_access_api.DAPAccessIntf link)
            {
                this.link = link;
                this._csw = new Dictionary<UInt32, UInt32>
                {
                };
                this._dp_select = -1;
                this._access_number = 0;
                if (dap.LOG_DAP)
                {
                    _setup_logging();
                }
            }

            public int next_access_number
            {
                get
                {
                    this._access_number += 1;
                    return this._access_number;
                }
            }

            // Set up DAP logging.
            //
            // A memory handler is created that buffers log records before flushing them to a file
            // handler that writes to DAP_LOG_FILE. This improves logging performance by writing to the
            // log file less often.
            public virtual void _setup_logging()
            {
                throw new NotImplementedException();
                // var cwd = os.getcwd();
                // var logfile = os.path.join(cwd, this.DAP_LOG_FILE);
                // Trace.TraceInformation("dap logfile: %s", logfile);
                // this.logger = logging.getLogger("dap");
                // this.logger.propagate = false;
                // var formatter = logging.Formatter("%(relativeCreated)010dms:%(levelname)s:%(name)s:%(message)s");
                // var fileHandler = logging.FileHandler(logfile, mode: "w+", delay: true);
                // fileHandler.setFormatter(formatter);
                // var memHandler = logging.handlers.MemoryHandler(capacity: 128, target: fileHandler);
                // this.logger.addHandler(memHandler);
                // this.logger.setLevel(logging.DEBUG);
            }

            public virtual void init()
            {
                // Connect to the target.
                this.link.connect();
                this.link.swj_sequence();
                this.read_id_code();
                this.clear_sticky_err();
            }

            public virtual UInt32 read_id_code()
            {
                // Read ID register and get DP version
                this.dpidr = this.read_reg(DP_REG["IDCODE"]);
                this.dp_version = (this.dpidr & DPIDR_VERSION_MASK) >> DPIDR_VERSION_SHIFT;
                this.is_mindp = (this.dpidr & DPIDR_MIN_MASK) != 0;
                return this.dpidr;
            }

            public virtual void flush()
            {
                try
                {
                    this.link.flush();
                }
                catch (Exception error)
                {
                    this._handle_error(error, this.next_access_number);
                    throw;
                }
                finally
                {
                    this._csw.Clear();
                    this._dp_select = -1;
                }
            }

            public virtual UInt32 read_reg(dap_access_api.DAPAccessIntf.REG addr, bool now = true)
            {
                return this.readDP(addr, now);
            }

            public virtual void write_reg(dap_access_api.DAPAccessIntf.REG addr, UInt32 data)
            {
                this.writeDP(addr, data);
            }

            public virtual void power_up_debug()
            {
                // select bank 0 (to access DRW and TAR)
                this.write_reg(DP_REG["SELECT"], 0);
                this.write_reg(DP_REG["CTRL_STAT"], CSYSPWRUPREQ | CDBGPWRUPREQ);
                while (true)
                {
                    UInt32 r = this.read_reg(DP_REG["CTRL_STAT"]);
                    if ((r & (CDBGPWRUPACK | CSYSPWRUPACK)) == (CDBGPWRUPACK | CSYSPWRUPACK))
                    {
                        break;
                    }
                }
                this.write_reg(DP_REG["CTRL_STAT"], CSYSPWRUPREQ | CDBGPWRUPREQ | TRNNORMAL | MASKLANE);
                this.write_reg(DP_REG["SELECT"], 0);
            }

            public virtual void power_down_debug()
            {
                // select bank 0 (to access DRW and TAR)
                this.write_reg(DP_REG["SELECT"], 0);
                this.write_reg(DP_REG["CTRL_STAT"], 0);
            }

            public virtual void reset()
            {
                try
                {
                    this.link.reset();
                }
                finally
                {
                    this._csw.Clear();
                    this._dp_select = -1;
                }
            }

            public virtual void assert_reset(bool asserted)
            {
                this.link.assert_reset(asserted);
                this._csw.Clear();
                this._dp_select = -1;
            }

            public virtual void set_clock(object frequency)
            {
                this.link.set_clock(frequency);
            }

            public virtual void find_aps()
            {
                var ap_num = 0;
                while (true)
                {
                    try
                    {
                        UInt32 idr = this.readAP((UInt32)(ap_num << APSEL_SHIFT | AP_REG["IDR"]));
                        if (idr == 0)
                        {
                            break;
                        }
                        Trace.TraceInformation("AP#%d IDR = 0x%08x", ap_num, idr);
                    }
                    catch (Exception e)
                    {
                        Trace.TraceError("Exception reading AP#%d IDR: %s", ap_num, e.GetType().Name + ": " + e.Message);
                        break;
                    }
                    ap_num += 1;
                }
            }

            public virtual UInt32 readDP(dap_access_api.DAPAccessIntf.REG addr, bool now = true)
            {
                Debug.Assert(Enum.IsDefined(typeof(dap_access_api.DAPAccessIntf.REG), addr));
                var num = this.next_access_number;
                Func<UInt32> result_cb;
                try
                {
                    result_cb = this.link.read_reg(addr, now: false);
                }
                catch (Exception error)
                {
                    this._handle_error(error, num);
                    throw;
                }
                Func<UInt32> readDPCb = () =>
                {
                    try
                    {
                        var result = result_cb();
                        if (dap.LOG_DAP)
                        {
                            Trace.TraceInformation("readDP:%06d %s(addr=0x%08x) -> 0x%08x", num, now ? "" : "...", addr, result);
                        }
                        return result;
                    }
                    catch (Exception error)
                    {
                        this._handle_error(error, num);
                        throw;
                    }
                };
                if (now)
                {
                    return readDPCb();
                }
                else
                {
                    if (dap.LOG_DAP)
                    {
                        Trace.TraceInformation("readDP:%06d (addr=0x%08x) -> ...", num, addr);
                    }
                    throw new NotImplementedException();
                    //return readDPCb;
                }
            }

            public virtual bool writeDP(dap_access_api.DAPAccessIntf.REG addr, UInt32 data)
            {
                Debug.Assert(Enum.IsDefined(typeof(dap_access_api.DAPAccessIntf.REG), addr));
                var num = this.next_access_number;
                // Skip writing DP SELECT register if its value is not changing.
                if (addr == DP_REG["SELECT"])
                {
                    if (data == this._dp_select)
                    {
                        if (dap.LOG_DAP)
                        {
                            Trace.TraceInformation("writeDP:%06d cached (addr=0x%08x) = 0x%08x", num, addr, data);
                        }
                        return true;
                    }
                    this._dp_select = (int)data;
                }
                // Write the DP register.
                try
                {
                    if (dap.LOG_DAP)
                    {
                        Trace.TraceInformation("writeDP:%06d (addr=0x%08x) = 0x%08x", num, addr, data);
                    }
                    this.link.write_reg(addr, data);
                }
                catch (Exception error)
                {
                    this._handle_error(error, num);
                    throw;
                }
                return true;
            }

            public virtual bool writeAP(UInt32 addr, UInt32 data)
            {
                // Debug.Assert(six.integer_types.Contains(type(addr)));
                var num = this.next_access_number;
                UInt32 ap_sel = addr & APSEL;
                byte bank_sel = (byte)(addr & APBANKSEL);
                byte ap_regaddr = (byte)(addr & APREG_MASK);
                // Don't need to write CSW if it's not changing value.
                if (ap_regaddr == AP_REG["CSW"])
                {
                    if (this._csw.ContainsKey(ap_sel) && data == this._csw[ap_sel])
                    {
                        if (dap.LOG_DAP)
                        {
                            Trace.TraceInformation("writeAP:%06d cached (addr=0x%08x) = 0x%08x", num, addr, data);
                        }
                        return true;
                    }
                    this._csw[ap_sel] = data;
                }
                // Select the AP and bank.
                this.writeDP(DP_REG["SELECT"], ap_sel | bank_sel);
                // Perform the AP register write.
                dap_access_api.DAPAccessIntf.REG ap_reg = _ap_addr_to_reg(WRITE | AP_ACC | addr & A32);
                try
                {
                    if (dap.LOG_DAP)
                    {
                        Trace.TraceInformation("writeAP:%06d (addr=0x%08x) = 0x%08x", num, addr, data);
                    }
                    this.link.write_reg(ap_reg, data);
                }
                catch (Exception error)
                {
                    this._handle_error(error, num);
                    throw;
                }
                return true;
            }

            public virtual UInt32 readAP(UInt32 addr, bool now = true)
            {
                // Debug.Assert(six.integer_types.Contains(type(addr)));
                var num = this.next_access_number;
                object res = null;
                dap_access_api.DAPAccessIntf.REG ap_reg = _ap_addr_to_reg(READ | AP_ACC | addr & A32);
                Func<UInt32> result_cb;
                try
                {
                    UInt32 ap_sel = addr & APSEL;
                    var bank_sel = addr & APBANKSEL;
                    this.writeDP(DP_REG["SELECT"], ap_sel | bank_sel);
                    result_cb = this.link.read_reg(ap_reg, now: false);
                }
                catch (Exception error)
                {
                    this._handle_error(error, num);
                    throw;
                }
                Func<UInt32> readAPCb = () =>
                {
                    try
                    {
                        var result = result_cb();
                        if (dap.LOG_DAP)
                        {
                            Trace.TraceInformation("readAP:%06d %s(addr=0x%08x) -> 0x%08x", num, now ? "" : "...", addr, result);
                        }
                        return result;
                    }
                    catch (Exception error)
                    {
                        this._handle_error(error, num);
                        throw;
                    }
                };
                if (now)
                {
                    return readAPCb();
                }
                else
                {
                    if (dap.LOG_DAP)
                    {
                        Trace.TraceInformation("readAP:%06d (addr=0x%08x) -> ...", num, addr);
                    }
                    throw new NotImplementedException();
                    //return readAPCb;
                }
            }

            public virtual void _handle_error(Exception error, int num)
            {
                if (dap.LOG_DAP)
                {
                    Trace.TraceInformation("error:%06d %s", num, error);
                }
                // Invalidate cached registers
                this._csw.Clear();
                this._dp_select = -1;
                // Clear sticky error for Fault errors only
                if (error is dap_access_api.DAPAccessIntf.TransferFaultError)
                {
                    this.clear_sticky_err();
                }
            }

            public virtual void clear_sticky_err()
            {
                dap_access_api.DAPAccessIntf.PORT mode = this.link.get_swj_mode();
                if (mode == dap_access_api.DAPAccessIntf.PORT.SWD)
                {
                    this.link.write_reg(dap_access_api.DAPAccessIntf.REG.DP_0x0, 1 << 2);
                }
                else if (mode == dap_access_api.DAPAccessIntf.PORT.JTAG)
                {
                    this.link.write_reg(DP_REG["CTRL_STAT"], CTRLSTAT_STICKYERR);
                }
                else
                {
                    Debug.Assert(false);
                }
            }
        }
    }
}
