// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace test {
    
    using split_command_line = pyOCD.utility.cmdline.split_command_line;
    
    using System.Collections.Generic;
    
    using System.Diagnostics;
    
    public static class test_cmdline {
        
        public class TestSplitCommandLine {
            
            public virtual object test_split() {
                Debug.Assert(split_command_line("foo") == new List<object> {
                    "foo"
                });
                Debug.Assert(split_command_line(new List<object> {
                    "foo"
                }) == new List<object> {
                    "foo"
                });
                Debug.Assert(split_command_line("foo bar") == new List<object> {
                    "foo",
                    "bar"
                });
                Debug.Assert(split_command_line(new List<object> {
                    "foo bar"
                }) == new List<object> {
                    "foo",
                    "bar"
                });
            }
            
            public virtual object test_split_strings() {
                Debug.Assert(split_command_line("\"foo\"") == new List<object> {
                    "foo"
                });
                Debug.Assert(split_command_line("\"foo bar\"") == new List<object> {
                    "foo bar"
                });
                Debug.Assert(split_command_line(new List<object> {
                    "\"foo\""
                }) == new List<object> {
                    "foo"
                });
                Debug.Assert(split_command_line("a \"b c\" d") == new List<object> {
                    "a",
                    "b c",
                    "d"
                });
                Debug.Assert(split_command_line("'foo bar'") == new List<object> {
                    "foo bar"
                });
            }
            
            public virtual object test_split_whitespace() {
                Debug.Assert(split_command_line("a b") == new List<object> {
                    "a",
                    "b"
                });
                Debug.Assert(split_command_line("a\tb") == new List<object> {
                    "a",
                    "b"
                });
                Debug.Assert(split_command_line("a\rb") == new List<object> {
                    "a",
                    "b"
                });
                Debug.Assert(split_command_line("a\nb") == new List<object> {
                    "a",
                    "b"
                });
                Debug.Assert(split_command_line("a   \tb") == new List<object> {
                    "a",
                    "b"
                });
            }
        }
    }
}
