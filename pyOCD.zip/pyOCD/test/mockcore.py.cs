// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2017 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace test {
    
    using MemoryCache = pyOCD.debug.cache.MemoryCache;
    
    using DebugContext = pyOCD.debug.context.DebugContext;
    
    using CORE_REGISTER = pyOCD.coresight.cortex_m.CORE_REGISTER;
    
    using register_name_to_index = pyOCD.coresight.cortex_m.register_name_to_index;
    
    using memory_map = pyOCD.core.memory_map;
    
    using conversion = pyOCD.utility.conversion;
    
    using mask = pyOCD.utility.mask;
    
    using pytest;
    
    using logging;
    
    using System.Collections.Generic;
    
    using System.Linq;
    
    public static class mockcore {
        
        public class MockCore
            : object {
            
            public MockCore() {
                this.run_token = 1;
                this.flash_region = memory_map.FlashRegion(start: 0, length: 1 * 1024, blocksize: 1024, name: "flash");
                this.ram_region = memory_map.RamRegion(start: 536870912, length: 1 * 1024, name: "ram");
                this.ram2_region = memory_map.RamRegion(start: 536871936, length: 1 * 1024, name: "ram2", isCacheable: false);
                this.memory_map = memory_map.MemoryMap(this.flash_region, this.ram_region, this.ram2_region);
                this.ram = bytearray(1024);
                this.ram2 = bytearray(1024);
                this.flash = bytearray(new List<object> {
                    255
                }) * 1024;
                this.regions = new List<object> {
                    Tuple.Create(this.flash_region, this.flash),
                    Tuple.Create(this.ram_region, this.ram),
                    Tuple.Create(this.ram2_region, this.ram2)
                };
                this.has_fpu = true;
                this.clear_all_regs();
            }
            
            public virtual object clear_all_regs() {
                this.regs = range(0, 19).ToDictionary(i => i, i => 0);
                this.regs[CORE_REGISTER["cfbp"]] = 0;
            }
            
            public virtual object isRunning() {
                return false;
            }
            
            public virtual object readCoreRegistersRaw(object reg_list) {
                object v;
                reg_list = reg_list.Select(reg => register_name_to_index(reg));
                var results = new List<object>();
                foreach (var r in reg_list) {
                    if (r < 0 && r >= -4) {
                        v = this.regs[CORE_REGISTER["cfbp"]];
                        v = v >> (-r - 1) * 8 & 255;
                    } else {
                        if (!this.regs.Contains(r)) {
                            this.regs[r] = 0;
                        }
                        v = this.regs[r];
                    }
                    results.append(v);
                    //         logging.info("mockcore[%x]:read(%s)=%s", id(self), reg_list, results)
                }
                return results;
            }
            
            public virtual object writeCoreRegistersRaw(object reg, object data) {
                reg = reg.Select(r => register_name_to_index(r));
                //         logging.info("mockcore[%x]:write(%s, %s)", id(self), reg, data)
                foreach (var _tup_1 in zip(reg, data)) {
                    var r = _tup_1.Item1;
                    var v = _tup_1.Item2;
                    if (r < 0 && r >= -4) {
                        var shift = (-r - 1) * 8;
                        var mask = -1 ^ 255 << shift;
                        data = this.regs[CORE_REGISTER["cfbp"]] & mask | (v & 255) << shift;
                        this.regs[CORE_REGISTER["cfbp"]] = data;
                    } else {
                        this.regs[r] = v;
                    }
                }
            }
            
            public virtual object readMemory(object addr, object transfer_size = 32, object now = true) {
                if (transfer_size == 8) {
                    return 18;
                } else if (transfer_size == 16) {
                    return 4660;
                } else if (transfer_size == 32) {
                    return 305419896;
                }
            }
            
            public virtual object readBlockMemoryUnaligned8(object addr, object size) {
                foreach (var _tup_1 in this.regions) {
                    var r = _tup_1.Item1;
                    var m = _tup_1.Item2;
                    if (r.containsRange(addr, length: size)) {
                        addr -= r.start;
                        return m[addr::(addr  +  size)].ToList();
                    }
                }
                return new List<object> {
                    85
                } * size;
            }
            
            public virtual object readBlockMemoryAligned32(object addr, object size) {
                return conversion.byteListToU32leList(this.readBlockMemoryUnaligned8(addr, size * 4));
            }
            
            public virtual object writeMemory(object addr, object value, object transfer_size = 32) {
                return true;
            }
            
            public virtual object writeBlockMemoryUnaligned8(object addr, object value) {
                foreach (var _tup_1 in this.regions) {
                    var r = _tup_1.Item1;
                    var m = _tup_1.Item2;
                    if (r.containsRange(addr, length: value.Count)) {
                        addr -= r.start;
                        m[addr::(addr  +  len(value))] = value;
                        return true;
                    }
                }
                return false;
            }
            
            public virtual object writeBlockMemoryAligned32(object addr, object data) {
                return this.writeBlockMemoryUnaligned8(addr, conversion.u32leListToByteList(data));
            }
        }
    }
}
