// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace utility {
    
    public static class mask {
        
        //# @brief Returns a mask with specified bit ranges set.
        //
        // An integer mask is generated based on the bits and bit ranges specified by the
        // arguments. Any number of arguments can be provided. Each argument may be either
        // a 2-tuple of integers, a list of integers, or an individual integer. The result
        // is the combination of masks produced by the arguments.
        //
        // - 2-tuple: The tuple is a bit range with the first element being the MSB and the
        //       second element the LSB. All bits from LSB up to and included MSB are set.
        // - list: Each bit position specified by the list elements is set.
        // - int: The specified bit position is set.
        //
        // @return An integer mask value computed from the logical OR'ing of masks generated
        //   by each argument.
        //
        // Example:
        // @code
        //   >>> hex(bitmask((23,17),1))
        //   0xfe0002
        //   >>> hex(bitmask([4,0,2],(31,24))
        //   0xff000015
        // @endcode
        public static object bitmask() {
            var mask = 0;
            foreach (var a in args) {
                if (object.ReferenceEquals(type(a), tuple)) {
                    foreach (var b in range(a[1], a[0] + 1)) {
                        mask |= 1 << b;
                    }
                } else if (object.ReferenceEquals(type(a), list)) {
                    foreach (var b in a) {
                        mask |= 1 << b;
                    }
                } else if (object.ReferenceEquals(type(a), @int)) {
                    mask |= 1 << a;
                }
            }
            return mask;
        }
        
        //# @brief Return the 32-bit inverted value of the argument.
        public static object invert32(object value) {
            return -1 & ~value;
        }
        
        //# @brief Extract a value from a bitfield.
        public static object bfx(object value, object msb, object lsb) {
            var mask = bitmask(Tuple.Create(msb, lsb));
            return (value & mask) >> lsb;
        }
        
        //# @brief Change a bitfield value.
        public static object bfi(object value, object msb, object lsb, object field) {
            var mask = bitmask(Tuple.Create(msb, lsb));
            value |= ~mask;
            value |= (field & mask) << lsb;
            return value;
        }
        
        public static object _msb(object n) {
            var ndx = 0;
            while (1 < n) {
                n = n >> 1;
                ndx += 1;
            }
            return ndx;
        }
    }
}
