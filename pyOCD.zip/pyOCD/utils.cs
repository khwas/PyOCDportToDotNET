using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace utils
{
    public static class utils
    {
        public static T[] SubArray<T>(this T[] data, UInt32 index, UInt32 length)
        {
            T[] result = new T[length];
            Array.Copy(data, index, result, 0, length);
            return result;
        }

        public static T[] SubArray<T>(this T[] data, UInt32 index) => SubArray<T>(data, index, (UInt32)data.Length - index);

    }

    public static class conversion
    {
        public static List<UInt32> byteListToU32leList(List<byte> data)
        {
            if (data.Count % 4 != 0)
            {
                throw new Exception("Can not convert bytes to UInt32, count is not divisible by 4");
            }
            UInt32[] result = new UInt32[data.Count / 4];
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = (UInt32)((data[i * 4 + 3] << 24) | (data[i * 4 + 2] << 16) | (data[i * 4 + 1] << 8) | data[i * 4]);
            }
            return result.ToList();
        }

        public static List<byte> u32leListToByteList(List<UInt32> data)
        {
            byte[] result = new byte[data.Count * 4];
            for (int i = 0; i < data.Count; i++)
            {
                result[i * 4 + 0] = (byte)(data[i] >> 0 & 0xFF);
                result[i * 4 + 1] = (byte)(data[i] >> 8 & 0xFF);
                result[i * 4 + 2] = (byte)(data[i] >> 16 & 0xFF);
                result[i * 4 + 3] = (byte)(data[i] >> 24 & 0xFF);
            }
            return result.ToList();
        }
    }
}
