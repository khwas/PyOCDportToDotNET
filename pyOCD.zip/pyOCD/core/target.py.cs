// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace core {
    using pyDAPAccess;
    using System;
    using System.Collections.Generic;
    using static flash.flash;
    using MemoryMap = memory_map.MemoryMap;
    
    public static class target {
        
        public class Target
            {
            
            public const byte TARGET_RUNNING = 1;
            public const byte TARGET_HALTED = 2;
            public const byte TARGET_RESET = 3;
            public const byte TARGET_SLEEPING = 4;
            public const byte TARGET_LOCKUP = 5;
            public const byte BREAKPOINT_HW = 1;
            public const byte BREAKPOINT_SW = 2;
            public const byte BREAKPOINT_AUTO = 3;
            public const byte WATCHPOINT_READ = 1;
            public const byte WATCHPOINT_WRITE = 2;
            public const byte WATCHPOINT_READ_WRITE = 3;
            public const byte CATCH_NONE = 0;
            public const byte CATCH_HARD_FAULT = 1 << 0;
            public const byte CATCH_BUS_FAULT = 1 << 1;
            public const byte CATCH_MEM_FAULT = 1 << 2;
            public const byte CATCH_INTERRUPT_ERR = 1 << 3;
            public const byte CATCH_STATE_ERR = 1 << 4;
            public const byte CATCH_CHECK_ERR = 1 << 5;
            public const byte CATCH_COPROCESSOR_ERR = 1 << 6;
            public const byte CATCH_CORE_RESET = 1 << 7;
            public const byte CATCH_ALL = CATCH_HARD_FAULT | CATCH_BUS_FAULT | CATCH_MEM_FAULT | CATCH_INTERRUPT_ERR | CATCH_STATE_ERR | CATCH_CHECK_ERR | CATCH_COPROCESSOR_ERR | CATCH_CORE_RESET;

            internal dap_access_api.DAPAccessIntf link;
            internal Flash flash;
            private bool halt_on_connect;
            public readonly bool has_fpu;
            private string part_number;
            public readonly MemoryMap memory_map;
            internal cmsis_svd.device _svd_device;
            internal debug.svd.SVDFile _svd_location;
            public byte core_number { get; internal set; }

            public Target(dap_access_api.DAPAccessIntf link, MemoryMap memoryMap = null) {
                this.link = link;
                this.flash = null;
                this.part_number = "";
                this.memory_map = memoryMap ?? new MemoryMap();
                this.halt_on_connect = true;
                this.has_fpu = false;
                this._svd_location = null;
                this._svd_device = null;
            }
            
            public virtual cmsis_svd.device svd_device {
                get {
                    return this._svd_device;
                }
            }
            
            public virtual void setAutoUnlock(object doAutoUnlock) {
            }
            
            public virtual bool isLocked() {
                return false;
            }
            
            public virtual void setHaltOnConnect(bool halt) {
                this.halt_on_connect = halt;
            }
            
            public virtual void setFlash(Flash flash) {
                this.flash = flash;
            }
            
            public virtual void init() {
                throw new NotImplementedException();
            }
            
            public virtual void disconnect() {
            }
            
            public virtual object info(object request) {
                throw new NotImplementedException();
                //return this.link.info(request);
            }
            
            public virtual void flush() {
                this.link.flush();
            }
            
            public virtual UInt32 readIDCode() {
                throw new NotImplementedException();
            }
            
            public virtual void halt() {
                throw new NotImplementedException();
            }
            
            public virtual void step(bool disable_interrupts = true) {
                throw new NotImplementedException();
            }
            
            public virtual void resume() {
                throw new NotImplementedException();
            }
            
            public virtual bool massErase() {
                throw new NotImplementedException();
            }
            
            public virtual object writeMemory(UInt32 addr, object value, byte transfer_size = 32) {
                throw new NotImplementedException();
            }
            
            // @brief Shorthand to write a 32-bit word.
            public virtual void write32(UInt32 addr, UInt32 value) {
                this.writeMemory(addr, value, 32);
            }
            
            // @brief Shorthand to write a 16-bit halfword.
            public virtual void write16(UInt32 addr, UInt16 value) {
                this.writeMemory(addr, value, 16);
            }
            
            // @brief Shorthand to write a byte.
            public virtual void write8(UInt32 addr, byte value) {
                this.writeMemory(addr, value, 8);
            }
            
            public virtual UInt32 readMemory(object addr, byte transfer_size = 32, bool now = true) {
                throw new NotImplementedException();
            }
            
            // @brief Shorthand to read a 32-bit word.
            public virtual UInt32 read32(object addr, bool now = true) {
                return this.readMemory(addr, 32, now);
            }
            
            // @brief Shorthand to read a 16-bit halfword.
            public virtual UInt16 read16(object addr, bool now = true) {
                return (UInt16)this.readMemory(addr, 16, now);
            }
            
            // @brief Shorthand to read a byte.
            public virtual object read8(object addr, bool now = true) {
                return this.readMemory(addr, 8, now);
            }
            
            public virtual object writeBlockMemoryUnaligned8(object addr, object value) {
                throw new NotImplementedException();
            }
            
            public virtual object writeBlockMemoryAligned32(object addr, object data) {
                throw new NotImplementedException();
            }
            
            public virtual List<byte> readBlockMemoryUnaligned8(UInt32 addr, UInt32 size) {
                throw new NotImplementedException();
            }
            
            public virtual List<UInt32> readBlockMemoryAligned32(UInt32 addr, UInt32 size) {
                throw new NotImplementedException();
            }
            
            public virtual object readCoreRegister(string id) {
                throw new NotImplementedException();
            }
            
            public virtual object writeCoreRegister(object id, object data) {
                throw new NotImplementedException();
            }
            
            public virtual object readCoreRegisterRaw(object reg) {
                throw new NotImplementedException();
            }
            
            public virtual List<object> readCoreRegistersRaw(List<sbyte> reg_list) {
                throw new NotImplementedException();
            }
            
            public virtual void writeCoreRegisterRaw(object reg, object data) {
                throw new NotImplementedException();
            }
            
            public virtual void writeCoreRegistersRaw(List<sbyte> reg_list, List<UInt32> data_list) {
                throw new NotImplementedException();
            }
            
            public virtual object findBreakpoint(object addr) {
                throw new NotImplementedException();
            }
            
            public virtual object setBreakpoint(object addr, byte type = BREAKPOINT_AUTO) {
                throw new NotImplementedException();
            }
            
            public virtual object getBreakpointType(object addr) {
                throw new NotImplementedException();
            }
            
            public virtual object removeBreakpoint(object addr) {
                throw new NotImplementedException();
            }
            
            public virtual object setWatchpoint(object addr, object size, object type) {
                throw new NotImplementedException();
            }
            
            public virtual object removeWatchpoint(object addr, object size, object type) {
                throw new NotImplementedException();
            }
            
            public virtual void reset(bool? software_reset = null) {
                throw new NotImplementedException();
            }
            
            public virtual object resetStopOnReset(object software_reset = null) {
                throw new NotImplementedException();
            }
            
            public virtual object setTargetState(object state) {
                throw new NotImplementedException();
            }
            
            public virtual byte getState() {
                throw new NotImplementedException();
            }
            
            public virtual int run_token {
                get {
                    return 0;
                }
            }
            
            public virtual bool isRunning() {
                return this.getState() == Target.TARGET_RUNNING;
            }
            
            public virtual bool isHalted() {
                return this.getState() == Target.TARGET_HALTED;
            }
            
            public virtual MemoryMap getMemoryMap() {
                return this.memory_map;
            }
            
            public virtual void setVectorCatch(UInt32 enableMask) {
                throw new NotImplementedException();
            }
            
            public virtual UInt32 getVectorCatch() {
                throw new NotImplementedException();
            }
            
            // GDB functions
            public virtual string getTargetXML() {
                throw new NotImplementedException();
            }
            
            public virtual object getTargetContext(object core = null) {
                throw new NotImplementedException();
            }
            
            public virtual object getRootContext(object core = null) {
                throw new NotImplementedException();
            }
            
            public virtual void setRootContext(object context, object core = null) {
                throw new NotImplementedException();
            }
        }
    }
}
