// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2015 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace core
{

    using Target = target.Target;

    using dap = coresight.dap;

    using ap = coresight.ap;

    using cortex_m = coresight.cortex_m;

    //using SVDFile = debug.svd.SVDFile;

    //using debug.svd.SVDLoader;

    using debug;

    using CachingDebugContext = debug.cache.CachingDebugContext;

    //using threading;

    //using logging;

    //using Element = xml.etree.ElementTree.Element;

    //using SubElement = xml.etree.ElementTree.SubElement;

    //using tostring = xml.etree.ElementTree.tostring;

    using System.Collections.Generic;

    using System;
    using static coresight.dap;
    using pyDAPAccess;
    using System.Diagnostics;

    public static class coresight_target
    {

        public class CoreSightTarget
            : Target
        {

            private DebugPort dp;
            private Dictionary<UInt32, cortex_m.CortexM> cores;
            private Dictionary<object, ap.MEM_AP> aps;
            private string part_number;
            private UInt32 _selected_core;
            Dictionary<object, object> _root_contexts;
            internal svd.SVDLoader _svd_load_thread;

            public CoreSightTarget(dap_access_api.DAPAccessIntf link, memory_map.MemoryMap memoryMap = null)
                : base(link, memoryMap)
            {
                this.part_number = this.GetType().Name;
                this.cores = new Dictionary<UInt32, cortex_m.CortexM>()
                {
                };
                this.aps = new Dictionary<object, ap.MEM_AP>()
                {
                };
                this.dp = new dap.DebugPort(link);
                this._selected_core = 0;
                this._svd_load_thread = null;
                this._root_contexts = new Dictionary<object, object>()
                {
                };
            }

            public Target selected_core
            {
                get
                {
                    return this.cores[this._selected_core];
                }
            }

            public virtual void select_core(UInt32 num)
            {
                if (!this.cores.ContainsKey(num))
                {
                    throw new ArgumentOutOfRangeException("invalid core number");
                }
                Trace.TraceInformation(String.Format("selected core #%d", num));
                this._selected_core = num;
            }

            public override cmsis_svd.device svd_device
            {
                get
                {
                    if ((this._svd_device == null) && (this._svd_load_thread != null))
                    {
                        Trace.TraceInformation("Waiting for SVD load to complete");
                        this._svd_device = this._svd_load_thread.device;
                    }
                    return this._svd_device;
                }
            }

            public virtual void loadSVD()
            {
                void svdLoadCompleted(cmsis_svd.device svdDevice)
                {
                    Trace.TraceInformation("Completed loading SVD");
                    this._svd_device = svdDevice;
                    this._svd_load_thread = null;
                }
                if ((this._svd_device == null) && (this._svd_location != null))
                {
                    Trace.TraceInformation("Started loading SVD");
                    // Spawn thread to load SVD in background.
                    this._svd_load_thread = new svd.SVDLoader(this._svd_location, svdLoadCompleted);
                    this._svd_load_thread.load();
                }
            }

            public virtual void add_ap(ap.MEM_AP ap)
            {
                this.aps[ap.ap_num] = ap;
            }

            public virtual void add_core(cortex_m.CortexM core)
            {
                this.cores[core.core_number] = core;
                this.cores[core.core_number].setTargetContext(new CachingDebugContext(core, new context.DebugContext(core)));
                this._root_contexts[core.core_number] = null;
            }

            public virtual void init(bool bus_accessible = true)
            {
                // Start loading the SVD file
                this.loadSVD();
                // Create the DP and turn on debug.
                this.dp.init();
                this.dp.power_up_debug();
                // Create an AHB-AP for the CPU.
                var ap0 = new ap.AHB_AP(this.dp, 0);
                ap0.init(bus_accessible);
                this.add_ap(ap0);
                // Create CortexM core.
                cortex_m.CortexM core0 = new cortex_m.CortexM(this.link, this.dp, this.aps[0], this.memory_map);
                if (bus_accessible)
                {
                    core0.init();
                }
                this.add_core(core0);
            }

            public override void disconnect()
            {
                foreach (var core in this.cores.Values)
                {
                    core.disconnect();
                }
                this.dp.power_down_debug();
            }

            public override UInt32 readIDCode()
            {
                return this.dp.dpidr;
            }

            public override int run_token
            {
                get
                {
                    return this.selected_core.run_token;
                }
            }

            public override void flush()
            {
                this.dp.flush();
            }

            public override void halt()
            {
                this.selected_core.halt();
            }

            public override void step(bool disable_interrupts = true)
            {
                this.selected_core.step(disable_interrupts);
            }

            public override void resume()
            {
                this.selected_core.resume();
            }

            public override bool massErase()
            {
                if (this.flash != null)
                {
                    this.flash.init();
                    this.flash.eraseAll();
                    return true;
                }
                else
                {
                    return false;
                }
            }

            public override object writeMemory(UInt32 addr, object value, byte transfer_size = 32)
            {
                return this.selected_core.writeMemory(addr, value, transfer_size);
            }

            public virtual object readMemory(UInt32 addr, byte transfer_size = 32, bool now = true)
            {
                return this.selected_core.readMemory(addr, transfer_size, now);
            }

            public override object writeBlockMemoryUnaligned8(object addr, object value)
            {
                return this.selected_core.writeBlockMemoryUnaligned8(addr, value);
            }

            public override object writeBlockMemoryAligned32(object addr, object data)
            {
                return this.selected_core.writeBlockMemoryAligned32(addr, data);
            }

            public override List<byte> readBlockMemoryUnaligned8(UInt32 addr, UInt32 size)
            {
                return this.selected_core.readBlockMemoryUnaligned8(addr, size);
            }

            public override List<UInt32> readBlockMemoryAligned32(UInt32 addr, UInt32 size)
            {
                return this.selected_core.readBlockMemoryAligned32(addr, size);
            }

            public override object readCoreRegister(string id)
            {
                return this.selected_core.readCoreRegister(id);
            }

            public override object writeCoreRegister(object id, object data)
            {
                return this.selected_core.writeCoreRegister(id, data);
            }

            public override object readCoreRegisterRaw(object reg)
            {
                return this.selected_core.readCoreRegisterRaw(reg);
            }

            public override List<object> readCoreRegistersRaw(List<sbyte> reg_list)
            {
                return this.selected_core.readCoreRegistersRaw(reg_list);
            }

            public override void writeCoreRegisterRaw(object reg, object data)
            {
                this.selected_core.writeCoreRegisterRaw(reg, data);
            }

            public override void writeCoreRegistersRaw(List<sbyte> reg_list, List<UInt32> data_list)
            {
                this.selected_core.writeCoreRegistersRaw(reg_list, data_list);
            }

            public override object findBreakpoint(object addr)
            {
                return this.selected_core.findBreakpoint(addr);
            }

            public override object setBreakpoint(object addr, byte type = Target.BREAKPOINT_AUTO)
            {
                return this.selected_core.setBreakpoint(addr, type);
            }

            public override object getBreakpointType(object addr)
            {
                return this.selected_core.getBreakpointType(addr);
            }

            public override object removeBreakpoint(object addr)
            {
                return this.selected_core.removeBreakpoint(addr);
            }

            public override object setWatchpoint(object addr, object size, object type)
            {
                return this.selected_core.setWatchpoint(addr, size, type);
            }

            public override object removeWatchpoint(object addr, object size, object type)
            {
                return this.selected_core.removeWatchpoint(addr, size, type);
            }

            public override void reset(bool? software_reset = null)
            {
                this.selected_core.reset(software_reset);
            }

            public override object resetStopOnReset(object software_reset = null)
            {
                return this.selected_core.resetStopOnReset(software_reset);
            }

            public override object setTargetState(object state)
            {
                return this.selected_core.setTargetState(state);
            }

            public override byte getState()
            {
                return this.selected_core.getState();
            }

            public override memory_map.MemoryMap getMemoryMap()
            {
                return this.memory_map;
            }

            public override void setVectorCatch(UInt32 enableMask)
            {
                //return 
                this.selected_core.setVectorCatch(enableMask);
            }

            public override UInt32 getVectorCatch()
            {
                return this.selected_core.getVectorCatch();
            }

            // GDB functions
            public override string getTargetXML()
            {
                return this.selected_core.getTargetXML();
            }

            public virtual object getTargetContext(UInt32? core = null)
            {
                if (core == null)
                {
                    core = this._selected_core;
                }
                return this.cores[(UInt32)core].getTargetContext();
            }

            public override object getRootContext(object core = null)
            {
                if (core == null)
                {
                    core = this._selected_core;
                }
                if (this._root_contexts[core] == null)
                {
                    return this.getTargetContext();
                }
                else
                {
                    return this._root_contexts[core];
                }
            }

            public override void setRootContext(object context, object core = null)
            {
                if (core == null)
                {
                    core = this._selected_core;
                }
                this._root_contexts[core] = context;
            }
        }
    }
}
