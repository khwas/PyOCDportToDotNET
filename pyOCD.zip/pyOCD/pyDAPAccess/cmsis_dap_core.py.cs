// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace pyDAPAccess
{

    //using logging;

    //using array;

    using DAPAccessIntf = dap_access_api.DAPAccessIntf;

    //using six;

    using System.Collections.Generic;

    using System;
    using System.Diagnostics;
    using System.Text;
    using System.Linq;

    public static class cmsis_dap_core
    {

        public static Dictionary<string, byte> COMMAND_ID = new Dictionary<string, byte>()
        {
            {"DAP_INFO",               0},
            {"DAP_LED",                1},
            {"DAP_CONNECT",            2},
            {"DAP_DISCONNECT",         3},
            {"DAP_TRANSFER_CONFIGURE", 4},
            {"DAP_TRANSFER",           5},
            {"DAP_TRANSFER_BLOCK",     6},
            {"DAP_TRANSFER_ABORT",     7},
            {"DAP_WRITE_ABORT",        8},
            {"DAP_DELAY",              9},
            {"DAP_RESET_TARGET",      10},
            {"DAP_SWJ_PINS",          16},
            {"DAP_SWJ_CLOCK",         17},
            {"DAP_SWJ_SEQUENCE",      18},
            {"DAP_SWD_CONFIGURE",     19},
            {"DAP_JTAG_SEQUENCE",     20},
            {"DAP_JTAG_CONFIGURE",    21},
            {"DAP_JTAG_IDCODE",       22},
            {"DAP_VENDOR0",          128}
        };

        public static Dictionary<string, DAPAccessIntf.ID> ID_INFO = new Dictionary<string, DAPAccessIntf.ID>()
        {
            {"VENDOR_ID",             DAPAccessIntf.ID.VENDOR},
            {"PRODUCT_ID",            DAPAccessIntf.ID.PRODUCT},
            {"SERIAL_NUMBER",         DAPAccessIntf.ID.SER_NUM},
            {"CMSIS_DAP_FW_VERSION",  DAPAccessIntf.ID.FW_VER},
            {"TARGET_DEVICE_VENDOR",  DAPAccessIntf.ID.DEVICE_VENDOR},
            {"TARGET_DEVICE_NAME",    DAPAccessIntf.ID.DEVICE_NAME },
            {"CAPABILITIES",          DAPAccessIntf.ID.CAPABILITIES},
            {"SWO_BUFFER_SIZE",       DAPAccessIntf.ID.SWO_BUFFER_SIZE},
            {"PACKET_COUNT",          DAPAccessIntf.ID.MAX_PACKET_COUNT},
            {"PACKET_SIZE",           DAPAccessIntf.ID.MAX_PACKET_SIZE}
        };

        public static Dictionary<string, byte> PINS = new Dictionary<string, byte>()
        {
            {"None",            0},
            {"SWCLK_TCK",  1 << 0},
            {"SWDIO_TMS",  1 << 1},
            {"TDI",        1 << 2},
            {"TDO",        1 << 3},
            {"nTRST",      1 << 5},
            {"nRESET",     1 << 7}
        };

        public const DAPAccessIntf.PORT DAP_DEFAULT_PORT = DAPAccessIntf.PORT.DEFAULT;
        public const byte DAP_SWD_PORT = 1;
        public const byte DAP_JTAG_POR = 2;
        public const byte DAP_LED_CONNECT = 0;
        public const byte DAP_LED_RUNNING = 1;
        public const byte DAP_OK = 0;
        public const byte DAP_ERROR = 255;
        public const byte DAP_TRANSFER_OK = 1;
        public const byte DAP_TRANSFER_WAIT = 2;
        public const byte DAP_TRANSFER_FAULT = 4;
        public const byte DAP_TRANSFER_NO_ACK = 7;

        public class CMSIS_DAP_Protocol
        {
            internal Interface.Interface anInterface { get; private set; }

            public CMSIS_DAP_Protocol(Interface.Interface anInterface)
            {
                this.anInterface = anInterface;
            }

            public virtual object dapInfo(DAPAccessIntf.ID id_)
            {
                //if (!six.integer_types.Contains(type(id_)))
                //{
                //    id_ = ID_INFO[id_];
                //}
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_INFO"]);
                cmd.Add((byte)id_);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_INFO"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] == 0)
                {
                    return null;
                }
                // Integer values
                if (new DAPAccessIntf.ID[] { ID_INFO["CAPABILITIES"], ID_INFO["SWO_BUFFER_SIZE"], ID_INFO["PACKET_COUNT"], ID_INFO["PACKET_SIZE"] }.Contains(id_))
                {
                    if (resp[1] == 1)
                    {
                        return resp[2];
                    }
                    if (resp[1] == 2)
                    {
                        return resp[3] << 8 | resp[2];
                    }
                }
                // String values. They are sent as C strings with a terminating null char, so we strip it out.
                string x = Encoding.ASCII.GetString(resp.GetRange(2, resp[1]).ToArray());
                //if (x[-1] == "\x00")
                //{
                //    x = x[0:: - 1];
                //}
                return x;
            }

            public virtual byte setLed(byte type, bool enabled)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_LED"]);
                cmd.Add(type);
                cmd.Add(Convert.ToByte(enabled));
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_LED"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != 0)
                {
                    // Second response byte must be 0
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[1];
            }

            public virtual DAPAccessIntf.PORT connect(DAPAccessIntf.PORT mode = DAP_DEFAULT_PORT)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_CONNECT"]);
                cmd.Add((byte)mode);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_CONNECT"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] == 0)
                {
                    // DAP connect failed
                    throw new DAPAccessIntf.CommandError();
                }
                if (resp[1] == 1)
                {
                    Trace.TraceInformation("DAP SWD MODE initialized");
                }
                if (resp[1] == 2)
                {
                    Trace.TraceInformation("DAP JTAG MODE initialized");
                }
                Debug.Assert(Enum.IsDefined(typeof(DAPAccessIntf.PORT), (DAPAccessIntf.PORT)resp[1]));
                return (DAPAccessIntf.PORT)resp[1];
            }

            public virtual object disconnect()
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_DISCONNECT"]);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_DISCONNECT"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP Disconnect failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[1];
            }

            public virtual object writeAbort(UInt32 data, byte dap_index = 0)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_WRITE_ABORT"]);
                cmd.Add(dap_index);
                cmd.Add((byte)((data >> 0) & 0xFF));
                cmd.Add((byte)((data >> 8) & 0xFF));
                cmd.Add((byte)((data >> 16) & 0xFF));
                cmd.Add((byte)((data >> 24) & 0xFF));
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_WRITE_ABORT"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP Write Abort failed
                    throw new DAPAccessIntf.CommandError();
                }
                return true;
            }

            public virtual object resetTarget()
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_RESET_TARGET"]);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_RESET_TARGET"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP Reset target failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[1];
            }

            public virtual object transferConfigure(byte idle_cycles = 0, UInt16 wait_retry = 80, UInt16 match_retry = 0)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_TRANSFER_CONFIGURE"]);
                cmd.Add(idle_cycles);
                cmd.Add((byte)(wait_retry & 0xFF));
                cmd.Add((byte)(wait_retry >> 8));
                cmd.Add((byte)(match_retry & 0xFF));
                cmd.Add((byte)(match_retry >> 8));
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_TRANSFER_CONFIGURE"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP Transfer Configure failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[1];
            }

            public virtual byte setSWJClock(UInt32 clock = 1000000)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_SWJ_CLOCK"]);
                cmd.Add((byte)((clock >> 0) & 0xFF));
                cmd.Add((byte)((clock >> 8) & 0xFF));
                cmd.Add((byte)((clock >> 16) & 0xFF));
                cmd.Add((byte)((clock >> 24) & 0xFF));
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_SWJ_CLOCK"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP SWJ Clock failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[1];
            }

            public virtual byte setSWJPins(byte output, string pin, UInt32 wait = 0)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_SWJ_PINS"]);
                byte p;
                try
                {
                    p = PINS[pin];
                }
                catch (KeyNotFoundException)
                {
                    Trace.TraceError("cannot find %s pin", pin);
                    throw; // return
                }
                cmd.Add((byte)(output & 0xFF));
                cmd.Add(p);
                cmd.Add((byte)((wait >> 0) & 0xFF));
                cmd.Add((byte)((wait >> 8) & 0xFF));
                cmd.Add((byte)((wait >> 16) & 0xFF));
                cmd.Add((byte)((wait >> 24) & 0xFF));
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_SWJ_PINS"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                return resp[1];
            }

            public virtual byte swdConfigure(byte conf = 0)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_SWD_CONFIGURE"]);
                cmd.Add(conf);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_SWD_CONFIGURE"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP SWD Configure failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[1];
            }

            public virtual byte swjSequence(List<byte> data)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_SWJ_SEQUENCE"]);
                cmd.Add((byte)(data.Count * 8));
                //foreach (var i in range(data.Count))
                //{
                cmd.AddRange(data); //cmd.Add(data[i]);
                //}
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_SWJ_SEQUENCE"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP SWJ Sequence failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[1];
            }

            public virtual byte jtagSequence(byte info, byte tdi)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_JTAG_SEQUENCE"]);
                cmd.Add(1);
                cmd.Add(info);
                cmd.Add(tdi);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_JTAG_SEQUENCE"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP JTAG Sequence failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[2];
            }

            public virtual byte jtagConfigure(byte irlen, byte dev_num = 1)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_JTAG_CONFIGURE"]);
                cmd.Add(dev_num);
                cmd.Add(irlen);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_JTAG_CONFIGURE"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // DAP JTAG Configure failed
                    throw new DAPAccessIntf.CommandError();
                }
                return resp[2];
            }

            public virtual UInt32 jtagIDCode(byte index = 0)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add(COMMAND_ID["DAP_JTAG_IDCODE"]);
                cmd.Add(index);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_JTAG_IDCODE"])
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                if (resp[1] != DAP_OK)
                {
                    // Operation failed
                    throw new DAPAccessIntf.CommandError();
                }
                return (UInt32)(resp[2] << 0 | resp[3] << 8 | resp[4] << 16 | resp[5] << 24);
            }

            public virtual byte vendor(byte index, List<byte> data)
            {
                List<byte> cmd = new List<byte>();
                cmd.Add((byte)(COMMAND_ID["DAP_VENDOR0"] + index));
                cmd.AddRange(data);
                this.anInterface.write(cmd);
                List<byte> resp = this.anInterface.read();
                if (resp[0] != COMMAND_ID["DAP_VENDOR0"] + index)
                {
                    // Response is to a different command
                    throw new DAPAccessIntf.DeviceError();
                }
                return resp[1];
            }
        }
    }
}
