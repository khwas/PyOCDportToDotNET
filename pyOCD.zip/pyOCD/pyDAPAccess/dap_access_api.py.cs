// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace pyDAPAccess {
    using System;
    using System.Collections.Generic;

    public static class dap_access_api {
        
        public class DAPAccessIntf
            {
            
            // Physical access ports
            public enum PORT {
                DEFAULT = 0,
                SWD = 1,
                JTAG = 2,
            }
            
            // Register for DAP access functions
            public enum REG {
                DP_0x0 = 0,
                DP_0x4 = 1,
                DP_0x8 = 2,
                DP_0xC = 3,
                AP_0x0 = 4,
                AP_0x4 = 5,
                AP_0x8 = 6,
                AP_0xC = 7,
            }
            
            // Information ID used for call to identify
            public enum ID {
                VENDOR = 1,
                PRODUCT = 2,
                SER_NUM = 3,
                FW_VER = 4,
                DEVICE_VENDOR = 5,
                DEVICE_NAME = 6,
                CAPABILITIES = 240,
                SWO_BUFFER_SIZE = 253,
                MAX_PACKET_COUNT = 254,
                MAX_PACKET_SIZE = 255,
            }
            
            // Parent of all error DAPAccess can raise
            public class Error
                : Exception {
            }
            
            // Error communicating with device
            public class DeviceError
                : Error {
            }
            
            // The host debugger reported failure for the given command
            public class CommandError
                : DeviceError {
            }
            
            // Error ocurred with a transfer over SWD or JTAG
            public class TransferError
                : CommandError {
            }
            
            // A SWD or JTAG timeout occurred
            public class TransferTimeoutError
                : TransferError {
            }
            
            // A SWD Fault occurred
            public class TransferFaultError
                : TransferError {

                private UInt32? _address;

                public TransferFaultError(UInt32? faultAddress = null) {
                    this._address = faultAddress;
                }
                
                public UInt32? fault_address {
                    get {
                        return this._address;
                    }
                    set {
                        this._address = value;
                    }
                }
                
                public override string ToString() {
                    var desc = "SWD/JTAG Transfer Fault";
                    if (this._address != null) {
                        desc += String.Format(" @ 0x%08x", this._address);
                    }
                    return desc;
                }
            }
            
            // A SWD protocol error occurred
            public class TransferProtocolError
                : TransferError {
            }
            
            // Return a list of DAPAccess devices
            // [staticmethod]
            public static List<DAPAccessIntf> get_connected_devices() {
                throw new NotImplementedException();
            }
            
            // Return the DAPAccess device with the give ID
            // [staticmethod]
            public static object get_device(object device_id) {
                throw new NotImplementedException();
            }
            
            // Set arguments to configure behavior
            // [staticmethod]
            public static object set_args(object arg_list) {
                throw new NotImplementedException();
            }
            
            // ------------------------------------------- #
            //          Host control functions
            // ------------------------------------------- #
            // Open device and lock it for exclusive access
            public virtual void open() {
                throw new NotImplementedException();
            }
            
            // Close device and unlock it
            public virtual void close() {
                throw new NotImplementedException();
            }
            
            // Get the unique ID of this device which can be used in get_device
            // 
            //         This function is safe to call before open is called.
            //         
            public virtual string get_unique_id() {
                throw new NotImplementedException();
            }
            
            // Return the requested information for this device
            public virtual object identify(object item) {
                throw new NotImplementedException();
            }
            
            // ------------------------------------------- #
            //          Target control functions
            // ------------------------------------------- #
            // Initailize DAP IO pins for JTAG or SWD
            public virtual object connect(object port = null) {
                throw new NotImplementedException();
            }
            
            // Send seqeunce to activate JTAG or SWD on the target
            public virtual void swj_sequence() {
                throw new NotImplementedException();
            }
            
            // Deinitialize the DAP I/O pins
            public virtual void disconnect() {
                throw new NotImplementedException();
            }
            
            // Set the frequency for JTAG and SWD in Hz
            // 
            //         This function is safe to call before connect is called.
            //         
            public virtual void set_clock(object frequency) {
                throw new NotImplementedException();
            }
            
            // Return the current port type - SWD or JTAG
            public virtual PORT get_swj_mode() {
                throw new NotImplementedException();
            }
            
            // Reset the target
            public virtual void reset() {
                throw new NotImplementedException();
            }
            
            // Assert or de-assert target reset line
            public virtual void assert_reset(bool asserted) {
                throw new NotImplementedException();
            }
            
            // Allow reads and writes to be buffered for increased speed
            public virtual void set_deferred_transfer(bool enable) {
                throw new NotImplementedException();
            }
            
            // Write out all unsent commands
            public virtual void flush() {
                throw new NotImplementedException();
            }
            
            // Send a vendor specific command
            public virtual object vendor(object index, object data = null) {
                throw new NotImplementedException();
            }
            
            // ------------------------------------------- #
            //          DAP Access functions
            // ------------------------------------------- #
            // Write a single word to a DP or AP register
            public virtual void write_reg(REG reg_id, object value, byte dap_index = 0) {
                throw new NotImplementedException();
            }
            
            // Read a single word to a DP or AP register
            public virtual Func<UInt32> read_reg(REG reg_id, byte dap_index = 0, bool now = true) {
                throw new NotImplementedException();
            }
            
            // Write one or more words to the same DP or AP register
            public virtual object reg_write_repeat(UInt32 num_repeats, REG reg_id, object data_array, byte dap_index = 0) {
                throw new NotImplementedException();
            }
            
            // Read one or more words from the same DP or AP register
            public virtual List<UInt32> reg_read_repeat(UInt16 num_repeats, REG reg_id, byte dap_index = 0, bool now = true) {
                throw new NotImplementedException();
            }
        }
    }
}
