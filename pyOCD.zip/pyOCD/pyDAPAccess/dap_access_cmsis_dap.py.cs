// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace pyDAPAccess
{

    //using @absolute_import = @@__future__.absolute_import;

    //using re;

    //using logging;

    //using time;

    //using collections;

    //using six;

    //using DAPSettings = dap_settings.DAPSettings;

    //using DAPAccessIntf = dap_access_api.DAPAccessIntf;

    // using CMSIS_DAP_Protocol = cmsis_dap_core.CMSIS_DAP_Protocol;
    using pyDAPAccess;

    // using INTERFACE = Interface.INTERFACE;
    // 
    // using usb_backend = Interface.usb_backend;
    // 
    // using ws_backend = Interface.ws_backend;
    // 
    // using COMMAND_ID = cmsis_dap_core.COMMAND_ID;
    // 
    // using DAP_TRANSFER_OK = cmsis_dap_core.DAP_TRANSFER_OK;
    // 
    // using DAP_TRANSFER_FAULT = cmsis_dap_core.DAP_TRANSFER_FAULT;
    // 
    // using DAP_TRANSFER_WAIT = cmsis_dap_core.DAP_TRANSFER_WAIT;

    using System.Diagnostics;

    using System.Collections.Generic;

    using System;

    using System.Linq;
    using System.Threading;

    public static class dap_access_cmsis_dap
    {

        public const byte AP_ACC = 1 << 0;
        public const byte DP_ACC = 0 << 0;
        public const byte READ = 1 << 1;
        public const byte WRITE = 0 << 1;
        public const byte VALUE_MATCH = 1 << 4;
        public const byte MATCH_MASK = 1 << 5;
        public const bool LOG_PACKET_BUILDS = false;

        // Get the connected USB devices
        public static List<Interface.Interface> _get_interfaces()
        {
            if (dap_settings.DAPSettings.use_ws)
            {
                throw new NotImplementedException();
                //return pyDAPAccess.Interface.__init__.INTERFACE[pyDAPAccess.Interface.__init__.ws_backend].getAllConnectedInterface(DAPSettings.ws_host, DAPSettings.ws_port);
            }
            else
            {
                return Interface.hidapi_backend.HidApiUSB.getAllConnectedInterface();
                //return pyDAPAccess.Interface.__init__.INTERFACE[pyDAPAccess.Interface.__init__.usb_backend].getAllConnectedInterface();
            }
        }

        // Get the unique id from an interface
        public static string _get_unique_id(Interface.Interface anInterface)
        {
            return anInterface.getSerialNumber();
        }

        // 
        //     A wrapper object representing a command invoked by the layer above.
        // 
        //     The transfer class contains a logical register read or a block
        //     of reads to the same register.
        //     
        public class _Transfer
        {

            internal UInt32 _size_bytes;
            internal Exception _error;
            internal List<UInt32> _result;
            internal DAPAccessCMSISDAP daplink;
            internal byte dap_index;
            internal UInt32 transfer_count;
            internal byte transfer_request;
            internal object transfer_data;

            public _Transfer(
                DAPAccessCMSISDAP daplink,
                byte dap_index,
                UInt32 transfer_count,
                byte transfer_request,
                object transfer_data)
            {
                // Writes should not need a transfer object
                // since they don't have any response data
                Debug.Assert((transfer_request & READ) != 0);
                this.daplink = daplink;
                this.dap_index = dap_index;
                this.transfer_count = transfer_count;
                this.transfer_request = transfer_request;
                this.transfer_data = transfer_data;
                this._size_bytes = 0;
                if ((transfer_request & READ) != 0)
                {
                    this._size_bytes = transfer_count * 4;
                }
                this._result = null;
                this._error = null;
            }

            // 
            //         Get the size in bytes of the return value of this transfer
            //         
            public virtual UInt32 get_data_size()
            {
                return this._size_bytes;
            }

            // 
            //         Add data read from the remote device to this object.
            // 
            //         The size of data added must match exactly the size
            //         that get_data_size returns.
            //         
            public virtual void add_response(List<byte> data)
            {
                Debug.Assert(data.Count == this._size_bytes);
                Debug.Assert(this._size_bytes % 4 == 0);
                List<UInt32> result = new List<UInt32>();
                foreach (var i in Enumerable.Range(0, (int)this._size_bytes / 4))
                {
                    var word = (UInt32)((data[0 + i*4] << 0) | (data[1 + i] << 8) | (data[2 + i] << 16) | (data[3 + i] << 24));
                    result.Add(word);
                }
                this._result = result;
            }

            // 
            //         Attach an exception to this transfer rather than data.
            //         
            public virtual void add_error(Exception error)
            {
                Debug.Assert(error is Exception);
                this._error = error;
            }

            // 
            //         Get the result of this transfer.
            //         
            public virtual List<UInt32> get_result()
            {
                while (this._result == null)
                {
                    if (this.daplink._commands_to_read.Count > 0)
                    {
                        this.daplink._read_packet();
                    }
                    else
                    {
                        Debug.Assert(!this.daplink._crnt_cmd.get_empty());
                        this.daplink.flush();
                    }
                }
                if (this._error != null)
                {
                    // Pylint is confused and thinks self._error is None
                    // since that is what it is initialized to.
                    // Supress warnings for this.
                    // pylint: disable=raising-bad-type
                    throw this._error;
                }
                Debug.Assert(this._result != null);
                return this._result;
            }
        }

        // 
        //     A wrapper object representing a command send to the layer below (ex. USB).
        // 
        //     This class wraps the phyiscal commands DAP_Transfer and DAP_TransferBlock
        //     to provide a uniform way to build the command to most efficiently transfer
        //     the data supplied.  Register reads and writes individually or in blocks
        //     are added to a command object until it is full.  Once full, this class
        //     decides if it is more efficient to use DAP_Transfer or DAP_TransferBlock.
        //     The payload to send over the layer below is constructed with
        //     encode_data.  The response to the command is decoded with decode_data.
        //     
        public class _Command
        {

            internal UInt32 _size;
            internal UInt16 _read_count;
            internal UInt16 _write_count;
            internal bool _block_allowed;
            internal byte? _block_request;
            internal bool _data_encoded;
            internal byte? _dap_index;
            internal List<Tuple<UInt16, byte, List<UInt32>>> _data;

            public _Command(UInt32 size)
            {
                this._size = size;
                this._read_count = 0;
                this._write_count = 0;
                this._block_allowed = true;
                this._block_request = null;
                this._data = new List<Tuple<UInt16, byte, List<UInt32>>>();
                this._dap_index = null;
                this._data_encoded = false;
                if (LOG_PACKET_BUILDS)
                {
                    //this._logger = logging.getLogger(@__name__);
                    Trace.TraceInformation("New _Command");
                }
            }

            // 
            //         Return the number of words free in the transmit packet
            //         
            public virtual UInt16 _get_free_words(bool blockAllowed, bool isRead)
            {
                UInt16 recv;
                UInt16 send;
                if (blockAllowed)
                {
                    // DAP_TransferBlock request packet:
                    //   BYTE | BYTE *****| SHORT**********| BYTE *************| WORD *********|
                    // > 0x06 | DAP Index | Transfer Count | Transfer Request  | Transfer Data |
                    //  ******|***********|****************|*******************|+++++++++++++++|
                    send = (UInt16)(this._size - 5 - 4 * this._write_count);
                    // DAP_TransferBlock response packet:
                    //   BYTE | SHORT *********| BYTE *************| WORD *********|
                    // < 0x06 | Transfer Count | Transfer Response | Transfer Data |
                    //  ******|****************|*******************|+++++++++++++++|
                    recv = (UInt16)(this._size - 4 - 4 * this._read_count);
                    if (isRead)
                    {
                        return (UInt16)(recv / 4);
                    }
                    else
                    {
                        return (UInt16)(send / 4);
                    }
                }
                else
                {
                    // DAP_Transfer request packet:
                    //   BYTE | BYTE *****| BYTE **********| BYTE *************| WORD *********|
                    // > 0x05 | DAP Index | Transfer Count | Transfer Request  | Transfer Data |
                    //  ******|***********|****************|+++++++++++++++++++++++++++++++++++|
                    send = (UInt16)(this._size - 3 - 1 * this._read_count - 5 * this._write_count);
                    // DAP_Transfer response packet:
                    //   BYTE | BYTE **********| BYTE *************| WORD *********|
                    // < 0x05 | Transfer Count | Transfer Response | Transfer Data |
                    //  ******|****************|*******************|+++++++++++++++|
                    recv = (UInt16)(this._size - 3 - 4 * this._read_count);
                    if (isRead)
                    {
                        // 1 request byte in request packet, 4 data bytes in response packet
                        return Math.Min(send, (UInt16)(recv / 4));
                    }
                    else
                    {
                        // 1 request byte + 4 data bytes
                        return (UInt16)(send / 5);
                    }
                }
            }

            public virtual UInt16 get_request_space(UInt16 count, byte request, byte dap_index)
            {
                Debug.Assert(object.ReferenceEquals(this._data_encoded, false));
                // Must create another command if the dap index is different.
                if (this._dap_index != null && dap_index != this._dap_index)
                {
                    return 0;
                }
                // Block transfers must use the same request.
                var blockAllowed = this._block_allowed;
                if (this._block_request != null && request != this._block_request)
                {
                    blockAllowed = false;
                }
                // Compute the portion of the request that will fit in this packet.
                bool is_read = (request & READ) != 0;
                UInt16 free = this._get_free_words(blockAllowed, is_read);
                int size = Math.Min(count, free);
                // Non-block transfers only have 1 byte for request count.
                if (!blockAllowed)
                {
                    UInt16 max_count = (UInt16)(this._write_count + this._read_count + size);
                    UInt16 delta = (UInt16)(max_count - 255);
                    size = Math.Min(size - delta, size);
                    if (LOG_PACKET_BUILDS)
                    {
                        Trace.TraceInformation(String.Format("get_request_space(%d, %02x:%s)[wc=%d, rc=%d, ba=%d->%d] -> (sz=%d, free=%d, delta=%d)", count, request, is_read ? "r" : "w", this._write_count, this._read_count, this._block_allowed, blockAllowed, size, free, delta));
                    }
                }
                else if (LOG_PACKET_BUILDS)
                {
                    Trace.TraceInformation(String.Format("get_request_space(%d, %02x:%s)[wc=%d, rc=%d, ba=%d->%d] -> (sz=%d, free=%d)", count, request, is_read ? "r" : "w", this._write_count, this._read_count, this._block_allowed, blockAllowed, size, free));
                }
                // We can get a negative free count if the packet already contains more data than can be
                // sent by a DAP_Transfer command, but the new request forces DAP_Transfer. In this case,
                // just return 0 to force the DAP_Transfer_Block to be sent.
                return (UInt16)Math.Max(size, 0);
            }

            public virtual bool get_full()
            {
                return this._get_free_words(this._block_allowed, true) == 0 || this._get_free_words(this._block_allowed, false) == 0;
            }

            // 
            //         Return True if no transfers have been added to this packet
            //         
            public virtual bool get_empty()
            {
                return this._data.Count == 0;
            }

            // 
            //         Add a single or block register transfer operation to this command
            //         
            public virtual void add(UInt16 count, byte request, List<UInt32> data, byte dap_index)
            {
                Debug.Assert(object.ReferenceEquals(this._data_encoded, false));
                if (this._dap_index == null)
                {
                    this._dap_index = dap_index;
                }
                Debug.Assert(this._dap_index == dap_index);
                if (this._block_request == null)
                {
                    this._block_request = request;
                }
                else if (request != this._block_request)
                {
                    this._block_allowed = false;
                }
                Debug.Assert(!this._block_allowed || this._block_request == request);
                if ((request & READ) != 0)
                {
                    this._read_count += count;
                }
                else
                {
                    this._write_count += count;
                }
                this._data.Add(Tuple.Create(count, request, data));
                if (LOG_PACKET_BUILDS)
                {
                    //Trace.TraceInformation(String.Format("add(%d, %02x:%s) -> [wc=%d, rc=%d, ba=%d]", count, request, request & READ ? "r" : "w", this._write_count, this._read_count, this._block_allowed));
                }
            }

            // 
            //         Encode this command into a byte array that can be sent
            // 
            //         The data returned by this function is a bytearray in
            //         the format that of a DAP_Transfer CMSIS-DAP command.
            //         
            public virtual byte[] _encode_transfer_data()
            {
                Debug.Assert(this.get_empty() == false);
                byte[] buf = new byte[this._size];
                byte transfer_count = (byte)(this._read_count + this._write_count);
                var pos = 0;
                buf[pos] = cmsis_dap_core.COMMAND_ID["DAP_TRANSFER"];
                pos += 1;
                buf[pos] = (byte)this._dap_index;
                pos += 1;
                buf[pos] = (byte)transfer_count;
                pos += 1;
                foreach (var _tup_1 in this._data)
                {
                    UInt32 count = _tup_1.Item1;
                    var request = _tup_1.Item2;
                    List<UInt32> write_list = _tup_1.Item3;
                    Debug.Assert(write_list == null || write_list.Count<= count);
                    var write_pos = 0;
                    foreach (var _ in Enumerable.Range(0, (int)count))
                    {
                        buf[pos] = request;
                        pos += 1;
                        if ((request & READ) == 0)
                        {
                            buf[pos] = (byte)((write_list[write_pos] >> 8 * 0) & 255);
                            pos += 1;
                            buf[pos] = (byte)((write_list[write_pos] >> 8 * 1) & 255);
                            pos += 1;
                            buf[pos] = (byte)((write_list[write_pos] >> 8 * 2) & 255);
                            pos += 1;
                            buf[pos] = (byte)((write_list[write_pos] >> 8 * 3) & 255);
                            pos += 1;
                            write_pos += 1;
                        }
                    }
                }
                return buf;
            }

            // 
            //         Take a byte array and extract the data from it
            // 
            //         Decode the response returned by a DAP_Transfer CMSIS-DAP command
            //         and return it as an array of bytes.
            //         
            public virtual List<byte> _decode_transfer_data(List<byte> data)
            {
                Debug.Assert(this.get_empty() == false);
                if (data[0] != cmsis_dap_core.COMMAND_ID["DAP_TRANSFER"])
                {
                    throw new ArgumentOutOfRangeException("DAP_TRANSFER response error");
                }
                if (data[2] != cmsis_dap_core.DAP_TRANSFER_OK)
                {
                    if (data[2] == cmsis_dap_core.DAP_TRANSFER_FAULT)
                    {
                        throw new dap_access_api.DAPAccessIntf.TransferFaultError();
                    }
                    else if (data[2] == cmsis_dap_core.DAP_TRANSFER_WAIT)
                    {
                        throw new dap_access_api.DAPAccessIntf.TransferTimeoutError();
                    }
                    throw new dap_access_api.DAPAccessIntf.TransferError();
                }
                // Check for count mismatch after checking for DAP_TRANSFER_FAULT
                // This allows TransferFaultError or TransferTimeoutError to get
                // thrown instead of TransferFaultError
                if (data[1] != this._read_count + this._write_count)
                {
                    throw new dap_access_api.DAPAccessIntf.TransferError();
                }
                return data.GetRange(3, 4 * this._read_count);
            }

            // 
            //         Encode this command into a byte array that can be sent
            // 
            //         The data returned by this function is a bytearray in
            //         the format that of a DAP_TransferBlock CMSIS-DAP command.
            //         
            public virtual byte[] _encode_transfer_block_data()
            {
                Debug.Assert(this.get_empty() == false);
                byte[] buf = new byte[this._size];
                UInt16 transfer_count = (UInt16)(this._read_count + this._write_count);
                Debug.Assert(!(this._read_count != 0 && this._write_count != 0));
                Debug.Assert(this._block_request != null);
                var pos = 0;
                buf[pos] = cmsis_dap_core.COMMAND_ID["DAP_TRANSFER_BLOCK"];
                pos += 1;
                buf[pos] = (byte)this._dap_index;
                pos += 1;
                buf[pos] = (byte)(transfer_count & 0xFF);
                pos += 1;
                buf[pos] = (byte)((transfer_count >> 8) & 0xFF);
                pos += 1;
                buf[pos] = (byte)this._block_request;
                pos += 1;
                foreach (var _tup_1 in this._data)
                {
                    UInt32 count = _tup_1.Item1;
                    var request = _tup_1.Item2;
                    List<UInt32> write_list = _tup_1.Item3;
                    Debug.Assert(write_list == null || write_list.Count <= count);
                    Debug.Assert(request == this._block_request);
                    var write_pos = 0;
                    if ((request & READ) == 0)
                    {
                        foreach (var _ in Enumerable.Range(0, (int)count))
                        {
                            buf[pos] = (byte)((write_list[write_pos] >> 8) * 0 & 0xFF);
                            pos += 1;
                            buf[pos] = (byte)((write_list[write_pos] >> 8) * 1 & 0xFF);
                            pos += 1;
                            buf[pos] = (byte)((write_list[write_pos] >> 8) * 2 & 0xFF);
                            pos += 1;
                            buf[pos] = (byte)((write_list[write_pos] >> 8) * 3 & 0xFF);
                            pos += 1;
                            write_pos += 1;
                        }
                    }
                }
                return buf;
            }

            // 
            //         Take a byte array and extract the data from it
            // 
            //         Decode the response returned by a DAP_TransferBlock CMSIS-DAP command
            //         and return it as an array of bytes.
            //         
            public virtual List<byte> _decode_transfer_block_data(List<byte> data)
            {
                Debug.Assert(this.get_empty() == false);
                if (data[0] != cmsis_dap_core.COMMAND_ID["DAP_TRANSFER_BLOCK"])
                {
                    throw new ArgumentOutOfRangeException("DAP_TRANSFER_BLOCK response error");
                }
                if (data[3] != cmsis_dap_core.DAP_TRANSFER_OK)
                {
                    if (data[3] == cmsis_dap_core.DAP_TRANSFER_FAULT)
                    {
                        throw new dap_access_api.DAPAccessIntf.TransferFaultError();
                    }
                    else if (data[3] == cmsis_dap_core.DAP_TRANSFER_WAIT)
                    {
                        throw new dap_access_api.DAPAccessIntf.TransferTimeoutError();
                    }
                    throw new dap_access_api.DAPAccessIntf.TransferError();
                }
                // Check for count mismatch after checking for DAP_TRANSFER_FAULT
                // This allows TransferFaultError or TransferTimeoutError to get
                // thrown instead of TransferFaultError
                var transfer_count = data[1] | data[2] << 8;
                if (transfer_count != this._read_count + this._write_count)
                {
                    throw new dap_access_api.DAPAccessIntf.TransferError();
                }
                return data.GetRange(4, 4 * this._read_count);
            }

            // 
            //         Encode this command into a byte array that can be sent
            // 
            //         The actual command this is encoded into depends on the data
            //         that was added.
            //         
            public virtual byte[] encode_data()
            {
                byte[] data;
                Debug.Assert(this.get_empty() == false);
                this._data_encoded = true;
                if (this._block_allowed)
                {
                    data = this._encode_transfer_block_data();
                }
                else
                {
                    data = this._encode_transfer_data();
                }
                return data;
            }

            // 
            //         Decode the response data
            //         
            public virtual List<byte> decode_data(List<byte> data)
            {
                Debug.Assert(this.get_empty() == false);
                Debug.Assert(object.ReferenceEquals(this._data_encoded, true));
                if (this._block_allowed)
                {
                    data = this._decode_transfer_block_data(data);
                }
                else
                {
                    data = this._decode_transfer_data(data);
                }
                return data;
            }
        }

        // 
        //     An implementation of the DAPAccessIntf layer for DAPLINK boards
        //     
        public class DAPAccessCMSISDAP
            : dap_access_api.DAPAccessIntf
        {

            // ------------------------------------------- #
            //          Static Functions
            // ------------------------------------------- #
            // 
            //         Return an array of all mbed boards connected
            //         
            // [staticmethod]
            public static new List<dap_access_api.DAPAccessIntf> get_connected_devices()
            {
                List<dap_access_api.DAPAccessIntf> all_daplinks = new List<dap_access_api.DAPAccessIntf>();
                var all_interfaces = _get_interfaces();
                foreach (var anInterface in all_interfaces)
                {
                    try
                    {
                        var unique_id = _get_unique_id(anInterface);
                        DAPAccessCMSISDAP new_daplink = new DAPAccessCMSISDAP(unique_id);
                        all_daplinks.Add(new_daplink);
                    }
                    catch
                    {
                        //var logger = logging.getLogger(@__name__);
                        Trace.TraceError("Failed to get unique id");
                    }
                }
                return all_daplinks;
            }

            // [staticmethod]
            public static object get_device(string device_id)
            {
                //Debug.Assert(device_id is six.string_types);
                return new DAPAccessCMSISDAP(device_id);
            }

            // [staticmethod]
            // public static object set_args(object arg_list)
            // {
            //     // Example: arg_list =['use_ws=True', 'ws_host=localhost', 'ws_port=8081']
            //     var arg_pattern = re.compile("([^=]+)=(.*)");
            //     if (arg_list)
            //     {
            //         foreach (var arg in arg_list)
            //         {
            //             var match = arg_pattern.match(arg);
            //             // check if arguments have correct format
            //             if (match)
            //             {
            //                 var attr = match.group(1);
            //                 if (hasattr(dap_settings.DAPSettings, attr))
            //                 {
            //                     var val = match.group(2);
            //                     // convert string to int or bool
            //                     if (val.isdigit())
            //                     {
            //                         val = Convert.ToInt32(val);
            //                     }
            //                     else if (val == "True")
            //                     {
            //                         val = true;
            //                     }
            //                     else if (val == "False")
            //                     {
            //                         val = false;
            //                     }
            //                     setattr(dap_settings.DAPSettings, attr, val);
            //                 }
            //             }
            //         }
            //     }
            // }

            private Interface.Interface _interface;
            private bool _deferred_transfer;
            private cmsis_dap_core.CMSIS_DAP_Protocol _protocol;
            private UInt16? _packet_count;
            private string _unique_id;
            private UInt32 _frequency;
            private dap_access_api.DAPAccessIntf.PORT? _dap_port;
            private List<_Transfer> _transfer_list;
            internal _Command _crnt_cmd;
            private UInt16? _packet_size;
            internal List<_Command> _commands_to_read;
            private List<byte> _command_response_buf;

            public DAPAccessCMSISDAP(string unique_id) : base()
            {
                // Debug.Assert(unique_id is six.string_types);
                // super(DAPAccessCMSISDAP, this).@__init__();
                this._interface = null;
                this._deferred_transfer = false;
                this._protocol = null;
                this._packet_count = null;
                this._unique_id = unique_id;
                this._frequency = 1000000;
                this._dap_port = null;
                this._transfer_list = null;
                this._crnt_cmd = null;
                this._packet_size = null;
                this._commands_to_read = null;
                this._command_response_buf = null;
                //this._logger = logging.getLogger(@__name__);
                return;
            }

            public override void open()
            {
                if (this._interface == null)
                {
                    var all_interfaces = _get_interfaces();
                    foreach (var anInterface in all_interfaces)
                    {
                        try
                        {
                            string unique_id = _get_unique_id(anInterface);
                            if (this._unique_id == unique_id)
                            {
                                // This assert could indicate that two boards
                                // had the same ID
                                Debug.Assert(this._interface == null);
                                this._interface = anInterface;
                            }
                        }
                        catch (Exception)
                        {
                            Trace.TraceError("Failed to get unique id for open");
                        }
                    }
                    if (this._interface == null)
                    {
                        throw new Exception("Unable to open device", new dap_access_api.DAPAccessIntf.DeviceError());
                    }
                }
                this._interface.open();
                this._protocol = new cmsis_dap_core.CMSIS_DAP_Protocol(this._interface);
                if (dap_settings.DAPSettings.limit_packets)
                {
                    this._packet_count = 1;
                    Trace.TraceInformation("Limiting packet count to %d", this._packet_count);
                }
                else
                {
                    this._packet_count = (UInt16)this._protocol.dapInfo(cmsis_dap_core.ID_INFO["PACKET_COUNT"]);
                }
                this._interface.setPacketCount((UInt16)this._packet_count);
                this._packet_size = (UInt16)this._protocol.dapInfo(cmsis_dap_core.ID_INFO["PACKET_SIZE"]);
                this._interface.setPacketSize((UInt16)this._packet_size);
                this._init_deferred_buffers();
            }

            public override void close()
            {
                Debug.Assert(this._interface != null);
                this.flush();
                this._interface.close();
            }

            public override string get_unique_id()
            {
                return this._unique_id;
            }

            public override void reset()
            {
                this.flush();
                this._protocol.setSWJPins(0, "nRESET");
                Thread.Sleep(100);
                this._protocol.setSWJPins(128, "nRESET");
                Thread.Sleep(100);
            }

            public override void assert_reset(bool asserted)
            {
                this.flush();
                if (asserted)
                {
                    this._protocol.setSWJPins(0, "nRESET");
                }
                else
                {
                    this._protocol.setSWJPins(128, "nRESET");
                }
            }

            public void set_clock(UInt32 frequency)
            {
                this.flush();
                this._protocol.setSWJClock(frequency);
                this._frequency = frequency;
            }

            public override PORT get_swj_mode()
            {
                return (PORT)this._dap_port;
            }

            // 
            //         Allow transfers to be delayed and buffered
            // 
            //         By default deferred transfers are turned off.  All reads and
            //         writes will be completed by the time the function returns.
            // 
            //         When enabled packets are buffered and sent all at once, which
            //         increases speed.  When memory is written to, the transfer
            //         might take place immediately, or might take place on a future
            //         memory write.  This means that an invalid write could cause an
            //         exception to occur on a later, unrelated write.  To guarantee
            //         that previous writes are complete call the flush() function.
            // 
            //         The behaviour of read operations is determined by the modes
            //         READ_START, READ_NOW and READ_END.  The option READ_NOW is the
            //         default and will cause the read to flush all previous writes,
            //         and read the data immediately.  To improve performance, multiple
            //         reads can be made using READ_START and finished later with READ_NOW.
            //         This allows the reads to be buffered and sent at once.  Note - All
            //         READ_ENDs must be called before a call using READ_NOW can be made.
            //         
            public override void set_deferred_transfer(bool enable)
            {
                if (this._deferred_transfer && !enable)
                {
                    this.flush();
                }
                this._deferred_transfer = enable;
            }

            public override void flush()
            {
                // Send current packet
                this._send_packet();
                // Read all backlogged
                foreach (var _ in Enumerable.Range(0, this._commands_to_read.Count))
                {
                    this._read_packet();
                }
            }

            public virtual object identify(dap_access_api.DAPAccessIntf.ID item)
            {
                Debug.Assert(item is dap_access_api.DAPAccessIntf.ID);
                return this._protocol.dapInfo(item);
            }

            public virtual byte vendor(byte index, List<byte> data = null)
            {
                if (data == null)
                {
                    data = new List<byte>();
                }
                return this._protocol.vendor(index, data);
            }

            // ------------------------------------------- #
            //             Target access functions
            // ------------------------------------------- #
            public virtual void connect(dap_access_api.DAPAccessIntf.PORT port = dap_access_api.DAPAccessIntf.PORT.DEFAULT)
            {
                Debug.Assert(port is dap_access_api.DAPAccessIntf.PORT);
                dap_access_api.DAPAccessIntf.PORT actual_port = this._protocol.connect(port);
                this._dap_port = actual_port;
                // set clock frequency
                this._protocol.setSWJClock(this._frequency);
                // configure transfer
                this._protocol.transferConfigure();
            }

            public override void swj_sequence()
            {
                if (this._dap_port == dap_access_api.DAPAccessIntf.PORT.SWD)
                {
                    // configure swd protocol
                    this._protocol.swdConfigure();
                    // switch from jtag to swd
                    this._jtag_to_swd();
                }
                else if (this._dap_port == dap_access_api.DAPAccessIntf.PORT.JTAG)
                {
                    // configure jtag protocol
                    this._protocol.jtagConfigure(4);
                    // Test logic reset, run test idle
                    this._protocol.swjSequence(new List<byte> {
                        31
                    });
                }
                else
                {
                    Debug.Assert(false);
                }
            }

            public override void disconnect()
            {
                this.flush();
                this._protocol.disconnect();
            }

            public virtual void write_reg(REG reg_id, UInt32 value, byte dap_index = 0)
            {
                Debug.Assert(Enum.IsDefined(typeof(REG), reg_id));
                byte request = WRITE;
                if ((int)reg_id < 4)
                {
                    request |= DP_ACC;
                }
                else
                {
                    request |= AP_ACC;
                }
                request |= (byte)((int)reg_id % 4 * 4);
                this._write(dap_index, 1, request, new List<UInt32> {
                    value
                });
            }

            public override object read_reg(REG reg_id, byte dap_index = 0, bool now = true)
            {
                Debug.Assert(Enum.IsDefined(typeof(REG), reg_id));
                //Debug.Assert(dap_index is six.integer_types);
                byte request = READ;
                if ((int)reg_id < 4)
                {
                    request |= DP_ACC;
                }
                else
                {
                    request |= AP_ACC;
                }
                request |= (byte)((int)reg_id % 4 << 2);
                var transfer = this._write(dap_index, 1, request, null);
                Debug.Assert(transfer != null);
                Func<UInt32> read_reg_cb = () =>
                {
                    List<UInt32> res = transfer.get_result();
                    Debug.Assert(res.Count == 1);
                    return res[0];
                };
                if (now)
                {
                    return read_reg_cb();
                }
                else
                {
                    return read_reg_cb;
                }
            }

            public virtual void reg_write_repeat(UInt16 num_repeats, REG reg_id, List<UInt32> data_array, byte dap_index = 0)
            {
                //Debug.Assert(num_repeats is six.integer_types);
                Debug.Assert(num_repeats == data_array.Count);
                Debug.Assert(Enum.IsDefined(typeof(REG), reg_id));
                //Debug.Assert(dap_index is six.integer_types);
                byte request = WRITE;
                if ((int)reg_id < 4)
                {
                    request |= DP_ACC;
                }
                else
                {
                    request |= AP_ACC;
                }
                request |= (byte)((int)reg_id % 4 * 4);
                this._write(dap_index, num_repeats, request, data_array);
            }

            public override List<UInt32> reg_read_repeat(UInt16 num_repeats, REG reg_id, byte dap_index = 0, bool now = true)
            {
                //Debug.Assert(num_repeats is six.integer_types);
                Debug.Assert(Enum.IsDefined(typeof(REG), reg_id));
                //Debug.Assert(dap_index is six.integer_types);
                //Debug.Assert(now is @bool);
                var request = READ;
                if ((int)reg_id < 4)
                {
                    request |= DP_ACC;
                }
                else
                {
                    request |= AP_ACC;
                }
                request |= (byte)((int)reg_id % 4 * 4);
                var transfer = this._write(dap_index, num_repeats, request, null);
                Debug.Assert(transfer != null);
                Func<List<UInt32>> reg_read_repeat_cb = () =>
                {
                    List<UInt32> res = transfer.get_result();
                    Debug.Assert(res.Count == num_repeats);
                    return res;
                };
                if (now)
                {
                    return reg_read_repeat_cb();
                }
                else
                {
                    return reg_read_repeat_cb;
                }
            }

            // ------------------------------------------- #
            //          Private functions
            // ------------------------------------------- #
            // 
            //         Initialize or reinitalize all the deferred transfer buffers
            // 
            //         Calling this method will drop all pending transactions
            //         so use with care.
            //         
            public virtual void _init_deferred_buffers()
            {
                // List of transfers that have been started, but
                // not completed (started by write_reg, read_reg,
                // reg_write_repeat and reg_read_repeat)
                this._transfer_list = new List<_Transfer>(); // collections.deque();
                // The current packet - this can contain multiple
                // different transfers
                this._crnt_cmd = new _Command((UInt16)this._packet_size);
                // Packets that have been sent but not read
                this._commands_to_read = new List<_Command>(); // collections.deque();
                // Buffer for data returned for completed commands.
                // This data will be added to transfers
                this._command_response_buf = new List<byte>();
            }

            // 
            //         Reads and decodes a single packet
            // 
            //         Reads a single packet from the device and
            //         stores the data from it in the current Command
            //         object
            //         
            public virtual void _read_packet()
            {
                List<byte> decoded_data;
                // Grab command, send it and decode response
                _Command cmd = this._commands_to_read[0];
                this._commands_to_read.RemoveAt(0); // popleft();
                try
                {
                    List<byte> raw_data = this._interface.read();
                    decoded_data = cmd.decode_data(raw_data);
                }
                catch (Exception e)
                {
                    this._abort_all_transfers(e);
                    throw;
                }
                //decoded_data = bytearray(decoded_data);
                this._command_response_buf.AddRange(decoded_data);
                // Attach data to transfers
                UInt32 pos = 0;
                while (true)
                {
                    var size_left = this._command_response_buf.Count - pos;
                    if (size_left == 0)
                    {
                        // If size left is 0 then the transfer list might
                        // be empty, so don't try to access element 0
                        break;
                    }
                    var transfer = this._transfer_list[0];
                    UInt32 size = transfer.get_data_size();
                    if (size > size_left)
                    {
                        break;
                    }
                    this._transfer_list.RemoveAt(0); // popleft();
                    var data = this._command_response_buf.GetRange((int)pos, (int)size);
                    pos += size;
                    transfer.add_response(data);
                }
                // Remove used data from _command_response_buf
                if (pos > 0)
                {
                    this._command_response_buf = this._command_response_buf.GetRange((int)pos, (int)(this._command_response_buf.Count - pos));
                }
            }

            // 
            //         Send a single packet to the interface
            // 
            //         This function guarentees that the number of packets
            //         that are stored in daplink's buffer (the number of
            //         packets written but not read) does not exceed the
            //         number supported by the given device.
            //         
            public virtual void _send_packet()
            {
                var cmd = this._crnt_cmd;
                if (cmd.get_empty())
                {
                    return;
                }
                var max_packets = this._interface.getPacketCount();
                if (this._commands_to_read.Count >= max_packets)
                {
                    this._read_packet();
                }
                var data = cmd.encode_data();
                try
                {
                    this._interface.write(data.ToList());
                }
                catch (Exception e)
                {
                    this._abort_all_transfers(e);
                    throw;
                }
                this._commands_to_read.Add(cmd);
                this._crnt_cmd = new _Command((UInt16)this._packet_size);
            }

            // 
            //         Write one or more commands
            //         
            public virtual _Transfer _write(byte dap_index, UInt16 transfer_count, byte transfer_request, List<UInt32> transfer_data)
            {
                List<UInt32> data;
                Debug.Assert(dap_index == 0);
                //Debug.Assert(transfer_count is six.integer_types);
                //Debug.Assert(transfer_request is six.integer_types);
                Debug.Assert(transfer_data == null || transfer_data.Count > 0);
                // Create transfer and add to transfer list
                _Transfer transfer = null;
                if ((transfer_request & READ) != 0)
                {
                    transfer = new _Transfer(this, dap_index, transfer_count, transfer_request, transfer_data);
                    this._transfer_list.Add(transfer);
                }
                // Build physical packet by adding it to command
                var cmd = this._crnt_cmd;
                var is_read = transfer_request & READ;
                UInt16 size_to_transfer = transfer_count;
                UInt16 trans_data_pos = 0;
                while (size_to_transfer > 0)
                {
                    // Get the size remaining in the current packet for the given request.
                    UInt16 size = cmd.get_request_space(size_to_transfer, transfer_request, dap_index);
                    // This request doesn't fit in the packet so send it.
                    if (size == 0)
                    {
                        if (LOG_PACKET_BUILDS)
                        {
                            Trace.TraceInformation("_write: send packet [size==0]");
                        }
                        this._send_packet();
                        cmd = this._crnt_cmd;
                        continue;
                    }
                    // Add request to packet.
                    if (transfer_data == null)
                    {
                        data = null;
                    }
                    else
                    {
                        data = transfer_data.GetRange(trans_data_pos, size);
                    }
                    cmd.add(size, transfer_request, data, dap_index);
                    size_to_transfer -= size;
                    trans_data_pos += size;
                    // Packet has been filled so send it
                    if (cmd.get_full())
                    {
                        if (LOG_PACKET_BUILDS)
                        {
                            Trace.TraceInformation("_write: send packet [full]");
                        }
                        this._send_packet();
                        cmd = this._crnt_cmd;
                    }
                }
                if (!this._deferred_transfer)
                {
                    this.flush();
                }
                return transfer;
            }

            // 
            //         Send the command to switch from SWD to jtag
            //         
            public virtual void _jtag_to_swd()
            {
                List<byte> data = new List<byte>() {
                    255,
                    255,
                    255,
                    255,
                    255,
                    255,
                    255
                };
                this._protocol.swjSequence(data);
                data = new List<byte>() {
                    158,
                    231
                };
                this._protocol.swjSequence(data);
                data = new List<byte>() {
                    255,
                    255,
                    255,
                    255,
                    255,
                    255,
                    255
                };
                this._protocol.swjSequence(data);
                data = new List<byte>() {
                    0
                };
                this._protocol.swjSequence(data);
            }

            // 
            //         Abort any ongoing transfers and clear all buffers
            //         
            public virtual void _abort_all_transfers(Exception exception)
            {
                var pending_reads = this._commands_to_read.Count;
                // invalidate _transfer_list
                foreach (var transfer in this._transfer_list)
                {
                    transfer.add_error(exception);
                }
                // clear all deferred buffers
                this._init_deferred_buffers();
                // finish all pending reads and ignore the data
                // Only do this if the error is a tranfer error.
                // Otherwise this could cause another exception
                if (exception is dap_access_api.DAPAccessIntf.TransferError)
                {
                    foreach (var _ in Enumerable.Range(0, pending_reads))
                    {
                        this._interface.read();
                    }
                }
            }
        }
    }
}
