// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace pyDAPAccess.Interface
{

    //using os;

    //using logging;

    using HidApiUSB = hidapi_backend.HidApiUSB;

    //using PyUSB = pyusb_backend.PyUSB;

    //using PyWinUSB = pywinusb_backend.PyWinUSB;

    //using WebSocketInterface = ws_backend.WebSocketInterface;

    using System.Collections.Generic;
    using System;

    public static class @__init__
    {

        public static Dictionary<string, Type> INTERFACE = new Dictionary<string, Type>()
        {
            {"hidapiusb", typeof(HidApiUSB)},
            //{"pyusb", PyUSB},
            //{"pywinusb", PyWinUSB},
            //{"ws", WebSocketInterface}
        };

        //public static object usb_backend = os.getenv("PYOCD_USB_BACKEND", "");

        static @__init__()
        {
            usb_backend = Environment.GetEnvironmentVariable("PYOCD_USB_BACKEND");
            if (String.IsNullOrWhiteSpace(usb_backend)) usb_backend = "hidapiusb";
            // Check validity of backend env var.
            if ((!String.IsNullOrWhiteSpace(usb_backend))
                && (
                (!INTERFACE.ContainsKey(usb_backend))
                //||
                //(!INTERFACE[usb_backend].isAvailable)
                ))
            {
                throw new Exception("Invalid USB backend specified in PYOCD_USB_BACKEND: " + usb_backend);
                // Trace.TraceError("Invalid USB backend specified in PYOCD_USB_BACKEND: " + usb_backend);
            }
        }

        public static string ws_backend = "ws";
        //public static string usb_backend = "";
        public static string usb_backend = "hidapiusb";

        //public static object usb_backend = "pywinusb";

        //public static object usb_backend = "hidapiusb";

        //public static object usb_backend = "pyusb";
    }
}
