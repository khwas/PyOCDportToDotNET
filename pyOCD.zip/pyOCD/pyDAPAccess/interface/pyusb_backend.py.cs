// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace pyDAPAccess.Interface {
    
    using logging;
    
    using os;
    
    using threading;
    
    using DAPAccessIntf = dap_access_api.DAPAccessIntf;
    
    using usb.core;
    
    using usb.util;
    
    using System.Collections.Generic;
    
    using System.Diagnostics;
    
    using System;
    
    public static class pyusb_backend {
        
        static pyusb_backend() {
            Trace.TraceError("PyUSB is required on a Linux Machine");
        }
        
        public static object isAvailable = false;
        
        // 
        //     This class provides basic functions to access
        //     a USB HID device using pyusb:
        //         - write/read an endpoint
        //     
        public class PyUSB
            : Interface {
            
            public object isAvailable = isAvailable;
            
            public PyUSB() {
                this.ep_out = null;
                this.ep_in = null;
                this.dev = null;
                this.intf_number = null;
                this.serial_number = null;
                this.kernel_driver_was_attached = false;
                this.closed = true;
                this.thread = null;
                this.rcv_data = new List<object>();
                this.read_sem = threading.Semaphore(0);
                this.packet_size = 64;
            }
            
            public virtual object open() {
                Debug.Assert(object.ReferenceEquals(this.closed, true));
                // Get device handle
                var dev = usb.core.find(custom_match: FindDap(this.serial_number));
                if (dev == null) {
                    throw new DAPAccessIntf.DeviceError(String.Format("Device %s not found", this.serial_number));
                }
                // get active config
                var config = dev.get_active_configuration();
                // Get hid interface
                object anInterface = null;
                object interface_number = null;
                foreach (var anInterface in config) {
                    if (anInterface.bInterfaceClass == 3) {
                        interface_number = anInterface.bInterfaceNumber;
                        break;
                    }
                }
                if (interface_number == null || anInterface == null) {
                    throw new DAPAccessIntf.DeviceError(String.Format("Device %s has no hid interface", this.serial_number));
                }
                // Find endpoints
                object ep_in = null;
                object ep_out = null;
                foreach (var endpoint in anInterface) {
                    if (endpoint.bEndpointAddress & 128) {
                        ep_in = endpoint;
                    } else {
                        ep_out = endpoint;
                    }
                }
                // If there is no EP for OUT then we can use CTRL EP.
                // The IN EP is required
                if (!ep_in) {
                    throw new DAPAccessIntf.DeviceError("Unable to open device -\" no endpoints\"");
                }
                // Detach kernel driver
                var kernel_driver_was_attached = false;
                try {
                    if (dev.is_kernel_driver_active(interface_number)) {
                        dev.detach_kernel_driver(interface_number);
                        kernel_driver_was_attached = true;
                    }
                } catch (NotImplementedException) {
                    // Some implementations don't don't have kernel attach/detach
                    Trace.TraceInformation(String.Format("Exception detaching kernel driver: %s", str(e)));
                }
                try {
                    usb.util.claim_interface(dev, interface_number);
                } catch {
                    throw new DAPAccessIntf.DeviceError("Unable to open device");
                }
                this.ep_out = ep_out;
                this.ep_in = ep_in;
                this.dev = dev;
                this.intf_number = interface_number;
                this.kernel_driver_was_attached = kernel_driver_was_attached;
                // Start RX thread as the last step
                this.closed = false;
                this.start_rx();
            }
            
            public virtual object start_rx() {
                // Flush the RX buffers by reading until timeout exception
                try {
                    while (true) {
                        this.ep_in.read(this.ep_in.wMaxPacketSize, 1);
                    }
                } catch {
                    // USB timeout expected
                }
                this.thread = threading.Thread(target: this.rx_task);
                this.thread.daemon = true;
                this.thread.start();
            }
            
            public virtual object rx_task() {
                try {
                    while (!this.closed) {
                        this.read_sem.acquire();
                        if (!this.closed) {
                            this.rcv_data.append(this.ep_in.read(this.ep_in.wMaxPacketSize, 10 * 1000));
                        }
                    }
                } finally {
                    // Set last element of rcv_data to None on exit
                    this.rcv_data.append(null);
                }
            }
            
            // 
            //         returns all the connected devices which matches PyUSB.vid/PyUSB.pid.
            //         returns an array of PyUSB (Interface) objects
            //         
            // [staticmethod]
            public static object getAllConnectedInterface() {
                // find all cmsis-dap devices
                var all_devices = usb.core.find(find_all: true, custom_match: FindDap());
                // iterate on all devices found
                var boards = new List<object>();
                foreach (var board in all_devices) {
                    var new_board = PyUSB();
                    new_board.vid = board.idVendor;
                    new_board.pid = board.idProduct;
                    new_board.product_name = board.product;
                    new_board.vendor_name = board.manufacturer;
                    new_board.serial_number = board.serial_number;
                    boards.append(new_board);
                }
                return boards;
            }
            
            // 
            //         write data on the OUT endpoint associated to the HID interface
            //         
            public virtual object write(object data) {
                var report_size = this.packet_size;
                if (this.ep_out) {
                    report_size = this.ep_out.wMaxPacketSize;
                }
                foreach (var _ in range(report_size - data.Count)) {
                    data.append(0);
                }
                this.read_sem.release();
                if (!this.ep_out) {
                    var bmRequestType = 33;
                    var bmRequest = 9;
                    var wValue = 512;
                    var wIndex = this.intf_number;
                    this.dev.ctrl_transfer(bmRequestType, bmRequest, wValue, wIndex, data);
                    return;
                    //raise ArgumentOutOfRangeException('EP_OUT endpoint is NULL')
                }
                this.ep_out.write(data);
                //Trace.TraceInformation('sent: %s', data)
                return;
            }
            
            // 
            //         read data on the IN endpoint associated to the HID interface
            //         
            public virtual object read() {
                while (this.rcv_data.Count == 0) {
                }
                if (this.rcv_data[0] == null) {
                    throw new DAPAccessIntf.DeviceError(String.Format("Device %s read thread exited", this.serial_number));
                }
                return this.rcv_data.pop(0);
            }
            
            public virtual void setPacketCount(UInt32 count) {
                // No interface level restrictions on count
                this.packet_count = count;
            }
            
            public virtual void setPacketSize(object size) {
                this.packet_size = size;
            }
            
            public virtual object getSerialNumber() {
                return this.serial_number;
            }
            
            // 
            //         close the interface
            //         
            public virtual object close() {
                Debug.Assert(object.ReferenceEquals(this.closed, false));
                Trace.TraceInformation("closing interface");
                this.closed = true;
                this.read_sem.release();
                this.thread.join();
                Debug.Assert(this.rcv_data[-1] == null);
                this.rcv_data = new List<object>();
                usb.util.release_interface(this.dev, this.intf_number);
                if (this.kernel_driver_was_attached) {
                    try {
                        this.dev.attach_kernel_driver(this.intf_number);
                    } catch (Exception) {
                        Trace.TraceWarning("Exception attaching kernel driver: %s", str(exception));
                    }
                }
                usb.util.dispose_resources(this.dev);
                this.ep_out = null;
                this.ep_in = null;
                this.dev = null;
                this.intf_number = null;
                this.kernel_driver_was_attached = false;
                this.thread = null;
            }
        }
        
        // CMSIS-DAP match class to be used with usb.core.find
        public class FindDap
            {
            
            public FindDap(object serial = null) {
                this._serial = serial;
            }
            
            // Return True if this is a DAP device, False otherwise
            public virtual object @__call__(object dev) {
                try {
                    var device_string = dev.product;
                } catch (ArgumentOutOfRangeException) {
                    // Permission denied error gets reported as ArgumentOutOfRangeException (langid)
                    return false;
                } catch {
                    Trace.TraceWarning("Exception getting product string: %s", error);
                    return false;
                } catch (IndexError) {
                    Trace.TraceWarning("Internal pyusb error: %s", error);
                    return false;
                }
                if (device_string == null) {
                    return false;
                }
                if (device_string.find("CMSIS-DAP") < 0) {
                    return false;
                }
                if (this._serial != null) {
                    if (this._serial != dev.serial_number) {
                        return false;
                    }
                }
                return true;
            }
        }
    }
}
