namespace pyDAPAccess.Interface
{
    
    using @print_function = @@__future__.print_function;
    
    using bytes_to_native_str = future.utils.bytes_to_native_str;
    
    using bytes = future.builtins.bytes;
    
    using b64encode = base64.b64encode;
    
    using b64decode = base64.b64decode;
    
    using create_connection = websocket.create_connection;
    
    
    using System;
    
    using System.Collections.Generic;
    
    public static class ws_backend {
        
        public class WebSocketInterface
            : Interface {
            
            public WebSocketInterface(object host = "localhost", object port = 8081) {
                this.connected = false;
                try {
                    this.ws = create_connection(String.Format("ws://%s:%i", host, port));
                    this.ws.settimeout(null);
                    this.connected = true;
                } catch {
                    this.connected = false;
                }
            }
            
            public virtual object write(object data) {
                this.ws.send(b64encode(bytes_to_native_str(bytes(data))));
            }
            
            public virtual object read() {
                //It will wait on recv() until data is sent over websocket
                var rawdata = this.ws.recv();
                //Data is sent in base64 string
                var data = b64decode(rawdata);
                data = data.Select(c => ord(c));
                return data;
            }
            
            public virtual void setPacketCount(object count) {
                this.packet_count = count;
            }
            
            public virtual object close() {
                this.ws.close();
            }
            
            // Get the unique id from an interface
            public virtual object getUniqueId() {
                this.write(new List<object> {
                    128
                });
                var raw_id = bytearray(this.read());
                var id_start = 2;
                var id_size = raw_id[1];
                var unique_id = str(raw_id[id_start::(id_start  +  id_size)]);
                return unique_id;
            }
            
            public virtual object getSerialNumber() {
                return this.getUniqueId();
            }
            
            // [staticmethod]
            public static object getAllConnectedInterface(object host, object port) {
                var ws = WebSocketInterface(host, port);
                if (ws.connected) {
                    return new List<object> {
                        ws
                    };
                } else {
                    return new List<object>();
                }
            }
        }
    }
}
