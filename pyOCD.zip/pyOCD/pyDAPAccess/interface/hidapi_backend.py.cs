// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace pyDAPAccess.Interface
{

    //using logging;

    //using os;

    using DAPAccessIntf = dap_access_api.DAPAccessIntf;

    using HidLibrary;

    using System.Collections.Generic;
    using System.Linq;
    using System.Diagnostics;
    using System;

    public static class hidapi_backend
    {

        static hidapi_backend()
        {
            //isAvailable = false;
            //Trace.TraceError("cython-hidapi is required on a Mac OS X Machine");
        }

        // 
        //     This class provides basic functions to access
        //     a USB HID device using cython-hidapi:
        //         - write/read an endpoint
        //     
        public class HidApiUSB : Interface
        {
            public object vid = 0;
            public object pid = 0;
            internal UInt32 packet_size;
            internal string serial_number { get; private set; }
            internal HidDevice device;

            public HidApiUSB() : base()
            {
                isAvailable = true;
                // Vendor page and usage_id = 2
                this.device = null;
                this.packet_size = 64;
            }

            public override void init()
            {
            }

            public override void open()
            {
                try
                {
                    // open_path(this.device_info["path"]);
                    this.device.OpenDevice(DeviceMode.NonOverlapped, DeviceMode.NonOverlapped, ShareMode.Exclusive);
                }
                catch // (IOError)
                {
                    throw new Exception("Unable to open device"); //DAPAccessIntf.DeviceError
                }
            }

            // 
            //         returns all the connected devices which matches HidApiUSB.vid/HidApiUSB.pid.
            //         returns an array of HidApiUSB (Interface) objects
            //         
            // [staticmethod]
            public static List<Interface> getAllConnectedInterface()
            {
                List<Interface> boards = new List<Interface>();
                IEnumerable<HidDevice> devices = HidDevices.Enumerate();
                if (!devices.Any())
                {
                    Trace.TraceInformation("No Mbed device connected");
                    return boards;
                }
                foreach (HidDevice deviceInfo in devices)
                {
                    string product_name = deviceInfo["product_string"];
                    if (!product_name.Contains("CMSIS-DAP"))
                    {
                        // Skip non cmsis-dap devices
                        continue;
                    }
                    HidDevice dev = deviceInfo;
                    try
                    {
                        //dev = hid.device(vendor_id: deviceInfo["vendor_id"], product_id: deviceInfo["product_id"], path: deviceInfo["path"]);
                    }
                    catch //(IOError)
                    {
                        Trace.TraceInformation("Failed to open Mbed device");
                        continue;
                    }
                    HidApiUSB new_board = new HidApiUSB();
                    new_board.vendor_name = deviceInfo["manufacturer_string"];
                    new_board.product_name = deviceInfo["product_string"];
                    new_board.serial_number = deviceInfo["serial_number"];
                    new_board.vid = deviceInfo["vendor_id"];
                    new_board.pid = deviceInfo["product_id"];
                    new_board.device_info = deviceInfo;
                    new_board.device = dev;
                    boards.Add(new_board);
                }
                return boards;
            }

            // 
            //         write data on the OUT endpoint associated to the HID interface
            //         
            public override void write(List<byte> data)
            {
                foreach (var _ in range(this.packet_size - data.Count))
                {
                    data.Add(0);
                }
                //Trace.TraceInformation("send: %s", data)
                this.device.Write(new List<object> {
                    0
                } + data);
                return;
            }

            // 
            //         read data on the IN endpoint associated to the HID interface
            //         
            public override object read(int size = -1, int timeout = -1)
            {
                HidDeviceData result = this.device.Read(timeout); // this.packet_size);
                if (result.Status == HidDeviceData.ReadStatus.Success)
                {
                    return result.Data;
                }
                else
                {
                    throw new Exception();
                }
            }

            public virtual string getSerialNumber()
            {
                return this.serial_number;
            }

            // 
            //         close the interface
            //         
            public override void close()
            {
                Trace.TraceInformation("closing interface");
                this.device.CloseDevice();
            }

            public virtual void setPacketCount(UInt32 count)
            {
                // No interface level restrictions on count
                this.packet_count = count;
            }

            public override void setPacketSize(UInt16 size)
            {
                this.packet_size = size;
            }
        }
    }
}
