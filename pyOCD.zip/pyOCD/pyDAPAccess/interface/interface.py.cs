// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
using System;
using System.Collections.Generic;

namespace pyDAPAccess.Interface
{
    public abstract class Interface
    {
        internal bool isAvailable;
        internal UInt32 packet_count { get; set; }

        public Interface()
        {
            this.vid = 0;
            this.pid = 0;
            this.vendor_name = "";
            this.product_name = "";
            this.packet_count = 1;
            return;
        }
        public abstract void open();

        public abstract void init();

        public abstract void write(List<byte> data);

        public abstract List<byte> read(int size = -1, int timeout = -1);

        public virtual string getInfo()
        {
            return this.vendor_name + " " + this.product_name + " (" + str(hex(this.vid)) + ", " + str(hex(this.pid)) + ")";
        }

        public virtual void setPacketCount(UInt16 count)
        {
            // Unless overridden the packet count cannot be changed
            return;
        }

        public virtual UInt32 getPacketCount()
        {
            return this.packet_count;
        }

        public abstract void close();

        public abstract void setPacketSize(UInt16 size);

        public abstract string getSerialNumber();
    }
}
