// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2006-2013 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace pyDAPAccess.Interface {
    
    using logging;
    
    using os;
    
    using collections;
    
    using time = time.time;
    
    using DAPAccessIntf = dap_access_api.DAPAccessIntf;
    
    using hid = pywinusb.hid;
    
    using System.Collections.Generic;
    
    using System.Diagnostics;
    
    public static class pywinusb_backend {
        
        public static object OPEN_TIMEOUT_S = 60.0;
        
        static pywinusb_backend() {
            Trace.TraceError("PyWinUSB is required on a Windows Machine");
        }
        
        public static object isAvailable = false;
        
        // 
        //     This class provides basic functions to access
        //     a USB HID device using pywinusb:
        //         - write/read an endpoint
        //     
        public class PyWinUSB
            : Interface {
            
            public object vid = 0;
            
            public object pid = 0;
            
            public object isAvailable = isAvailable;
            
            public PyWinUSB() {
                // Vendor page and usage_id = 2
                this.report = new List<object>();
                // deque used here instead of synchronized Queue
                // since read speeds are ~10-30% faster and are
                // comprable to a based list implmentation.
                this.rcv_data = collections.deque();
                this.device = null;
                this.packet_size = 64;
            }
            
            // handler called when a report is received
            public virtual object rx_handler(object data) {
                //Trace.TraceInformation("rcv: %s", data[1:])
                this.rcv_data.append(data[1]);
            }
            
            public virtual object open() {
                this.device.set_raw_data_handler(this.rx_handler);
                // Attempt to open the device.
                // Note - this operation must be retried since
                // other instances of pyOCD listing board can prevent
                // opening this device with exclusive access.
                var start = DateTime.Now;
                while (true) {
                    // Attempt to open the device
                    try {
                        this.device.open(shared: false);
                        break;
                    } catch {
                    }
                    try {
                        this.device.open(shared: true);
                        this.device.close();
                    } catch {
                        // If the device could not be opened in read only mode
                        // Then it either has been disconnected or is in use
                        // by another thread/process
                        throw new DAPAccessIntf.DeviceError("Unable to open device");
                    }
                    if (time() - start > OPEN_TIMEOUT_S) {
                        // If this timeout has elapsed then another process
                        // has locked this device in shared mode. This should
                        // not happen.
                        Debug.Assert(false);
                        break;
                    }
                }
            }
            
            // 
            //         returns all the connected CMSIS-DAP devices
            //         
            // [staticmethod]
            public static object getAllConnectedInterface() {
                var all_devices = hid.find_all_hid_devices();
                // find devices with good vid/pid
                var all_mbed_devices = new List<object>();
                foreach (var d in all_devices) {
                    if (d.product_name.find("CMSIS-DAP") >= 0) {
                        all_mbed_devices.append(d);
                    }
                }
                var boards = new List<object>();
                foreach (var dev in all_mbed_devices) {
                    try {
                        dev.open(shared: true);
                        var report = dev.find_output_reports();
                        if (report.Count != 1) {
                            dev.close();
                            continue;
                        }
                        var new_board = PyWinUSB();
                        new_board.report = report[0];
                        new_board.vendor_name = dev.vendor_name;
                        new_board.product_name = dev.product_name;
                        new_board.serial_number = dev.serial_number;
                        new_board.vid = dev.vendor_id;
                        new_board.pid = dev.product_id;
                        new_board.device = dev;
                        dev.close();
                        boards.append(new_board);
                    } catch (Exception) {
                        if (str(e) != "Failure to get HID pre parsed data") {
                            Trace.TraceError("Receiving Exception: %s", e);
                        }
                        dev.close();
                    }
                }
                return boards;
            }
            
            // 
            //         write data on the OUT endpoint associated to the HID interface
            //         
            public virtual object write(object data) {
                foreach (var _ in range(this.packet_size - data.Count)) {
                    data.append(0);
                }
                //Trace.TraceInformation("send: %s", data)
                this.report.send(new List<object> {
                    0
                } + data);
                return;
            }
            
            // 
            //         read data on the IN endpoint associated to the HID interface
            //         
            public virtual object read(object timeout = 20.0) {
                var start = DateTime.Now;
                while (this.rcv_data.Count == 0) {
                    if (time() - start > timeout) {
                        // Read operations should typically take ~1-2ms.
                        // If this exception occurs, then it could indicate
                        // a problem in one of the following areas:
                        // 1. Bad usb driver causing either a dropped read or write
                        // 2. CMSIS-DAP firmware problem cause a dropped read or write
                        // 3. CMSIS-DAP is performing a long operation or is being
                        //    halted in a debugger
                        throw new Exception("Read timed out");
                    }
                }
                return this.rcv_data.popleft();
            }
            
            public virtual void setPacketCount(UInt32 count) {
                // No interface level restrictions on count
                this.packet_count = count;
            }
            
            public virtual void setPacketSize(object size) {
                this.packet_size = size;
            }
            
            public virtual object getSerialNumber() {
                return this.serial_number;
            }
            
            // 
            //         close the interface
            //         
            public virtual object close() {
                Trace.TraceInformation("closing interface");
                this.device.close();
            }
        }
    }
}
