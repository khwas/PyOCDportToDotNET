// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2016 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace rtos {
    
    using TargetThread = provider.TargetThread;
    
    using ThreadProvider = provider.ThreadProvider;
    
    using read_c_string = common.read_c_string;
    
    using HandlerModeThread = common.HandlerModeThread;
    
    using DebugContext = debug.context.DebugContext;
    
    using CORE_REGISTER = coresight.cortex_m.CORE_REGISTER;
    
    using register_name_to_index = coresight.cortex_m.register_name_to_index;
    
    using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    
    using logging;
    
    using System.Collections.Generic;
    
    using System;
    
    public static class freertos {
        
        public static object FREERTOS_MAX_PRIORITIES = 63;
        
        public static object LIST_SIZE = 20;
        
        public static object LIST_INDEX_OFFSET = 16;
        
        public static object LIST_NODE_NEXT_OFFSET = 8;
        
        public static object LIST_NODE_OBJECT_OFFSET = 12;
        
        public static object THREAD_STACK_POINTER_OFFSET = 0;
        
        public static object THREAD_PRIORITY_OFFSET = 44;
        
        public static object THREAD_NAME_OFFSET = 52;
        
        public static object log = logging.getLogger("freertos");
        
        public class TargetList
            : object {
            
            public TargetList(object context, object ptr) {
                this._context = context;
                this._list = ptr;
            }
            
            public virtual object @__iter__() {
                var prev = -1;
                var found = 0;
                var count = this._context.read32(this._list);
                if (count == 0) {
                    return;
                }
                var node = this._context.read32(this._list + LIST_INDEX_OFFSET);
                while (node != 0 && node != prev && found < count) {
                    try {
                        // Read the object from the node.
                        var obj = this._context.read32(node + LIST_NODE_OBJECT_OFFSET);
                        yield return obj;
                        found += 1;
                        // Read next list node pointer.
                        prev = node;
                        node = this._context.read32(node + LIST_NODE_NEXT_OFFSET);
                    } catch {
                        log.warning("TransferError while reading list elements (list=0x%08x, node=0x%08x), terminating list", this._list, node);
                        node = 0;
                    }
                }
            }
        }
        
        public class FreeRTOSThreadContext
            : DebugContext {
            
            public object COMMON_REGISTER_OFFSETS = new Dictionary<object, object> {
                {
                    4,
                    0},
                {
                    5,
                    4},
                {
                    6,
                    8},
                {
                    7,
                    12},
                {
                    8,
                    16},
                {
                    9,
                    20},
                {
                    10,
                    24},
                {
                    11,
                    28}};
            
            public object NOFPU_REGISTER_OFFSETS = new Dictionary<object, object> {
                {
                    0,
                    32},
                {
                    1,
                    36},
                {
                    2,
                    40},
                {
                    3,
                    44},
                {
                    12,
                    48},
                {
                    14,
                    52},
                {
                    15,
                    56},
                {
                    16,
                    60}};
            
            static FreeRTOSThreadContext() {
                NOFPU_REGISTER_OFFSETS.update(COMMON_REGISTER_OFFSETS);
                FPU_BASIC_REGISTER_OFFSETS.update(COMMON_REGISTER_OFFSETS);
                FPU_EXTENDED_REGISTER_OFFSETS.update(COMMON_REGISTER_OFFSETS);
            }
            
            public object FPU_BASIC_REGISTER_OFFSETS = new Dictionary<object, object> {
                {
                    -1,
                    32},
                {
                    0,
                    36},
                {
                    1,
                    40},
                {
                    2,
                    44},
                {
                    3,
                    48},
                {
                    12,
                    42},
                {
                    14,
                    56},
                {
                    15,
                    60},
                {
                    16,
                    64}};
            
            public object FPU_EXTENDED_REGISTER_OFFSETS = new Dictionary<object, object> {
                {
                    -1,
                    32},
                {
                    80,
                    36},
                {
                    81,
                    40},
                {
                    82,
                    44},
                {
                    83,
                    48},
                {
                    84,
                    52},
                {
                    85,
                    56},
                {
                    86,
                    60},
                {
                    87,
                    64},
                {
                    88,
                    68},
                {
                    89,
                    72},
                {
                    90,
                    76},
                {
                    91,
                    80},
                {
                    92,
                    84},
                {
                    93,
                    88},
                {
                    94,
                    92},
                {
                    95,
                    96},
                {
                    0,
                    100},
                {
                    1,
                    104},
                {
                    2,
                    108},
                {
                    3,
                    112},
                {
                    12,
                    116},
                {
                    14,
                    120},
                {
                    15,
                    124},
                {
                    16,
                    128},
                {
                    64,
                    132},
                {
                    65,
                    136},
                {
                    66,
                    140},
                {
                    67,
                    144},
                {
                    68,
                    148},
                {
                    69,
                    152},
                {
                    70,
                    156},
                {
                    71,
                    160},
                {
                    72,
                    164},
                {
                    73,
                    168},
                {
                    74,
                    172},
                {
                    75,
                    176},
                {
                    76,
                    180},
                {
                    77,
                    184},
                {
                    78,
                    188},
                {
                    79,
                    192},
                {
                    33,
                    196}};
            
            public object EXCEPTION_UNAVAILABLE_REGS = Tuple.Create(4, 5, 6, 7, 8, 9, 10, 11);
            
            public FreeRTOSThreadContext(object parentContext, object thread) {
                this._parent = parentContext;
                this._thread = thread;
                this._has_fpu = parentContext.core.has_fpu;
            }
            
            public virtual object readCoreRegistersRaw(object reg_list) {
                reg_list = reg_list.Select(reg => register_name_to_index(reg));
                var reg_vals = new List<object>();
                var inException = this._get_ipsr() > 0;
                var isCurrent = this._thread.is_current;
                // If this is the current thread and we're not in an exception, just read the live registers.
                if (isCurrent && !inException) {
                    return this._parent.readCoreRegistersRaw(reg_list);
                }
                var sp = this._thread.get_stack_pointer();
                // Determine which register offset table to use and the offsets past the saved state.
                var realSpOffset = 64;
                var realSpExceptionOffset = 32;
                var table = this.NOFPU_REGISTER_OFFSETS;
                if (this._has_fpu) {
                    try {
                        // Read stacked exception return LR.
                        var offset = this.FPU_BASIC_REGISTER_OFFSETS[-1];
                        var exceptionLR = this._parent.read32(sp + offset);
                        // Check bit 4 of the saved exception LR to determine if FPU registers were stacked.
                        if ((exceptionLR & 1 << 4) != 0) {
                            table = this.FPU_BASIC_REGISTER_OFFSETS;
                            realSpOffset = 68;
                        } else {
                            table = this.FPU_EXTENDED_REGISTER_OFFSETS;
                            realSpOffset = 204;
                            realSpExceptionOffset = 108;
                        }
                    } catch {
                        log.debug("Transfer error while reading thread's saved LR");
                    }
                }
                foreach (var reg in reg_list) {
                    // Check for regs we can't access.
                    if (isCurrent && inException) {
                        if (this.EXCEPTION_UNAVAILABLE_REGS.Contains(reg)) {
                            reg_vals.append(0);
                            continue;
                        }
                        if (reg == 18 || reg == 13) {
                            // PSP
                            reg_vals.append(sp + realSpExceptionOffset);
                            continue;
                        }
                    }
                    // Must handle stack pointer specially.
                    if (reg == 13) {
                        reg_vals.append(sp + realSpOffset);
                        continue;
                    }
                    // Look up offset for this register on the stack.
                    var spOffset = table.get(reg, null);
                    if (spOffset == null) {
                        reg_vals.append(this._parent.readCoreRegisterRaw(reg));
                        continue;
                    }
                    if (isCurrent && inException) {
                        spOffset -= realSpExceptionOffset;
                    }
                    try {
                        reg_vals.append(this._parent.read32(sp + spOffset));
                    } catch {
                        reg_vals.append(0);
                    }
                }
                return reg_vals;
            }
            
            public virtual object _get_ipsr() {
                return this._parent.readCoreRegister("xpsr") & 255;
            }
            
            public virtual object writeCoreRegistersRaw(object reg_list, object data_list) {
                this._parent.writeCoreRegistersRaw(reg_list, data_list);
            }
        }
        
        public class FreeRTOSThread
            : TargetThread {
            
            public object RUNNING = 1;
            
            public object READY = 2;
            
            public object BLOCKED = 3;
            
            public object SUSPENDED = 4;
            
            public object DELETED = 5;
            
            public object STATE_NAMES = new Dictionary<object, object> {
                {
                    RUNNING,
                    "Running"},
                {
                    READY,
                    "Ready"},
                {
                    BLOCKED,
                    "Blocked"},
                {
                    SUSPENDED,
                    "Suspended"},
                {
                    DELETED,
                    "Deleted"}};
            
            public FreeRTOSThread(object targetContext, object provider, object @base) {
                this._target_context = targetContext;
                this._provider = provider;
                this._base = @base;
                this._state = FreeRTOSThread.READY;
                this._thread_context = FreeRTOSThreadContext(this._target_context, this);
                this._priority = this._target_context.read32(this._base + THREAD_PRIORITY_OFFSET);
                this._name = read_c_string(this._target_context, this._base + THREAD_NAME_OFFSET);
                if (this._name.Count == 0) {
                    this._name = "Unnamed";
                }
            }
            
            public virtual object get_stack_pointer() {
                object sp;
                if (this.is_current) {
                    // Read live process stack.
                    sp = this._target_context.readCoreRegister("psp");
                } else {
                    // Get stack pointer saved in thread struct.
                    try {
                        sp = this._target_context.read32(this._base + THREAD_STACK_POINTER_OFFSET);
                    } catch {
                        log.debug("Transfer error while reading thread's stack pointer @ 0x%08x", this._base + THREAD_STACK_POINTER_OFFSET);
                    }
                }
                return sp;
            }
            
            public object state {
                get {
                    return this._state;
                }
                set {
                    this._state = value;
                }
            }
            
            public object priority {
                get {
                    return this._priority;
                }
            }
            
            public object unique_id {
                get {
                    return this._base;
                }
            }
            
            public object name {
                get {
                    return this._name;
                }
            }
            
            public object description {
                get {
                    return String.Format("%s; Priority %d", this.STATE_NAMES[this.state], this.priority);
                }
            }
            
            public object is_current {
                get {
                    return this._provider.get_actual_current_thread_id() == this.unique_id;
                }
            }
            
            public object context {
                get {
                    return this._thread_context;
                }
            }
            
            public override object ToString() {
                return String.Format("<FreeRTOSThread@0x%08x id=%x name=%s>", id(this), this.unique_id, this.name);
            }
            
            public virtual object @__repr__() {
                return str(this);
            }
        }
        
        public class FreeRTOSThreadProvider
            : ThreadProvider {
            
            public object FREERTOS_SYMBOLS = new List<object> {
                "uxCurrentNumberOfTasks",
                "pxCurrentTCB",
                "pxReadyTasksLists",
                "xDelayedTaskList1",
                "xDelayedTaskList2",
                "xPendingReadyList",
                "uxTopReadyPriority",
                "xSchedulerRunning"
            };
            
            public FreeRTOSThreadProvider(object target) {
                this._symbols = null;
                this._total_priorities = 0;
                this._threads = new Dictionary<object, object> {
                };
            }
            
            public virtual object init(object symbolProvider) {
                // Lookup required symbols.
                this._symbols = this._lookup_symbols(this.FREERTOS_SYMBOLS, symbolProvider);
                if (this._symbols == null) {
                    return false;
                }
                // Look up optional xSuspendedTaskList, controlled by INCLUDE_vTaskSuspend
                var suspendedTaskListSym = this._lookup_symbols(new List<object> {
                    "xSuspendedTaskList"
                }, symbolProvider);
                if (suspendedTaskListSym != null) {
                    this._symbols["xSuspendedTaskList"] = suspendedTaskListSym["xSuspendedTaskList"];
                }
                // Look up optional xTasksWaitingTermination, controlled by INCLUDE_vTaskDelete
                var tasksWaitingTerminationSym = this._lookup_symbols(new List<object> {
                    "xTasksWaitingTermination"
                }, symbolProvider);
                if (tasksWaitingTerminationSym != null) {
                    this._symbols["xTasksWaitingTermination"] = tasksWaitingTerminationSym["xTasksWaitingTermination"];
                }
                // Look up vPortEnableVFP() to determine if the FreeRTOS port supports the FPU.
                var vPortEnableVFP = this._lookup_symbols(new List<object> {
                    "vPortEnableVFP"
                }, symbolProvider);
                this._fpu_port = vPortEnableVFP != null;
                // Check for the expected list size. These two symbols are each a single list and xDelayedTaskList2
                // immediately follows xDelayedTaskList1, so we can just subtract their addresses to get the
                // size of a single list.
                var delta = this._symbols["xDelayedTaskList2"] - this._symbols["xDelayedTaskList1"];
                if (delta != LIST_SIZE) {
                    log.warning("FreeRTOS: list size is unexpected, maybe an unsupported configuration of FreeRTOS");
                    return false;
                }
                // xDelayedTaskList1 immediately follows pxReadyTasksLists, so subtracting their addresses gives
                // us the total size of the pxReadyTaskLists array.
                delta = this._symbols["xDelayedTaskList1"] - this._symbols["pxReadyTasksLists"];
                if (delta % LIST_SIZE) {
                    log.warning("FreeRTOS: pxReadyTasksLists size is unexpected, maybe an unsupported version of FreeRTOS");
                    return false;
                }
                this._total_priorities = delta / LIST_SIZE;
                if (this._total_priorities > FREERTOS_MAX_PRIORITIES) {
                    log.warning("FreeRTOS: number of priorities is too large (%d)", this._total_priorities);
                    return false;
                }
                log.debug("FreeRTOS: number of priorities is %d", this._total_priorities);
                return true;
            }
            
            public virtual object _build_thread_list() {
                object t;
                var newThreads = new Dictionary<object, object> {
                };
                // Read the number of threads.
                var threadCount = this._target_context.read32(this._symbols["uxCurrentNumberOfTasks"]);
                // Read the current thread.
                var currentThread = this._target_context.read32(this._symbols["pxCurrentTCB"]);
                // We should only be building the thread list if the scheduler is running, so a zero thread
                // count or a null current thread means something is bizarrely wrong.
                if (threadCount == 0 || currentThread == 0) {
                    log.warning("FreeRTOS: no threads even though the scheduler is running");
                    return;
                }
                // Read the top ready priority.
                var topPriority = this._target_context.read32(this._symbols["uxTopReadyPriority"]);
                // Handle an uxTopReadyPriority value larger than the number of lists. This is most likely
                // caused by the configUSE_PORT_OPTIMISED_TASK_SELECTION option being enabled, which treats
                // uxTopReadyPriority as a bitmap instead of integer. This is ok because uxTopReadyPriority
                // in optimised mode will always be >= the actual top priority.
                if (topPriority > this._total_priorities) {
                    topPriority = this._total_priorities;
                }
                // Build up list of all the thread lists we need to scan.
                var listsToRead = new List<object>();
                foreach (var i in range(topPriority + 1)) {
                    listsToRead.append(Tuple.Create(this._symbols["pxReadyTasksLists"] + i * LIST_SIZE, FreeRTOSThread.READY));
                }
                listsToRead.append(Tuple.Create(this._symbols["xDelayedTaskList1"], FreeRTOSThread.BLOCKED));
                listsToRead.append(Tuple.Create(this._symbols["xDelayedTaskList2"], FreeRTOSThread.BLOCKED));
                listsToRead.append(Tuple.Create(this._symbols["xPendingReadyList"], FreeRTOSThread.READY));
                if (this._symbols.has_key("xSuspendedTaskList")) {
                    listsToRead.append(Tuple.Create(this._symbols["xSuspendedTaskList"], FreeRTOSThread.SUSPENDED));
                }
                if (this._symbols.has_key("xTasksWaitingTermination")) {
                    listsToRead.append(Tuple.Create(this._symbols["xTasksWaitingTermination"], FreeRTOSThread.DELETED));
                }
                foreach (var _tup_1 in listsToRead) {
                    var listPtr = _tup_1.Item1;
                    var state = _tup_1.Item2;
                    foreach (var threadBase in TargetList(this._target_context, listPtr)) {
                        try {
                            // Don't try adding more threads than the number of threads that FreeRTOS says there are.
                            if (newThreads.Count >= threadCount) {
                                break;
                            }
                            // Reuse existing thread objects.
                            if (this._threads.Contains(threadBase)) {
                                t = this._threads[threadBase];
                            } else {
                                t = FreeRTOSThread(this._target_context, this, threadBase);
                            }
                            // Set thread state.
                            if (threadBase == currentThread) {
                                t.state = FreeRTOSThread.RUNNING;
                            } else {
                                t.state = state;
                            }
                            log.debug("Thread 0x%08x (%s)", threadBase, t.name);
                            newThreads[t.unique_id] = t;
                        } catch {
                            log.debug("TransferError while examining thread 0x%08x", threadBase);
                        }
                    }
                }
                if (newThreads.Count != threadCount) {
                    log.warning("FreeRTOS: thread count mismatch");
                }
                // Create fake handler mode thread.
                if (this.get_ipsr() > 0) {
                    log.debug("FreeRTOS: creating handler mode thread");
                    t = HandlerModeThread(this._target_context, this);
                    newThreads[t.unique_id] = t;
                }
                this._threads = newThreads;
            }
            
            public virtual object get_threads() {
                if (!this.is_enabled) {
                    return new List<object>();
                }
                this.update_threads();
                return this._threads.values();
            }
            
            public virtual object get_thread(object threadId) {
                if (!this.is_enabled) {
                    return null;
                }
                this.update_threads();
                return this._threads.get(threadId, null);
            }
            
            public object is_enabled {
                get {
                    return this._symbols != null && this.get_is_running();
                }
            }
            
            public object current_thread {
                get {
                    if (!this.is_enabled) {
                        return null;
                    }
                    this.update_threads();
                    var id = this.get_current_thread_id();
                    try {
                        return this._threads[id];
                    } catch (KeyError) {
                        return null;
                    }
                }
            }
            
            public virtual object is_valid_thread_id(object threadId) {
                if (!this.is_enabled) {
                    return false;
                }
                this.update_threads();
                return this._threads.Contains(threadId);
            }
            
            public virtual object get_current_thread_id() {
                if (!this.is_enabled) {
                    return null;
                }
                if (this.get_ipsr() > 0) {
                    return 2;
                }
                return this.get_actual_current_thread_id();
            }
            
            public virtual object get_actual_current_thread_id() {
                if (!this.is_enabled) {
                    return null;
                }
                return this._target_context.read32(this._symbols["pxCurrentTCB"]);
            }
            
            public virtual object get_is_running() {
                if (this._symbols == null) {
                    return false;
                }
                return this._target_context.read32(this._symbols["xSchedulerRunning"]) != 0;
            }
        }
    }
}
