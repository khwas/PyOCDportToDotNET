// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2016 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace rtos {
    
    using TargetThread = provider.TargetThread;
    
    using ThreadProvider = provider.ThreadProvider;
    
    using DebugContext = debug.context.DebugContext;
    
    using CORE_REGISTER = coresight.cortex_m.CORE_REGISTER;
    
    using register_name_to_index = coresight.cortex_m.register_name_to_index;
    
    using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    
    using logging;
    
    using System.Collections.Generic;
    
    using System;
    
    public static class common {
        
        public static object LIST_NODE_NEXT_OFFSET = 0;
        
        public static object LIST_NODE_OBJ_OFFSET = 8;
        
        //# @brief Reads a null-terminated C string from the target.
        public static object read_c_string(object context, object ptr) {
            if (ptr == 0) {
                return "";
            }
            var s = "";
            var done = false;
            var count = 0;
            var badCount = 0;
            try {
                while (!done && count < 256) {
                    var data = context.readBlockMemoryUnaligned8(ptr, 16);
                    ptr += 16;
                    count += 16;
                    foreach (var c in data) {
                        if (c == 0) {
                            done = true;
                            break;
                        } else if (c > 127) {
                            // Replace non-ASCII characters. If there is a run of invalid characters longer
                            // than 4, then terminate the string early.
                            badCount += 1;
                            if (badCount > 4) {
                                done = true;
                                break;
                            }
                            s += "?";
                        } else {
                            s += chr(c);
                            badCount = 0;
                        }
                    }
                }
            } catch {
                logging.debug("TransferError while trying to read 16 bytes at 0x%08x", ptr);
            }
            return s;
        }
        
        public class CommonThreadContext
            : DebugContext {
            
            public object CORE_REGISTER_OFFSETS = new Dictionary<object, object> {
                {
                    0,
                    32},
                {
                    1,
                    36},
                {
                    2,
                    40},
                {
                    3,
                    44},
                {
                    4,
                    0},
                {
                    5,
                    4},
                {
                    6,
                    8},
                {
                    7,
                    12},
                {
                    8,
                    16},
                {
                    9,
                    20},
                {
                    10,
                    24},
                {
                    11,
                    28},
                {
                    12,
                    48},
                {
                    14,
                    52},
                {
                    15,
                    56},
                {
                    16,
                    60}};
            
            public CommonThreadContext(object parentContext, object thread) {
                this._parent = parentContext;
                this._thread = thread;
            }
            
            public virtual object readCoreRegistersRaw(object reg_list) {
                reg_list = reg_list.Select(reg => register_name_to_index(reg));
                var reg_vals = new List<object>();
                var inException = this._get_ipsr() > 0;
                var isCurrent = this._is_current();
                var sp = this._get_stack_pointer();
                var saveSp = sp;
                if (!isCurrent) {
                    sp -= 64;
                } else if (inException) {
                    sp -= 32;
                }
                foreach (var reg in reg_list) {
                    if (isCurrent) {
                        if (!inException) {
                            // Not in an exception, so just read the live register.
                            reg_vals.append(this._core.readCoreRegisterRaw(reg));
                            continue;
                        } else {
                            // Check for regs we can't access.
                            if (Tuple.Create(4, 5, 6, 7, 8, 9, 10, 11).Contains(reg)) {
                                reg_vals.append(0);
                                continue;
                            }
                        }
                    }
                    // Must handle stack pointer specially.
                    if (reg == 13) {
                        reg_vals.append(saveSp);
                        continue;
                    }
                    var spOffset = this.CORE_REGISTER_OFFSETS.get(reg, null);
                    if (spOffset == null) {
                        reg_vals.append(this._core.readCoreRegisterRaw(reg));
                        continue;
                    }
                    if (isCurrent && inException) {
                        spOffset -= 32;
                    }
                    try {
                        reg_vals.append(this._core.read32(sp + spOffset));
                    } catch {
                        reg_vals.append(0);
                    }
                }
                return reg_vals;
            }
            
            public virtual object _get_stack_pointer() {
                var sp = 0;
                if (this._is_current()) {
                    // Read live process stack.
                    sp = this._core.readCoreRegister("sp");
                    // In IRQ context, we have to adjust for hw saved state.
                    if (this._get_ipsr() > 0) {
                        sp += 32;
                    }
                } else {
                    // Get stack pointer saved in thread struct.
                    sp = this._core.read32(this._thread._base + THREAD_STACK_POINTER_OFFSET);
                    // Skip saved thread state.
                    sp += 64;
                }
                return sp;
            }
            
            public virtual object _get_ipsr() {
                return this._core.readCoreRegister("xpsr") & 255;
            }
            
            public virtual object _has_extended_frame() {
                return false;
            }
            
            public virtual object _is_current() {
                return this._thread.is_current;
            }
            
            public virtual object writeCoreRegistersRaw(object reg_list, object data_list) {
                this._core.writeCoreRegistersRaw(reg_list, data_list);
            }
        }
        
        public class HandlerModeThread
            : TargetThread {
            
            public HandlerModeThread(object targetContext, object provider) {
                this._target_context = targetContext;
                this._provider = provider;
            }
            
            public virtual object get_stack_pointer() {
                return this._target_context.readCoreRegister("msp");
            }
            
            public object priority {
                get {
                    return 0;
                }
            }
            
            public object unique_id {
                get {
                    return 2;
                }
            }
            
            public object name {
                get {
                    return "Handler mode";
                }
            }
            
            public object description {
                get {
                    return "";
                }
            }
            
            public object is_current {
                get {
                    return this._provider.get_ipsr() > 0;
                }
            }
            
            public object context {
                get {
                    return this._target_context;
                }
            }
            
            public override object ToString() {
                return String.Format("<HandlerModeThread@0x%08x>", id(this));
            }
            
            public virtual object @__repr__() {
                return str(this);
            }
        }
    }
}
