// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2016 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace rtos {
    
    using TargetThread = provider.TargetThread;
    
    using ThreadProvider = provider.ThreadProvider;
    
    using read_c_string = common.read_c_string;
    
    using HandlerModeThread = common.HandlerModeThread;
    
    using DebugContext = debug.context.DebugContext;
    
    using CORE_REGISTER = coresight.cortex_m.CORE_REGISTER;
    
    using register_name_to_index = coresight.cortex_m.register_name_to_index;
    
    using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    
    using logging;
    
    using System.Collections.Generic;
    
    using System;
    
    public static class argon {
        
        public static object IS_RUNNING_OFFSET = 84;
        
        public static object ALL_OBJECTS_THREADS_OFFSET = 0;
        
        public static object THREAD_STACK_POINTER_OFFSET = 0;
        
        public static object THREAD_EXTENDED_FRAME_OFFSET = 4;
        
        public static object THREAD_NAME_OFFSET = 8;
        
        public static object THREAD_STACK_BOTTOM_OFFSET = 12;
        
        public static object THREAD_PRIORITY_OFFSET = 16;
        
        public static object THREAD_STATE_OFFSET = 17;
        
        public static object THREAD_CREATED_NODE_OFFSET = 36;
        
        public static object LIST_NODE_NEXT_OFFSET = 0;
        
        public static object LIST_NODE_OBJ_OFFSET = 8;
        
        public static object log = logging.getLogger("argon");
        
        public class TargetList
            : object {
            
            public TargetList(object context, object ptr) {
                this._context = context;
                this._list = ptr;
            }
            
            public virtual object @__iter__() {
                var next = 0;
                var head = this._context.read32(this._list);
                var node = head;
                var is_valid = head != 0;
                while (is_valid && next != head) {
                    try {
                        // Read the object from the node.
                        var obj = this._context.read32(node + LIST_NODE_OBJ_OFFSET);
                        yield return obj;
                        next = this._context.read32(node + LIST_NODE_NEXT_OFFSET);
                        node = next;
                    } catch {
                        log.warning("TransferError while reading list elements (list=0x%08x, node=0x%08x), terminating list", this._list, node);
                        is_valid = false;
                    }
                }
            }
        }
        
        public class ArgonThreadContext
            : DebugContext {
            
            public object CORE_REGISTER_OFFSETS = new Dictionary<object, object> {
                {
                    4,
                    0},
                {
                    5,
                    4},
                {
                    6,
                    8},
                {
                    7,
                    12},
                {
                    8,
                    16},
                {
                    9,
                    20},
                {
                    10,
                    24},
                {
                    11,
                    28},
                {
                    0,
                    32},
                {
                    1,
                    36},
                {
                    2,
                    40},
                {
                    3,
                    44},
                {
                    12,
                    48},
                {
                    14,
                    52},
                {
                    15,
                    56},
                {
                    16,
                    60}};
            
            public object FPU_EXTENDED_REGISTER_OFFSETS = new Dictionary<object, object> {
                {
                    4,
                    0},
                {
                    5,
                    4},
                {
                    6,
                    8},
                {
                    7,
                    12},
                {
                    8,
                    16},
                {
                    9,
                    20},
                {
                    10,
                    24},
                {
                    11,
                    28},
                {
                    80,
                    32},
                {
                    81,
                    36},
                {
                    82,
                    40},
                {
                    83,
                    44},
                {
                    84,
                    48},
                {
                    85,
                    52},
                {
                    86,
                    56},
                {
                    87,
                    60},
                {
                    88,
                    64},
                {
                    89,
                    68},
                {
                    90,
                    72},
                {
                    91,
                    76},
                {
                    92,
                    80},
                {
                    93,
                    84},
                {
                    94,
                    88},
                {
                    95,
                    92},
                {
                    0,
                    96},
                {
                    1,
                    100},
                {
                    2,
                    104},
                {
                    3,
                    108},
                {
                    12,
                    112},
                {
                    14,
                    116},
                {
                    15,
                    120},
                {
                    16,
                    124},
                {
                    64,
                    128},
                {
                    65,
                    132},
                {
                    66,
                    136},
                {
                    67,
                    140},
                {
                    68,
                    144},
                {
                    69,
                    148},
                {
                    70,
                    152},
                {
                    71,
                    156},
                {
                    72,
                    160},
                {
                    73,
                    164},
                {
                    74,
                    168},
                {
                    75,
                    172},
                {
                    76,
                    176},
                {
                    77,
                    180},
                {
                    78,
                    184},
                {
                    79,
                    188},
                {
                    33,
                    192}};
            
            public object EXCEPTION_UNAVAILABLE_REGS = Tuple.Create(4, 5, 6, 7, 8, 9, 10, 11);
            
            public ArgonThreadContext(object parentContext, object thread) {
                this._parent = parentContext;
                this._thread = thread;
            }
            
            public virtual object readCoreRegistersRaw(object reg_list) {
                reg_list = reg_list.Select(reg => register_name_to_index(reg));
                var reg_vals = new List<object>();
                var inException = this._get_ipsr() > 0;
                var isCurrent = this._thread.is_current;
                // If this is the current thread and we're not in an exception, just read the live registers.
                if (isCurrent && !inException) {
                    return this._parent.readCoreRegistersRaw(reg_list);
                }
                var sp = this._thread.get_stack_pointer();
                // Determine which register offset table to use and the offsets past the saved state.
                var realSpOffset = 64;
                var realSpExceptionOffset = 32;
                var table = this.CORE_REGISTER_OFFSETS;
                if (this._thread.has_extended_frame) {
                    table = this.FPU_EXTENDED_REGISTER_OFFSETS;
                    realSpOffset = 200;
                    realSpExceptionOffset = 104;
                }
                foreach (var reg in reg_list) {
                    // Check for regs we can't access.
                    if (isCurrent && inException) {
                        if (this.EXCEPTION_UNAVAILABLE_REGS.Contains(reg)) {
                            reg_vals.append(0);
                            continue;
                        }
                        if (reg == 18 || reg == 13) {
                            // PSP
                            log.debug("psp = 0x%08x", sp + realSpExceptionOffset);
                            reg_vals.append(sp + realSpExceptionOffset);
                            continue;
                        }
                    }
                    // Must handle stack pointer specially.
                    if (reg == 13) {
                        reg_vals.append(sp + realSpOffset);
                        continue;
                    }
                    // Look up offset for this register on the stack.
                    var spOffset = table.get(reg, null);
                    if (spOffset == null) {
                        reg_vals.append(this._parent.readCoreRegisterRaw(reg));
                        continue;
                    }
                    if (isCurrent && inException) {
                        spOffset -= realSpExceptionOffset;
                    }
                    try {
                        reg_vals.append(this._parent.read32(sp + spOffset));
                    } catch {
                        reg_vals.append(0);
                    }
                }
                return reg_vals;
            }
            
            public virtual object _get_ipsr() {
                return this._parent.readCoreRegister("xpsr") & 255;
            }
            
            public virtual object writeCoreRegistersRaw(object reg_list, object data_list) {
                this._parent.writeCoreRegistersRaw(reg_list, data_list);
            }
        }
        
        public class ArgonThread
            : TargetThread {
            
            public object UNKNOWN = 0;
            
            public object SUSPENDED = 1;
            
            public object READY = 2;
            
            public object RUNNING = 3;
            
            public object BLOCKED = 4;
            
            public object SLEEPING = 5;
            
            public object DONE = 6;
            
            public object STATE_NAMES = new Dictionary<object, object> {
                {
                    UNKNOWN,
                    "Unknown"},
                {
                    SUSPENDED,
                    "Suspended"},
                {
                    READY,
                    "Ready"},
                {
                    RUNNING,
                    "Running"},
                {
                    BLOCKED,
                    "Blocked"},
                {
                    SLEEPING,
                    "Sleeping"},
                {
                    DONE,
                    "Done"}};
            
            public ArgonThread(object targetContext, object provider, object @base) {
                this._target_context = targetContext;
                this._provider = provider;
                this._base = @base;
                this._thread_context = ArgonThreadContext(this._target_context, this);
                this._has_fpu = this._thread_context.core.has_fpu;
                this._priority = 0;
                this._state = this.UNKNOWN;
                this._name = "?";
                try {
                    this.update_info();
                    var ptr = this._target_context.read32(this._base + THREAD_NAME_OFFSET);
                    this._name = read_c_string(this._target_context, ptr);
                } catch {
                    log.debug("Transfer error while reading thread info");
                }
            }
            
            public virtual object get_stack_pointer() {
                var sp = 0;
                if (this.is_current) {
                    // Read live process stack.
                    sp = this._target_context.readCoreRegister("psp");
                } else {
                    // Get stack pointer saved in thread struct.
                    try {
                        sp = this._target_context.read32(this._base + THREAD_STACK_POINTER_OFFSET);
                    } catch {
                        log.debug("Transfer error while reading thread's stack pointer @ 0x%08x", this._base + THREAD_STACK_POINTER_OFFSET);
                    }
                }
                return sp;
            }
            
            public virtual object update_info() {
                try {
                    this._priority = this._target_context.read8(this._base + THREAD_PRIORITY_OFFSET);
                    this._state = this._target_context.read8(this._base + THREAD_STATE_OFFSET);
                    if (this._state > this.DONE) {
                        this._state = this.UNKNOWN;
                    }
                } catch {
                    log.debug("Transfer error while reading thread info");
                }
            }
            
            public object state {
                get {
                    return this._state;
                }
            }
            
            public object priority {
                get {
                    return this._priority;
                }
            }
            
            public object unique_id {
                get {
                    return this._base;
                }
            }
            
            public object name {
                get {
                    return this._name;
                }
            }
            
            public object description {
                get {
                    return String.Format("%s; Priority %d", this.STATE_NAMES[this.state], this.priority);
                }
            }
            
            public object is_current {
                get {
                    return this._provider.get_actual_current_thread_id() == this.unique_id;
                }
            }
            
            public object context {
                get {
                    return this._thread_context;
                }
            }
            
            public object has_extended_frame {
                get {
                    if (!this._has_fpu) {
                        return false;
                    }
                    try {
                        var flag = this._target_context.read8(this._base + THREAD_EXTENDED_FRAME_OFFSET);
                        return flag != 0;
                    } catch {
                        log.debug("Transfer error while reading thread's extended frame flag @ 0x%08x", this._base + THREAD_EXTENDED_FRAME_OFFSET);
                        return false;
                    }
                }
            }
            
            public override object ToString() {
                return String.Format("<ArgonThread@0x%08x id=%x name=%s>", id(this), this.unique_id, this.name);
            }
            
            public virtual object @__repr__() {
                return str(this);
            }
        }
        
        public class ArgonThreadProvider
            : ThreadProvider {
            
            public ArgonThreadProvider(object target) {
                this.g_ar = null;
                this.g_ar_objects = null;
                this._all_threads = null;
                this._threads = new Dictionary<object, object> {
                };
            }
            
            public virtual object init(object symbolProvider) {
                this.g_ar = symbolProvider.get_symbol_value("g_ar");
                if (this.g_ar == null) {
                    return false;
                }
                log.debug("Argon: g_ar = 0x%08x", this.g_ar);
                this.g_ar_objects = symbolProvider.get_symbol_value("g_ar_objects");
                if (this.g_ar_objects == null) {
                    return false;
                }
                log.debug("Argon: g_ar_objects = 0x%08x", this.g_ar_objects);
                this._all_threads = this.g_ar_objects + ALL_OBJECTS_THREADS_OFFSET;
                return true;
            }
            
            public virtual object _build_thread_list() {
                object t;
                var allThreads = TargetList(this._target_context, this._all_threads);
                var newThreads = new Dictionary<object, object> {
                };
                foreach (var threadBase in allThreads) {
                    try {
                        // Reuse existing thread objects if possible.
                        if (this._threads.Contains(threadBase)) {
                            t = this._threads[threadBase];
                            // Ask the thread object to update its state and priority.
                            t.update_info();
                        } else {
                            t = ArgonThread(this._target_context, this, threadBase);
                        }
                        log.debug("Thread 0x%08x (%s)", threadBase, t.name);
                        newThreads[t.unique_id] = t;
                    } catch {
                        log.debug("TransferError while examining thread 0x%08x", threadBase);
                    }
                }
                // Create fake handler mode thread.
                if (this.get_ipsr() > 0) {
                    log.debug("creating handler mode thread");
                    t = HandlerModeThread(this._target_context, this);
                    newThreads[t.unique_id] = t;
                }
                this._threads = newThreads;
            }
            
            public virtual object get_threads() {
                if (!this.is_enabled) {
                    return new List<object>();
                }
                this.update_threads();
                return this._threads.values();
            }
            
            public virtual object get_thread(object threadId) {
                if (!this.is_enabled) {
                    return null;
                }
                this.update_threads();
                return this._threads.get(threadId, null);
            }
            
            public object is_enabled {
                get {
                    return this.g_ar != null && this.get_is_running();
                }
            }
            
            public object current_thread {
                get {
                    if (!this.is_enabled) {
                        return null;
                    }
                    this.update_threads();
                    var id = this.get_current_thread_id();
                    try {
                        return this._threads[id];
                    } catch (KeyError) {
                        log.debug("key error getting current thread id=%x", id);
                        log.debug("self._threads = %s", repr(this._threads));
                        return null;
                    }
                }
            }
            
            public virtual object is_valid_thread_id(object threadId) {
                if (!this.is_enabled) {
                    return false;
                }
                this.update_threads();
                return this._threads.Contains(threadId);
            }
            
            public virtual object get_current_thread_id() {
                if (!this.is_enabled) {
                    return null;
                }
                if (this.get_ipsr() > 0) {
                    return 2;
                }
                return this.get_actual_current_thread_id();
            }
            
            public virtual object get_actual_current_thread_id() {
                if (!this.is_enabled) {
                    return null;
                }
                return this._target_context.read32(this.g_ar);
            }
            
            public virtual object get_is_running() {
                if (this.g_ar == null) {
                    return false;
                }
                var flag = this._target_context.read8(this.g_ar + IS_RUNNING_OFFSET);
                return flag != 0;
            }
        }
    }
}
