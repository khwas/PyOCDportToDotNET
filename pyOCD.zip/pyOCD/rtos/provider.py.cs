// 
//  mbed CMSIS-DAP debugger
//  Copyright (c) 2016 ARM Limited
// 
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
// 
//      http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// 
namespace rtos {
    
    using logging;
    
    using System.Collections.Generic;
    
    public static class provider {
        
        public class TargetThread
            : object {
            
            public TargetThread() {
            }
            
            public object unique_id {
                get {
                    throw NotImplementedError();
                }
            }
            
            public object name {
                get {
                    throw NotImplementedError();
                }
            }
            
            public object description {
                get {
                    throw NotImplementedError();
                }
            }
            
            public object is_current {
                get {
                    throw NotImplementedError();
                }
            }
            
            public object context {
                get {
                    throw NotImplementedError();
                }
            }
        }
        
        public class ThreadProvider
            : object {
            
            public ThreadProvider(object target) {
                this._target = target;
                this._target_context = this._target.getTargetContext();
                this._last_run_token = -1;
            }
            
            public virtual object _lookup_symbols(object symbolList, object symbolProvider) {
                var syms = new Dictionary<object, object> {
                };
                foreach (var name in symbolList) {
                    var addr = symbolProvider.get_symbol_value(name);
                    logging.debug("Value for symbol %s = %s", name, addr != null ? hex(addr) : "<none>");
                    if (addr == null) {
                        return null;
                    }
                    syms[name] = addr;
                }
                return syms;
            }
            
            //#
            // @retval True The provider was successfully initialzed.
            // @retval False The provider could not be initialized successfully.
            public virtual object init(object symbolProvider) {
                throw NotImplementedError();
            }
            
            public virtual object _build_thread_list() {
                throw NotImplementedError();
            }
            
            public virtual object _is_thread_list_dirty() {
                var token = this._target.run_token;
                if (token == this._last_run_token) {
                    // Target hasn't run since we last updated threads, so there is nothing to do.
                    return false;
                }
                this._last_run_token = token;
                return true;
            }
            
            public virtual object update_threads() {
                if (this._is_thread_list_dirty()) {
                    this._build_thread_list();
                }
            }
            
            public virtual object get_threads() {
                throw NotImplementedError();
            }
            
            public virtual object get_thread(object threadId) {
                throw NotImplementedError();
            }
            
            public object is_enabled {
                get {
                    throw NotImplementedError();
                }
            }
            
            public object current_thread {
                get {
                    throw NotImplementedError();
                }
            }
            
            public virtual object is_valid_thread_id(object threadId) {
                throw NotImplementedError();
            }
            
            public virtual object get_ipsr() {
                return this._target_context.readCoreRegister("xpsr") & 255;
            }
            
            public virtual object get_current_thread_id() {
                throw NotImplementedError();
            }
        }
    }
}
