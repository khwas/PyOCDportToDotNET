namespace tools {
    
    using argparse;
    
    using logging;
    
    using os;
    
    using sys;
    
    using optparse;
    
    using make_option = optparse.make_option;
    
    using traceback;
    
    using readline;
    
    using pyOCD;
    
    using @@__version__ = @pyOCD.@@__version__;
    
    using MbedBoard = pyOCD.board.MbedBoard;
    
    using target_kinetis = pyOCD.target.family.target_kinetis;

    //using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    using pyDAPAccess;
    
    using Target = pyOCD.core.target.Target;
    
    using mask = pyOCD.utility.mask;
    
    using capstone;
    
    using System.Collections.Generic;
    
    using System;
    
    public static class pyocd {
        
        static pyocd() {
            string license = @"
 mbed CMSIS-DAP debugger
 Copyright (c) 2015 ARM Limited

 Licensed under the Apache License, Version 2.0 (the ""License"");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an ""AS IS"" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
";
            main();
        }
        
        public static object isCapstoneAvailable = true;
        
        public static object isCapstoneAvailable = false;
        
        public static object LEVELS = new Dictionary<object, object> {
            {
                "debug",
                logging.DEBUG},
            {
                "info",
                logging.INFO},
            {
                "warning",
                logging.WARNING},
            {
                "error",
                logging.ERROR},
            {
                "critical",
                logging.CRITICAL}};
        
        public static object CORE_STATUS_DESC = new Dictionary<object, object> {
            {
                Target.TARGET_HALTED,
                "Halted"},
            {
                Target.TARGET_RUNNING,
                "Running"},
            {
                Target.TARGET_RESET,
                "Reset"},
            {
                Target.TARGET_SLEEPING,
                "Sleeping"},
            {
                Target.TARGET_LOCKUP,
                "Lockup"}};
        
        public static object VC_NAMES_MAP = new Dictionary<object, object> {
            {
                Target.CATCH_HARD_FAULT,
                "hard fault"},
            {
                Target.CATCH_BUS_FAULT,
                "bus fault"},
            {
                Target.CATCH_MEM_FAULT,
                "memory fault"},
            {
                Target.CATCH_INTERRUPT_ERR,
                "interrupt error"},
            {
                Target.CATCH_STATE_ERR,
                "state error"},
            {
                Target.CATCH_CHECK_ERR,
                "check error"},
            {
                Target.CATCH_COPROCESSOR_ERR,
                "coprocessor error"},
            {
                Target.CATCH_CORE_RESET,
                "core reset"}};
        
        public static object DP_REGS_MAP = new Dictionary<object, object> {
            {
                0,
                DAPAccess.REG.DP_0x0},
            {
                4,
                DAPAccess.REG.DP_0x4},
            {
                8,
                DAPAccess.REG.DP_0x8},
            {
                12,
                DAPAccess.REG.DP_0xC}};
        
        public static object DEFAULT_CLOCK_FREQ_KHZ = 1000;
        
        public static object COMMAND_INFO = new Dictionary<object, object> {
            {
                "list",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Show available targets"}}},
            {
                "erase",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "ADDR [COUNT]"},
                    {
                        "help",
                        "Erase internal flash sectors"}}},
            {
                "unlock",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Unlock security on the target"}}},
            {
                "status",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "stat"
                        }},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Show the target's current state"}}},
            {
                "reg",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "[-f] [REG]"},
                    {
                        "help",
                        "Print all or one register"}}},
            {
                "wreg",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "REG VALUE"},
                    {
                        "help",
                        "Set the value of a register"}}},
            {
                "reset",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "[-h/--halt]"},
                    {
                        "help",
                        "Reset the target"}}},
            {
                "savemem",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "ADDR LEN FILENAME"},
                    {
                        "help",
                        "Save a range of memory to a binary file"}}},
            {
                "loadmem",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "ADDR FILENAME"},
                    {
                        "help",
                        "Load a binary file to an address in memory"}}},
            {
                "read8",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "read",
                            "r",
                            "rb"
                        }},
                    {
                        "args",
                        "ADDR [LEN]"},
                    {
                        "help",
                        "Read 8-bit bytes"}}},
            {
                "read16",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "r16",
                            "rh"
                        }},
                    {
                        "args",
                        "ADDR [LEN]"},
                    {
                        "help",
                        "Read 16-bit halfwords"}}},
            {
                "read32",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "r32",
                            "rw"
                        }},
                    {
                        "args",
                        "ADDR [LEN]"},
                    {
                        "help",
                        "Read 32-bit words"}}},
            {
                "write8",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "write",
                            "w",
                            "wb"
                        }},
                    {
                        "args",
                        "ADDR DATA..."},
                    {
                        "help",
                        "Write 8-bit bytes"}}},
            {
                "write16",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "w16",
                            "wh"
                        }},
                    {
                        "args",
                        "ADDR DATA..."},
                    {
                        "help",
                        "Write 16-bit halfwords"}}},
            {
                "write32",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "w32",
                            "ww"
                        }},
                    {
                        "args",
                        "ADDR DATA..."},
                    {
                        "help",
                        "Write 32-bit words"}}},
            {
                "go",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "g"
                        }},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Resume execution of the target"}}},
            {
                "step",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "s"
                        }},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Step one instruction"}}},
            {
                "halt",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "h"
                        }},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Halt the target"}}},
            {
                "break",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "ADDR"},
                    {
                        "help",
                        "Set a breakpoint address"}}},
            {
                "rmbreak",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "ADDR"},
                    {
                        "help",
                        "Remove a breakpoint"}}},
            {
                "lsbreak",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "List breakpoints"}}},
            {
                "help",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "?"
                        }},
                    {
                        "args",
                        "[CMD]"},
                    {
                        "help",
                        "Show help for commands"}}},
            {
                "disasm",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "d"
                        }},
                    {
                        "args",
                        "[-c/--center] ADDR [LEN]"},
                    {
                        "help",
                        "Disassemble instructions at an address"},
                    {
                        "extra_help",
                        "Only available if the capstone library is installed."}}},
            {
                "exit",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "quit"
                        }},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Quit pyocd-tool"}}},
            {
                "core",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "[NUM]"},
                    {
                        "help",
                        "Select CPU core by number or print selected core"}}},
            {
                "readdp",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "rdp"
                        }},
                    {
                        "args",
                        "ADDR"},
                    {
                        "help",
                        "Read DP register"}}},
            {
                "writedp",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "wdp"
                        }},
                    {
                        "args",
                        "ADDR DATA"},
                    {
                        "help",
                        "Read DP register"}}},
            {
                "readap",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "rap"
                        }},
                    {
                        "args",
                        "[APSEL] ADDR"},
                    {
                        "help",
                        "Read AP register"}}},
            {
                "writeap",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "wap"
                        }},
                    {
                        "args",
                        "[APSEL] ADDR DATA"},
                    {
                        "help",
                        "Read AP register"}}},
            {
                "reinit",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        ""},
                    {
                        "help",
                        "Reinitialize the target object"}}},
            {
                "show",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "INFO"},
                    {
                        "help",
                        "Report info about the target"}}},
            {
                "set",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "args",
                        "NAME VALUE"},
                    {
                        "help",
                        "Set an option value"},
                    {
                        "extra_help",
                        "Available info names: vc, vectorcatch."}}}};
        
        public static object INFO_HELP = new Dictionary<object, object> {
            {
                "map",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "Target memory map."}}},
            {
                "peripherals",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "List of target peripheral instances."}}},
            {
                "uid",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "Target's unique ID"}}},
            {
                "cores",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "Information about CPU cores in the target."}}},
            {
                "target",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "General target information."}}}};
        
        public static object OPTION_HELP = new Dictionary<object, object> {
            {
                "vector-catch",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "vc"
                        }},
                    {
                        "help",
                        "Control enabled vector catch sources. Value is a concatenation of one letter per enabled source in any order, or 'all' or 'none'. (h=hard fault, b=bus fault, m=mem fault, i=irq err, s=state err, c=check err, p=nocp, r=reset, a=all, n=none)."}}},
            {
                "step-into-interrupt",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object> {
                            "si"
                        }},
                    {
                        "help",
                        "Set whether to enable or disable interrupts when single stepping. Set to 1 to enable."}}},
            {
                "nreset",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "Set nRESET signal state. Accepts a value of 0 or 1."}}},
            {
                "log",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "Set log level to one of debug, info, warning, error, critical"}}},
            {
                "clock",
                new Dictionary<object, object> {
                    {
                        "aliases",
                        new List<object>()},
                    {
                        "help",
                        "Set SWD or JTAG clock frequency"}}}};
        
        public static object hex_width(object value, object width) {
            if (width == 8) {
                return String.Format("%02x", value);
            } else if (width == 16) {
                return String.Format("%04x", value);
            } else if (width == 32) {
                return String.Format("%08x", value);
            } else {
                throw ToolError(String.Format("unrecognized register width (%d)", reg.size));
            }
        }
        
        public static object dumpHexData(object data, object startAddress = 0, object width = 8) {
            var i = 0;
            while (i < data.Count) {
                Console.WriteLine(String.Format("%08x: ", startAddress + i));
                while (i < data.Count) {
                    var d = data[i];
                    i += 1;
                    if (width == 8) {
                        Console.WriteLine(String.Format("%02x", d));
                        if (i % 4 == 0) {
                            Console.WriteLine("");
                        }
                        if (i % 16 == 0) {
                            break;
                        }
                    } else if (width == 16) {
                        Console.WriteLine(String.Format("%04x", d));
                        if (i % 8 == 0) {
                            break;
                        }
                    } else if (width == 32) {
                        Console.WriteLine(String.Format("%08x", d));
                        if (i % 4 == 0) {
                            break;
                        }
                    }
                }
                Console.WriteLine();
            }
        }
        
        public class ToolError
            : Exception {
        }
        
        public class ToolExitException
            : Exception {
        }
        
        public static object cmdoptions(object opts) {
            Func<object, object> process_opts = fn => {
                var parser = optparse.OptionParser(add_help_option: false);
                foreach (var opt in opts) {
                    parser.add_option(opt);
                }
                Func<object, object, object> foo = (inst,args) => {
                    var _tup_1 = parser.parse_args(args);
                    var namespace = _tup_1.Item1;
                    var other_args = _tup_1.Item2;
                    return fn(inst, namespace, other_args);
                };
                return foo;
            };
            return process_opts;
        }
        
        public class PyOCDConsole
            : object {
            
            public object PROMPT = ">>> ";
            
            public PyOCDConsole(object tool) {
                this.tool = tool;
                this.last_command = "";
            }
            
            public virtual object run() {
                try {
                    while (true) {
                        try {
                            var line = raw_input(this.PROMPT);
                            line = line.strip();
                            if (line) {
                                this.process_command_line(line);
                                this.last_command = line;
                            } else if (this.last_command) {
                                this.process_command(this.last_command);
                            }
                        } catch (KeyboardInterrupt) {
                            Console.WriteLine();
                        }
                    }
                } catch (EOFError) {
                    // Print a newline when we get a Ctrl-D on a Posix system.
                    // Windows exits with a Ctrl-Z+Return, so there is no need for this.
                    if (os.name != "nt") {
                        Console.WriteLine();
                    }
                }
            }
            
            public virtual object process_command_line(object line) {
                foreach (var cmd in line.split(";")) {
                    this.process_command(cmd);
                }
            }
            
            public virtual object process_command(object cmd) {
                try {
                    var firstChar = cmd.strip()[0];
                    if ("$!".Contains(firstChar)) {
                        cmd = cmd[1].strip();
                        if (firstChar == "$") {
                            this.tool.handle_python(cmd);
                        } else if (firstChar == "!") {
                            os.system(cmd);
                        }
                        return;
                    }
                    var args = pyOCD.utility.cmdline.split_command_line(cmd);
                    cmd = args[0].lower();
                    args = args[1];
                    // Handle register name as command.
                    if (pyOCD.coresight.cortex_m.CORE_REGISTER.Contains(cmd)) {
                        this.tool.handle_reg(new List<object> {
                            cmd
                        });
                        return;
                    }
                    // Check for valid command.
                    if (!this.tool.command_list.Contains(cmd)) {
                        Console.WriteLine(String.Format("Error: unrecognized command '%s'", cmd));
                        return;
                    }
                    // Run command.
                    var handler = this.tool.command_list[cmd];
                    handler(args);
                } catch (ValueError) {
                    Console.WriteLine("Error: invalid argument");
                    traceback.print_exc();
                } catch {
                    Console.WriteLine("Error:", e);
                    traceback.print_exc();
                } catch (ToolError) {
                    Console.WriteLine("Error:", e);
                } catch (ToolExitException) {
                    throw;
                } catch (Exception) {
                    Console.WriteLine("Unexpected exception:", e);
                    traceback.print_exc();
                }
            }
        }
        
        public class PyOCDTool
            : object {
            
            public PyOCDTool() {
                this.board = null;
                this.exitCode = 0;
                this.step_into_interrupt = false;
                this.command_list = new Dictionary<object, object> {
                    {
                        "list",
                        this.handle_list},
                    {
                        "erase",
                        this.handle_erase},
                    {
                        "unlock",
                        this.handle_unlock},
                    {
                        "status",
                        this.handle_status},
                    {
                        "stat",
                        this.handle_status},
                    {
                        "reg",
                        this.handle_reg},
                    {
                        "wreg",
                        this.handle_write_reg},
                    {
                        "reset",
                        this.handle_reset},
                    {
                        "savemem",
                        this.handle_savemem},
                    {
                        "loadmem",
                        this.handle_loadmem},
                    {
                        "read",
                        this.handle_read8},
                    {
                        "read8",
                        this.handle_read8},
                    {
                        "read16",
                        this.handle_read16},
                    {
                        "read32",
                        this.handle_read32},
                    {
                        "r",
                        this.handle_read8},
                    {
                        "rb",
                        this.handle_read8},
                    {
                        "r16",
                        this.handle_read16},
                    {
                        "rh",
                        this.handle_read16},
                    {
                        "r32",
                        this.handle_read32},
                    {
                        "rw",
                        this.handle_read32},
                    {
                        "write",
                        this.handle_write8},
                    {
                        "write8",
                        this.handle_write8},
                    {
                        "write16",
                        this.handle_write16},
                    {
                        "write32",
                        this.handle_write32},
                    {
                        "w",
                        this.handle_write8},
                    {
                        "wb",
                        this.handle_write8},
                    {
                        "w16",
                        this.handle_write16},
                    {
                        "wh",
                        this.handle_write16},
                    {
                        "w32",
                        this.handle_write32},
                    {
                        "ww",
                        this.handle_write32},
                    {
                        "go",
                        this.handle_go},
                    {
                        "g",
                        this.handle_go},
                    {
                        "step",
                        this.handle_step},
                    {
                        "s",
                        this.handle_step},
                    {
                        "halt",
                        this.handle_halt},
                    {
                        "h",
                        this.handle_halt},
                    {
                        "break",
                        this.handle_breakpoint},
                    {
                        "rmbreak",
                        this.handle_remove_breakpoint},
                    {
                        "lsbreak",
                        this.handle_list_breakpoints},
                    {
                        "disasm",
                        this.handle_disasm},
                    {
                        "d",
                        this.handle_disasm},
                    {
                        "exit",
                        this.handle_exit},
                    {
                        "quit",
                        this.handle_exit},
                    {
                        "core",
                        this.handle_core},
                    {
                        "readdp",
                        this.handle_readdp},
                    {
                        "writedp",
                        this.handle_writedp},
                    {
                        "readap",
                        this.handle_readap},
                    {
                        "writeap",
                        this.handle_writeap},
                    {
                        "rdp",
                        this.handle_readdp},
                    {
                        "wdp",
                        this.handle_writedp},
                    {
                        "rap",
                        this.handle_readap},
                    {
                        "wap",
                        this.handle_writeap},
                    {
                        "reinit",
                        this.handle_reinit},
                    {
                        "show",
                        this.handle_show},
                    {
                        "set",
                        this.handle_set},
                    {
                        "help",
                        this.handle_help},
                    {
                        "?",
                        this.handle_help}};
                this.info_list = new Dictionary<object, object> {
                    {
                        "map",
                        this.handle_show_map},
                    {
                        "peripherals",
                        this.handle_show_peripherals},
                    {
                        "uid",
                        this.handle_show_unique_id},
                    {
                        "cores",
                        this.handle_show_cores},
                    {
                        "target",
                        this.handle_show_target}};
                this.option_list = new Dictionary<object, object> {
                    {
                        "vector-catch",
                        this.handle_set_vectorcatch},
                    {
                        "vc",
                        this.handle_set_vectorcatch},
                    {
                        "step-into-interrupt",
                        this.handle_set_step_interrupts},
                    {
                        "si",
                        this.handle_set_step_interrupts},
                    {
                        "nreset",
                        this.handle_set_nreset},
                    {
                        "log",
                        this.handle_set_log},
                    {
                        "clock",
                        this.handle_set_clock}};
            }
            
            public virtual object get_args() {
                var debug_levels = LEVELS.keys();
                var epi = "Available commands:\n" + ", ".join(this.command_list.keys().OrderBy(_p_1 => _p_1).ToList());
                var parser = argparse.ArgumentParser(description: "Target inspection utility", epilog: epi);
                parser.add_argument("--version", action: "version", version: @__version__);
                parser.add_argument("-H", "--halt", action: "store_true", help: "Halt core upon connect.");
                parser.add_argument("-N", "--no-init", action: "store_true", help: "Do not init debug system.");
                parser.add_argument("-k", "--clock", metavar: "KHZ", @default: DEFAULT_CLOCK_FREQ_KHZ, type: @int, help: "Set SWD speed in kHz. (Default 1 MHz.)");
                parser.add_argument("-b", "--board", action: "store", metavar: "ID", help: "Use the specified board. ");
                parser.add_argument("-t", "--target", action: "store", metavar: "TARGET", help: "Override target.");
                parser.add_argument("-d", "--debug", dest: "debug_level", choices: debug_levels, @default: "warning", help: "Set the level of system logging output. Supported choices are: " + ", ".join(debug_levels), metavar: "LEVEL");
                parser.add_argument("cmd", nargs: "?", @default: null, help: "Command");
                parser.add_argument("args", nargs: "*", help: "Arguments for the command.");
                parser.add_argument("-da", "--daparg", dest: "daparg", nargs: "+", help: "Send setting to DAPAccess layer.");
                return parser.parse_args();
            }
            
            public virtual object configure_logging() {
                var level = LEVELS.get(this.args.debug_level, logging.WARNING);
                logging.basicConfig(level: level);
            }
            
            public virtual object run() {
                try {
                    // Read command-line arguments.
                    this.args = this.get_args();
                    this.cmd = this.args.cmd;
                    if (this.cmd) {
                        this.cmd = this.cmd.lower();
                    }
                    // Set logging level
                    this.configure_logging();
                    DAPAccess.set_args(this.args.daparg);
                    // Check for a valid command.
                    if (this.cmd && !this.command_list.Contains(this.cmd)) {
                        Console.WriteLine(String.Format("Error: unrecognized command '%s'", this.cmd));
                        return 1;
                    }
                    // Handle certain commands without connecting.
                    if (this.cmd == "list") {
                        this.handle_list(new List<object>());
                        return 0;
                    } else if (this.cmd == "help") {
                        this.handle_help(this.args.args);
                        return 0;
                    }
                    if (this.args.clock != DEFAULT_CLOCK_FREQ_KHZ) {
                        Console.WriteLine(String.Format("Setting SWD clock to %d kHz", this.args.clock));
                    }
                    // Connect to board.
                    this.board = MbedBoard.chooseBoard(board_id: this.args.board, target_override: this.args.target, init_board: false, frequency: this.args.clock * 1000);
                    this.board.target.setAutoUnlock(false);
                    this.board.target.setHaltOnConnect(false);
                    try {
                        if (!this.args.no_init) {
                            this.board.init();
                        }
                    } catch {
                        if (!this.board.target.isLocked()) {
                            Console.WriteLine(String.Format("Transfer fault while initing board: %s", e));
                            traceback.print_exc();
                            this.exitCode = 1;
                            return this.exitCode;
                        }
                    } catch (Exception) {
                        Console.WriteLine(String.Format("Exception while initing board: %s", e));
                        traceback.print_exc();
                        this.exitCode = 1;
                        return this.exitCode;
                    }
                    this.target = this.board.target;
                    this.link = this.board.link;
                    this.flash = this.board.flash;
                    this.svd_device = this.target.svd_device;
                    this.peripherals = new Dictionary<object, object> {
                    };
                    if (this.svd_device) {
                        foreach (var p in this.svd_device.peripherals) {
                            this.peripherals[p.name.lower()] = p;
                        }
                    }
                    // Halt if requested.
                    if (this.args.halt) {
                        this.handle_halt(new List<object>());
                    }
                    // Handle a device with flash security enabled.
                    this.didErase = false;
                    if (!this.args.no_init && this.target.isLocked() && this.cmd != "unlock") {
                        Console.WriteLine("Warning: Target is locked, limited operations available. Use unlock command to mass erase and unlock.");
                    }
                    // If no command, enter interactive mode.
                    if (!this.cmd) {
                        if (!this.args.no_init) {
                            try {
                                // Say what we're connected to.
                                Console.WriteLine(String.Format("Connected to %s [%s]: %s", this.target.part_number, CORE_STATUS_DESC[this.target.getState()], this.board.getUniqueID()));
                            } catch {
                            }
                        }
                        // Run the command line.
                        var console = PyOCDConsole(this);
                        console.run();
                    } else {
                        // Invoke action handler.
                        var result = this.command_list[this.cmd](this.args.args);
                        if (result != null) {
                            this.exitCode = result;
                        }
                    }
                } catch (ToolExitException) {
                    this.exitCode = 0;
                } catch (ValueError) {
                    Console.WriteLine("Error: invalid argument");
                } catch {
                    Console.WriteLine("Error: transfer failed");
                    traceback.print_exc();
                    this.exitCode = 2;
                } catch (ToolError) {
                    Console.WriteLine("Error:", e);
                    this.exitCode = 1;
                } finally {
                    if (this.board != null) {
                        // Pass false to prevent target resume.
                        this.board.uninit(false);
                    }
                }
                return this.exitCode;
            }
            
            public virtual object handle_list(object args) {
                MbedBoard.listConnectedBoards();
            }
            
            public virtual object handle_status(object args) {
                if (this.target.isLocked()) {
                    Console.WriteLine("Security:       Locked");
                } else {
                    Console.WriteLine("Security:       Unlocked");
                }
                if (this.target is target_kinetis.Kinetis) {
                    Console.WriteLine(String.Format("MDM-AP Status:  0x%08x", this.target.mdm_ap.read_reg(target_kinetis.MDM_STATUS)));
                }
                if (!this.target.isLocked()) {
                    foreach (var _tup_1 in this.target.cores.Select((_p_1,_p_2) => Tuple.Create(_p_2, _p_1))) {
                        var i = _tup_1.Item1;
                        var c = _tup_1.Item2;
                        var core = this.target.cores[c];
                        Console.WriteLine(String.Format("Core %d status:  %s", i, CORE_STATUS_DESC[core.getState()]));
                    }
                }
            }
            
            public virtual object handle_reg(object args) {
                object show_fields;
                // If there are no args, print all register values.
                if (args.Count < 1) {
                    this.dump_registers();
                    return;
                }
                if (args.Count == 2 && args[0].lower() == "-f") {
                    args.Remove(0);
                    show_fields = true;
                } else {
                    show_fields = false;
                }
                var reg = args[0].lower();
                if (pyOCD.coresight.cortex_m.CORE_REGISTER.Contains(reg)) {
                    var value = this.target.readCoreRegister(reg);
                    if (object.ReferenceEquals(type(value), @int)) {
                        Console.WriteLine(String.Format("%s = 0x%08x (%d)", reg, value, value));
                    } else if (object.ReferenceEquals(type(value), float)) {
                        Console.WriteLine(String.Format("%s = %g", reg, value));
                    } else {
                        throw ToolError("Unknown register value type");
                    }
                } else {
                    var subargs = reg.split(".");
                    if (this.peripherals.has_key(subargs[0])) {
                        var p = this.peripherals[subargs[0]];
                        if (subargs.Count > 1) {
                            var r = p.registers.Where(x => x.name.lower() == subargs[1]);
                            if (r.Count) {
                                this._dump_peripheral_register(p, r[0], true);
                            } else {
                                throw ToolError(String.Format("invalid register '%s' for %s", subargs[1], p.name));
                            }
                        } else {
                            foreach (var r in p.registers) {
                                this._dump_peripheral_register(p, r, show_fields);
                            }
                        }
                    } else {
                        throw ToolError(String.Format("invalid peripheral '%s'", subargs[0]));
                    }
                }
            }
            
            public virtual object handle_write_reg(object args) {
                object value;
                if (args.Count < 1) {
                    throw ToolError("No register specified");
                }
                if (args.Count < 2) {
                    throw ToolError("No value specified");
                }
                var reg = args[0].lower();
                if (pyOCD.coresight.cortex_m.CORE_REGISTER.Contains(reg)) {
                    if (reg.startswith("s") && reg != "sp") {
                        value = float(args[1]);
                    } else {
                        value = this.convert_value(args[1]);
                    }
                    this.target.writeCoreRegister(reg, value);
                } else {
                    value = this.convert_value(args[1]);
                    var subargs = reg.split(".");
                    if (subargs.Count < 2) {
                        throw ToolError("no register specified");
                    }
                    if (this.peripherals.has_key(subargs[0])) {
                        var p = this.peripherals[subargs[0]];
                        var r = p.registers.Where(x => x.name.lower() == subargs[1]);
                        if (r.Count) {
                            r = r[0];
                            var addr = p.base_address + r.address_offset;
                            if (subargs.Count == 2) {
                                Console.WriteLine(String.Format("writing 0x%x to 0x%x:%d (%s)", value, addr, r.size, r.name));
                                this.target.writeMemory(addr, value, r.size);
                            } else if (subargs.Count == 3) {
                                var f = r.fields.Where(x => x.name.lower() == subargs[2]);
                                if (f.Count) {
                                    f = f[0];
                                    var msb = f.bit_offset + f.bit_width - 1;
                                    var lsb = f.bit_offset;
                                    var originalValue = this.target.readMemory(addr, r.size);
                                    value = mask.bfi(originalValue, msb, lsb, value);
                                    Console.WriteLine(String.Format("writing 0x%x to 0x%x[%d:%d]:%d (%s.%s)", value, addr, msb, lsb, r.size, r.name, f.name));
                                    this.target.writeMemory(addr, value, r.size);
                                }
                            } else {
                                throw ToolError("too many dots");
                            }
                            this._dump_peripheral_register(p, r, true);
                        } else {
                            throw ToolError(String.Format("invalid register '%s' for %s", subargs[1], p.name));
                        }
                    } else {
                        throw ToolError(String.Format("invalid peripheral '%s'", subargs[0]));
                    }
                }
            }
            
            [cmdoptions(new List<object> {
                make_option("-h", "--halt", action: "store_true")
            })]
            public virtual object handle_reset(object args, object other) {
                Console.WriteLine("Resetting target");
                if (args.halt) {
                    this.target.resetStopOnReset();
                    var status = this.target.getState();
                    if (status != Target.TARGET_HALTED) {
                        Console.WriteLine("Failed to halt device on reset");
                    } else {
                        Console.WriteLine("Successfully halted device on reset");
                    }
                } else {
                    this.target.reset();
                }
            }
            
            public virtual object handle_set_nreset(object args) {
                if (args.Count != 1) {
                    Console.WriteLine("Missing reset state");
                    return;
                }
                var state = Convert.ToInt32(args[0], @base: 0);
                Console.WriteLine(String.Format("nRESET = %d", state));
                this.target.dp.assert_reset(state == 0);
            }
            
            [cmdoptions(new List<object> {
                make_option("-c", "--center", action: "store_true")
            })]
            public virtual object handle_disasm(object args, object other) {
                object count;
                if (other.Count == 0) {
                    Console.WriteLine("Error: no address specified");
                    return 1;
                }
                var addr = this.convert_value(other[0]);
                if (other.Count < 2) {
                    count = 6;
                } else {
                    count = this.convert_value(other[1]);
                }
                if (args.center) {
                    addr -= count / 2;
                }
                // Since we're disassembling, make sure the Thumb bit is cleared.
                addr |= ~1;
                // Print disasm of data.
                var data = this.target.readBlockMemoryUnaligned8(addr, count);
                this.print_disasm(str(bytearray(data)), addr);
            }
            
            public virtual object handle_read8(object args) {
                return this.do_read(args, 8);
            }
            
            public virtual object handle_read16(object args) {
                return this.do_read(args, 16);
            }
            
            public virtual object handle_read32(object args) {
                return this.do_read(args, 32);
            }
            
            public virtual object handle_write8(object args) {
                return this.do_write(args, 8);
            }
            
            public virtual object handle_write16(object args) {
                return this.do_write(args, 16);
            }
            
            public virtual object handle_write32(object args) {
                return this.do_write(args, 32);
            }
            
            public virtual object handle_savemem(object args) {
                if (args.Count < 3) {
                    Console.WriteLine("Error: missing argument");
                    return 1;
                }
                var addr = this.convert_value(args[0]);
                var count = this.convert_value(args[1]);
                var filename = args[2];
                var data = bytearray(this.target.readBlockMemoryUnaligned8(addr, count));
                using (var f = open(filename, "wb")) {
                    f.write(data);
                    Console.WriteLine(String.Format("Saved %d bytes to %s", count, filename));
                }
            }
            
            public virtual object handle_loadmem(object args) {
                if (args.Count < 2) {
                    Console.WriteLine("Error: missing argument");
                    return 1;
                }
                var addr = this.convert_value(args[0]);
                var filename = args[1];
                using (var f = open(filename, "rb")) {
                    data = bytearray(f.read());
                    this.target.writeBlockMemoryUnaligned8(addr, data);
                    Console.WriteLine(String.Format("Loaded %d bytes to 0x%08x", data.Count, addr));
                }
            }
            
            public virtual object do_read(object args, object width) {
                object count;
                if (args.Count == 0) {
                    Console.WriteLine("Error: no address specified");
                    return 1;
                }
                var addr = this.convert_value(args[0]);
                if (args.Count < 2) {
                    count = width / 8;
                } else {
                    count = this.convert_value(args[1]);
                }
                if (width == 8) {
                    var data = this.target.readBlockMemoryUnaligned8(addr, count);
                    var byteData = data;
                } else if (width == 16) {
                    byteData = this.target.readBlockMemoryUnaligned8(addr, count);
                    data = pyOCD.utility.conversion.byteListToU16leList(byteData);
                } else if (width == 32) {
                    byteData = this.target.readBlockMemoryUnaligned8(addr, count);
                    data = pyOCD.utility.conversion.byteListToU32leList(byteData);
                }
                // Print hex dump of output.
                dumpHexData(data, addr, width: width);
            }
            
            public virtual object do_write(object args, object width) {
                object data;
                if (args.Count == 0) {
                    Console.WriteLine("Error: no address specified");
                    return 1;
                }
                var addr = this.convert_value(args[0]);
                if (args.Count <= 1) {
                    Console.WriteLine("Error: no data for write");
                    return 1;
                } else {
                    data = args[1].Select(d => this.convert_value(d));
                }
                if (width == 8) {
                } else if (width == 16) {
                    data = pyOCD.utility.conversion.u16leListToByteList(data);
                } else if (width == 32) {
                    data = pyOCD.utility.conversion.u32leListToByteList(data);
                }
                if (this.isFlashWrite(addr, width, data)) {
                    this.target.flash.init();
                    this.target.flash.programPhrase(addr, data);
                } else {
                    this.target.writeBlockMemoryUnaligned8(addr, data);
                    this.target.flush();
                }
            }
            
            public virtual object handle_erase(object args) {
                object count;
                if (args.Count < 1) {
                    throw ToolError("invalid arguments");
                }
                var addr = this.convert_value(args[0]);
                if (args.Count < 2) {
                    count = 1;
                } else {
                    count = this.convert_value(args[1]);
                }
                this.flash.init();
                while (count) {
                    var info = this.flash.getPageInfo(addr);
                    this.flash.erasePage(info.base_addr);
                    Console.WriteLine(String.Format("Erased page 0x%08x", info.base_addr));
                    count -= 1;
                    addr += info.size;
                }
            }
            
            public virtual object handle_unlock(object args) {
                // Currently the same as erase.
                if (!this.didErase) {
                    this.target.massErase();
                }
            }
            
            public virtual object handle_go(object args) {
                this.target.resume();
                var status = this.target.getState();
                if (status == Target.TARGET_RUNNING) {
                    Console.WriteLine("Successfully resumed device");
                } else {
                    Console.WriteLine("Failed to resume device");
                }
            }
            
            public virtual object handle_step(object args) {
                this.target.step(disable_interrupts: !this.step_into_interrupt);
                var addr = this.target.readCoreRegister("pc");
                if (isCapstoneAvailable) {
                    addr |= ~1;
                    var data = this.target.readBlockMemoryUnaligned8(addr, 4);
                    this.print_disasm(str(bytearray(data)), addr, maxInstructions: 1);
                } else {
                    Console.WriteLine(String.Format("PC = 0x%08x", addr));
                }
            }
            
            public virtual object handle_halt(object args) {
                this.target.halt();
                var status = this.target.getState();
                if (status != Target.TARGET_HALTED) {
                    Console.WriteLine("Failed to halt device");
                    return 1;
                } else {
                    Console.WriteLine("Successfully halted device");
                }
            }
            
            public virtual object handle_breakpoint(object args) {
                if (args.Count < 1) {
                    throw ToolError("no breakpoint address provided");
                }
                var addr = this.convert_value(args[0]);
                if (this.target.setBreakpoint(addr)) {
                    this.target.selected_core.bp_manager.flush();
                    Console.WriteLine(String.Format("Set breakpoint at 0x%08x", addr));
                } else {
                    Console.WriteLine(String.Format("Failed to set breakpoint at 0x%08x", addr));
                }
            }
            
            public virtual object handle_remove_breakpoint(object args) {
                if (args.Count < 1) {
                    throw ToolError("no breakpoint address provided");
                }
                var addr = this.convert_value(args[0]);
                try {
                    var type = this.target.getBreakpointType(addr);
                    this.target.removeBreakpoint(addr);
                    this.target.selected_core.bp_manager.flush();
                    Console.WriteLine(String.Format("Removed breakpoint at 0x%08x", addr));
                } catch {
                    Console.WriteLine(String.Format("Failed to remove breakpoint at 0x%08x", addr));
                }
            }
            
            public virtual object handle_list_breakpoints(object args) {
                var availableBpCount = this.target.selected_core.availableBreakpoint();
                Console.WriteLine(String.Format("%d hardware breakpoints available", availableBpCount));
                var bps = this.target.selected_core.bp_manager.get_breakpoints();
                if (!bps.Count) {
                    Console.WriteLine("No breakpoints installed");
                } else {
                    foreach (var _tup_1 in bps.Select((_p_1,_p_2) => Tuple.Create(_p_2, _p_1))) {
                        var i = _tup_1.Item1;
                        var addr = _tup_1.Item2;
                        Console.WriteLine(String.Format("%d: 0x%08x", i, addr));
                    }
                }
            }
            
            public virtual object handle_set_log(object args) {
                if (args.Count < 1) {
                    Console.WriteLine("Error: no log level provided");
                    return 1;
                }
                if (!LEVELS.Contains(args[0].lower())) {
                    Console.WriteLine(String.Format("Error: log level must be one of {%s}", ",".join(LEVELS.keys())));
                    return 1;
                }
                logging.getLogger().setLevel(LEVELS[args[0].lower()]);
            }
            
            public virtual object handle_set_clock(object args) {
                object swd_jtag;
                if (args.Count < 1) {
                    Console.WriteLine("Error: no clock frequency provided");
                    return 1;
                }
                try {
                    var freq_Hz = this.convert_value(args[0]) * 1000;
                } catch {
                    Console.WriteLine("Error: invalid frequency");
                    return 1;
                }
                this.link.set_clock(freq_Hz);
                if (this.link.get_swj_mode() == DAPAccess.PORT.SWD) {
                    swd_jtag = "SWD";
                } else {
                    swd_jtag = "JTAG";
                }
                if (freq_Hz >= 1000000) {
                    var nice_freq = String.Format("%.2f MHz", freq_Hz / 1000000);
                } else if (freq_Hz > 1000) {
                    nice_freq = String.Format("%.2f kHz", freq_Hz / 1000);
                } else {
                    nice_freq = String.Format("%d Hz", freq_Hz);
                }
                Console.WriteLine(String.Format("Changed %s frequency to %s", swd_jtag, nice_freq));
            }
            
            public virtual object handle_exit(object args) {
                throw ToolExitException();
            }
            
            public virtual object handle_python(object args) {
                try {
                    var env = new Dictionary<object, object> {
                        {
                            "board",
                            this.board},
                        {
                            "target",
                            this.target},
                        {
                            "link",
                            this.link},
                        {
                            "flash",
                            this.flash}};
                    var result = eval(args, globals(), env);
                    if (result != null) {
                        if (object.ReferenceEquals(type(result), @int)) {
                            Console.WriteLine(String.Format("0x%08x (%d)", result, result));
                        } else {
                            Console.WriteLine(result);
                        }
                    }
                } catch (Exception) {
                    Console.WriteLine("Exception while executing expression:", e);
                    traceback.print_exc();
                }
            }
            
            public virtual object handle_core(object args) {
                if (args.Count < 1) {
                    Console.WriteLine(String.Format("Core %d is selected", this.target.selected_core.core_number));
                    return;
                }
                var core = Convert.ToInt32(args[0], @base: 0);
                this.target.select_core(core);
                Console.WriteLine(String.Format("Selected core %d", core));
            }
            
            public virtual object handle_readdp(object args) {
                if (args.Count < 1) {
                    Console.WriteLine("Missing DP address");
                    return;
                }
                var addr_int = this.convert_value(args[0]);
                var addr = DP_REGS_MAP[addr_int];
                var result = this.target.dp.read_reg(addr);
                Console.WriteLine(String.Format("DP register 0x%x = 0x%08x", addr_int, result));
            }
            
            public virtual object handle_writedp(object args) {
                if (args.Count < 1) {
                    Console.WriteLine("Missing DP address");
                    return;
                }
                if (args.Count < 2) {
                    Console.WriteLine("Missing value");
                    return;
                }
                var addr_int = this.convert_value(args[0]);
                var addr = DP_REGS_MAP[addr_int];
                var data = this.convert_value(args[1]);
                this.target.dp.write_reg(addr, data);
            }
            
            public virtual object handle_readap(object args) {
                object addr;
                if (args.Count < 1) {
                    Console.WriteLine("Missing AP address");
                    return;
                }
                if (args.Count == 1) {
                    addr = this.convert_value(args[0]);
                } else if (args.Count == 2) {
                    addr = this.convert_value(args[0]) << 24 | this.convert_value(args[1]);
                }
                var result = this.target.dp.readAP(addr);
                Console.WriteLine(String.Format("AP register 0x%x = 0x%08x", addr, result));
            }
            
            public virtual object handle_writeap(object args) {
                object data_arg;
                object addr;
                if (args.Count < 1) {
                    Console.WriteLine("Missing AP address");
                    return;
                }
                if (args.Count < 2) {
                    Console.WriteLine("Missing value");
                    return;
                }
                if (args.Count == 2) {
                    addr = this.convert_value(args[0]);
                    data_arg = 1;
                } else if (args.Count == 3) {
                    addr = this.convert_value(args[0]) << 24 | this.convert_value(args[1]);
                    data_arg = 2;
                }
                var data = this.convert_value(args[data_arg]);
                this.target.dp.writeAP(addr, data);
            }
            
            public virtual object handle_reinit(object args) {
                this.target.init();
            }
            
            public virtual object handle_show(object args) {
                if (args.Count < 1) {
                    throw ToolError("missing info name argument");
                }
                var infoName = args[0];
                try {
                    this.info_list[infoName](args[1]);
                } catch (KeyError) {
                    throw ToolError(String.Format("unkown info name '%s'", infoName));
                }
            }
            
            public virtual object handle_show_unique_id(object args) {
                Console.WriteLine(String.Format("Unique ID:    %s", this.board.getUniqueID()));
            }
            
            public virtual object handle_show_target(object args) {
                Console.WriteLine(String.Format("Target:       %s", this.target.part_number));
                Console.WriteLine(String.Format("DAP IDCODE:   0x%08x", this.target.readIDCode()));
            }
            
            public virtual object handle_show_cores(object args) {
                if (this.target.isLocked()) {
                    Console.WriteLine("Target is locked");
                } else {
                    Console.WriteLine(String.Format("Cores:        %d", this.target.cores.Count));
                    foreach (var _tup_1 in this.target.cores.Select((_p_1,_p_2) => Tuple.Create(_p_2, _p_1))) {
                        var i = _tup_1.Item1;
                        var c = _tup_1.Item2;
                        var core = this.target.cores[c];
                        Console.WriteLine(String.Format("Core %d type:  %s", i, pyOCD.coresight.cortex_m.CORE_TYPE_NAME[core.core_type]));
                    }
                }
            }
            
            public virtual object handle_show_map(object args) {
                Console.WriteLine("Region          Start         End                 Size    Blocksize");
                foreach (var region in this.target.getMemoryMap()) {
                    Console.WriteLine("{:<15} {:#010x}    {:#010x}    {:#10x}    {}".format(region.name, region.start, region.end, region.length, region.isFlash ? region.blocksize : "-"));
                }
            }
            
            public virtual object handle_show_peripherals(object args) {
                foreach (var periph in this.peripherals.values().OrderBy(x => x.base_address).ToList()) {
                    Console.WriteLine(String.Format("0x%08x: %s", periph.base_address, periph.name));
                }
            }
            
            public virtual object handle_set(object args) {
                if (args.Count < 1) {
                    throw ToolError("missing option name argument");
                }
                var name = args[0];
                try {
                    this.option_list[name](args[1]);
                } catch (KeyError) {
                    throw ToolError(String.Format("unkown option name '%s'", name));
                }
            }
            
            public virtual object handle_set_vectorcatch(object args) {
                if (args.Count == 0) {
                    var catch = this.target.getVectorCatch();
                    Console.WriteLine("Vector catch:");
                    foreach (var mask in VC_NAMES_MAP.Keys.OrderBy(_p_1 => _p_1).ToList()) {
                        var name = VC_NAMES_MAP[mask];
                        var s = catch & mask ? "ON" : "OFF";
                        Console.WriteLine("  {:3} {}".format(s, name));
                    }
                } else {
                    try {
                        this.target.setVectorCatch(pyOCD.utility.cmdline.convert_vector_catch(args[0]));
                    } catch (ValueError) {
                        Console.WriteLine(e);
                    }
                }
            }
            
            public virtual object handle_set_step_interrupts(object args) {
                if (args.Count == 0) {
                    Console.WriteLine("Interrupts while stepping:", this.step_into_interrupt ? "enabled" : "disabled");
                } else {
                    this.step_into_interrupt = Tuple.Create("1", "true", "yes", "on").Contains(args[0]);
                }
            }
            
            public virtual object handle_help(object args) {
                if (!args) {
                    this.list_commands();
                } else {
                    var cmd = args[0];
                    foreach (var _tup_1 in COMMAND_INFO) {
                        var name = _tup_1.Item1;
                        var info = _tup_1.Item2;
                        if (cmd == name || info["aliases"].Contains(cmd)) {
                            Console.WriteLine("Usage: {cmd} {args}".format(cmd: cmd, args: info["args"]));
                            if (info["aliases"].Count) {
                                Console.WriteLine("Aliases:", ", ".join(info["aliases"]));
                            }
                            Console.WriteLine(info["help"]);
                            if (info.has_key("extra_help")) {
                                Console.WriteLine(info["extra_help"]);
                            }
                        }
                    }
                }
            }
            
            public virtual object list_commands() {
                object info;
                var cmds = COMMAND_INFO.keys().OrderBy(_p_1 => _p_1).ToList();
                Console.WriteLine("Commands:\n---------");
                foreach (var cmd in cmds) {
                    info = COMMAND_INFO[cmd];
                    Console.WriteLine("{cmd:<25} {args:<20} {help}".format(cmd: ", ".join(new List<object> {
                        cmd
                    } + info["aliases"].OrderBy(_p_2 => _p_2).ToList()), info));
                }
                Console.WriteLine("\nInfo:\n---------");
                foreach (var name in INFO_HELP.keys().OrderBy(_p_3 => _p_3).ToList()) {
                    info = INFO_HELP[name];
                    Console.WriteLine("{name:<25} {help}".format(name: ", ".join(new List<object> {
                        name
                    } + info["aliases"].OrderBy(_p_4 => _p_4).ToList()), help: info["help"]));
                }
                Console.WriteLine("\nOptions:\n---------");
                foreach (var name in OPTION_HELP.keys().OrderBy(_p_5 => _p_5).ToList()) {
                    info = OPTION_HELP[name];
                    Console.WriteLine("{name:<25} {help}".format(name: ", ".join(new List<object> {
                        name
                    } + info["aliases"].OrderBy(_p_6 => _p_6).ToList()), help: info["help"]));
                }
                Console.WriteLine(@"
All register names are also available as commands that print the register's value.
Any ADDR or LEN argument will accept a register name.
Prefix line with $ to execute a Python expression.
Prefix line with ! to execute a shell command.");
            }
            
            public virtual object isFlashWrite(object addr, object width, object data) {
                var mem_map = this.board.target.getMemoryMap();
                var region = mem_map.getRegionForAddress(addr);
                if (region == null || !region.isFlash) {
                    return false;
                }
                if (width == 8) {
                    var l = data.Count;
                } else if (width == 16) {
                    l = data.Count * 2;
                } else if (width == 32) {
                    l = data.Count * 4;
                }
                return region.containsRange(addr, length: l);
            }
            
            //# @brief Convert an argument to a 32-bit integer.
            //
            // Handles the usual decimal, binary, and hex numbers with the appropriate prefix.
            // Also recognizes register names and address dereferencing. Dereferencing using the
            // ARM assembler syntax. To dereference, put the value in brackets, i.e. '[r0]' or
            // '[0x1040]'. You can also use put an offset in the brackets after a comma, such as
            // '[r3,8]'. The offset can be positive or negative, and any supported base.
            public virtual object convert_value(object arg) {
                object value;
                arg = arg.lower().replace("_", "");
                var deref = arg[0] == "[";
                if (deref) {
                    arg = arg[1:: - 1];
                    var offset = 0;
                    if (arg.Contains(",")) {
                        var _tup_1 = arg.split(",");
                        arg = _tup_1.Item1;
                        offset = _tup_1.Item2;
                        arg = arg.strip();
                        offset = Convert.ToInt32(offset.strip(), @base: 0);
                    }
                }
                if (pyOCD.coresight.cortex_m.CORE_REGISTER.Contains(arg)) {
                    value = this.target.readCoreRegister(arg);
                    Console.WriteLine(String.Format("%s = 0x%08x", arg, value));
                } else {
                    var subargs = arg.split(".");
                    if (this.peripherals.has_key(subargs[0]) && subargs.Count > 1) {
                        var p = this.peripherals[subargs[0]];
                        var r = p.registers.Where(x => x.name.lower() == subargs[1]);
                        if (r.Count) {
                            value = p.base_address + r[0].address_offset;
                        } else {
                            throw ToolError(String.Format("invalid register '%s' for %s", subargs[1], p.name));
                        }
                    } else {
                        value = Convert.ToInt32(arg, @base: 0);
                    }
                }
                if (deref) {
                    value = pyOCD.utility.conversion.byteListToU32leList(this.target.readBlockMemoryUnaligned8(value + offset, 4))[0];
                    Console.WriteLine(String.Format("[%s,%d] = 0x%08x", arg, offset, value));
                }
                return value;
            }
            
            public virtual object dump_registers() {
                // Registers organized into columns for display.
                var regs = new List<object> {
                    "r0",
                    "r6",
                    "r12",
                    "r1",
                    "r7",
                    "sp",
                    "r2",
                    "r8",
                    "lr",
                    "r3",
                    "r9",
                    "pc",
                    "r4",
                    "r10",
                    "xpsr",
                    "r5",
                    "r11",
                    "primask"
                };
                foreach (var _tup_1 in regs.Select((_p_1,_p_2) => Tuple.Create(_p_2, _p_1))) {
                    var i = _tup_1.Item1;
                    var reg = _tup_1.Item2;
                    var regValue = this.target.readCoreRegister(reg);
                    Console.WriteLine("{:>8} {:#010x} ".format(reg + ":", regValue));
                    if (i % 3 == 2) {
                        Console.WriteLine();
                    }
                }
            }
            
            public virtual object _dump_peripheral_register(object periph, object reg, object show_fields) {
                object f_value_enum_str;
                object bits_str;
                var addr = periph.base_address + reg.address_offset;
                var value = this.target.readMemory(addr, reg.size);
                var value_str = hex_width(value, reg.size);
                Console.WriteLine(String.Format("%s.%s @ %08x = %s", periph.name, reg.name, addr, value_str));
                if (show_fields) {
                    foreach (var f in reg.fields) {
                        if (f.is_reserved) {
                            continue;
                        }
                        var msb = f.bit_offset + f.bit_width - 1;
                        var lsb = f.bit_offset;
                        var f_value = mask.bfx(value, msb, lsb);
                        object v_enum = null;
                        if (f.enumerated_values) {
                            foreach (var v in f.enumerated_values) {
                                if (v.value == f_value) {
                                    v_enum = v;
                                    break;
                                }
                            }
                        }
                        if (f.bit_width == 1) {
                            bits_str = String.Format("%d", lsb);
                        } else {
                            bits_str = String.Format("%d:%d", msb, lsb);
                        }
                        var f_value_str = String.Format("%x", f_value);
                        var digits = (f.bit_width + 3) / 4;
                        f_value_str = "0" * (digits - f_value_str.Count) + f_value_str;
                        var f_value_bin_str = bin(f_value)[2];
                        f_value_bin_str = "0" * (f.bit_width - f_value_bin_str.Count) + f_value_bin_str;
                        if (v_enum) {
                            f_value_enum_str = String.Format(" %s: %s", v.name, v_enum.description);
                        } else {
                            f_value_enum_str = "";
                        }
                        Console.WriteLine(String.Format("  %s[%s] = %s (%s)%s", f.name, bits_str, f_value_str, f_value_bin_str, f_value_enum_str));
                    }
                }
            }
            
            public virtual object print_disasm(object code, object startAddr, object maxInstructions = null) {
                if (!isCapstoneAvailable) {
                    Console.WriteLine("Warning: Disassembly is not available because the Capstone library is not installed");
                    return;
                }
                var pc = this.target.readCoreRegister("pc") & ~1;
                var md = capstone.Cs(capstone.CS_ARCH_ARM, capstone.CS_MODE_THUMB);
                var addrLine = 0;
                var text = "";
                var n = 0;
                foreach (var i in md.disasm(code, startAddr)) {
                    var hexBytes = "";
                    foreach (var b in i.bytes) {
                        hexBytes += String.Format("%02x", b);
                    }
                    var pc_marker = pc == i.address ? "*" : " ";
                    text += "{addr:#010x}:{pc_marker} {bytes:<10}{mnemonic:<8}{args}\n".format(addr: i.address, pc_marker: pc_marker, bytes: hexBytes, mnemonic: i.mnemonic, args: i.op_str);
                    n += 1;
                    if (maxInstructions != null && n >= maxInstructions) {
                        break;
                    }
                }
                Console.WriteLine(text);
            }
        }
        
        public static object main() {
            sys.exit(PyOCDTool().run());
        }
    }
}
