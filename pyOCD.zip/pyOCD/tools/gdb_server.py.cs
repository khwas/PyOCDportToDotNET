namespace tools {
    
    using sys;
    
    using logging;
    
    using traceback;
    
    using argparse;
    
    using json;
    
    using pkg_resources;
    
    using pyOCD.board.mbed_board;
    
    using @@__version__ = @pyOCD.@@__version__;
    
    using isCmsisSvdAvailable = pyOCD.debug.svd.isCmsisSvdAvailable;
    
    using GDBServer = pyOCD.gdbserver.GDBServer;
    
    using MbedBoard = pyOCD.board.MbedBoard;
    
    using split_command_line = pyOCD.utility.cmdline.split_command_line;
    
    using VECTOR_CATCH_CHAR_MAP = pyOCD.utility.cmdline.VECTOR_CATCH_CHAR_MAP;
    
    using convert_vector_catch = pyOCD.utility.cmdline.convert_vector_catch;
    
    using DAPAccessCMSISDAP = pyOCD.pyDAPAccess.dap_access_cmsis_dap.DAPAccessCMSISDAP;
    
    using pyOCD.board.mbed_board;
    
    using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    
    using System.Collections.Generic;
    
    using System;
    
    public static class gdb_server {
        
        static gdb_server() {
            string license = @"
 mbed CMSIS-DAP debugger
 Copyright (c) 2006-2013 ARM Limited

 Licensed under the Apache License, Version 2.0 (the ""License"");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an ""AS IS"" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
";
            main();
        }
        
        public static object LEVELS = new Dictionary<object, object> {
            {
                "debug",
                logging.DEBUG},
            {
                "info",
                logging.INFO},
            {
                "warning",
                logging.WARNING},
            {
                "error",
                logging.ERROR},
            {
                "critical",
                logging.CRITICAL}};
        
        public static object supported_targets = pyOCD.target.TARGET.keys();
        
        public static object debug_levels = LEVELS.keys();
        
        public class InvalidArgumentError
            : RuntimeError {
        }
        
        //# @brief Argparse type function to validate the supplied target device name.
        //
        // If the target name is valid, it is returned unmodified to become the --target option's
        // attribute value.
        public static object validate_target(object value) {
            if (!supported_targets.Contains(value.lower())) {
                throw InvalidArgumentError("invalid target option '{}'".format(value));
            }
            return value;
        }
        
        public class GDBServerTool
            : object {
            
            public GDBServerTool() {
                this.args = null;
                this.gdb_server_settings = null;
                this.echo_msg = null;
            }
            
            public virtual object build_parser() {
                // Build epilog with list of targets.
                var epilog = "Available targets for use with --target option: " + ", ".join(supported_targets);
                // Keep args in snyc with flash_tool.py when possible
                var parser = argparse.ArgumentParser(description: "PyOCD GDB Server", epilog: epilog);
                parser.add_argument("--version", action: "version", version: @__version__);
                parser.add_argument("-p", "--port", dest: "port_number", type: @int, @default: 3333, help: "Write the port number that GDB server will open.");
                parser.add_argument("-T", "--telnet-port", dest: "telnet_port", type: @int, @default: 4444, help: "Specify the telnet port for semihosting.");
                parser.add_argument("--allow-remote", dest: "serve_local_only", @default: true, action: "store_false", help: "Allow remote TCP/IP connections (default is no).");
                parser.add_argument("-b", "--board", dest: "board_id", @default: null, help: "Connect to board by board id.  Use -l to list all connected boards.");
                parser.add_argument("-l", "--list", action: "store_true", dest: "list_all", @default: false, help: "List all connected boards.");
                parser.add_argument("--list-targets", action: "store_true", dest: "list_targets", @default: false, help: "List all available targets.");
                parser.add_argument("--json", action: "store_true", dest: "output_json", @default: false, help: "Output lists in JSON format. Only applies to --list and --list-targets.");
                parser.add_argument("-d", "--debug", dest: "debug_level", choices: debug_levels, @default: "info", help: "Set the level of system logging output. Supported choices are: " + ", ".join(debug_levels), metavar: "LEVEL");
                parser.add_argument("-t", "--target", dest: "target_override", @default: null, help: "Override target to debug.", metavar: "TARGET", type: validate_target);
                parser.add_argument("-n", "--nobreak", dest: "no_break_at_hardfault", action: "store_true", help: "Disable halt at hardfault handler. (Deprecated)");
                parser.add_argument("-r", "--reset-break", dest: "break_on_reset", action: "store_true", help: "Halt the target when reset. (Deprecated)");
                parser.add_argument("-C", "--vector-catch", @default: "h", help: "Enable vector catch sources, one letter per enabled source in any order, or 'all' or 'none'. (h=hard fault, b=bus fault, m=mem fault, i=irq err, s=state err, c=check err, p=nocp, r=reset, a=all, n=none). (Default is hard fault.)");
                parser.add_argument("-s", "--step-int", dest: "step_into_interrupt", @default: false, action: "store_true", help: "Allow single stepping to step into interrupts.");
                parser.add_argument("-f", "--frequency", dest: "frequency", @default: 1000000, type: @int, help: "Set the SWD clock frequency in Hz.");
                parser.add_argument("-o", "--persist", dest: "persist", @default: false, action: "store_true", help: "Keep GDB server running even after remote has detached.");
                parser.add_argument("-bh", "--soft-bkpt-as-hard", dest: "soft_bkpt_as_hard", @default: false, action: "store_true", help: "Replace software breakpoints with hardware breakpoints.");
                var group = parser.add_mutually_exclusive_group();
                group.add_argument("-ce", "--chip_erase", action: "store_true", help: "Use chip erase when programming.");
                group.add_argument("-se", "--sector_erase", action: "store_true", help: "Use sector erase when programming.");
                // -Currently "--unlock" does nothing since kinetis parts will automatically get unlocked
                parser.add_argument("-u", "--unlock", action: "store_true", @default: false, help: "Unlock the device.");
                // reserved: "-a", "--address"
                // reserved: "-s", "--skip"
                parser.add_argument("-hp", "--hide_progress", action: "store_true", help: "Don't display programming progress.");
                parser.add_argument("-fp", "--fast_program", action: "store_true", help: "Use only the CRC of each page to determine if it already has the same data.");
                parser.add_argument("-S", "--semihosting", dest: "enable_semihosting", action: "store_true", help: "Enable semihosting.");
                parser.add_argument("-G", "--gdb-syscall", dest: "semihost_use_syscalls", action: "store_true", help: "Use GDB syscalls for semihosting file I/O.");
                parser.add_argument("-c", "--command", dest: "commands", metavar: "CMD", action: "append", nargs: "+", help: "Run command (OpenOCD compatibility).");
                parser.add_argument("-da", "--daparg", dest: "daparg", nargs: "+", help: "Send setting to DAPAccess layer.");
                this.parser = parser;
                return parser;
            }
            
            public virtual object get_chip_erase(object args) {
                // Determine programming mode
                object chip_erase = null;
                if (args.chip_erase) {
                    chip_erase = true;
                } else if (args.sector_erase) {
                    chip_erase = false;
                }
                return chip_erase;
            }
            
            public virtual object get_vector_catch(object args) {
                var vector_catch = args.vector_catch.lower();
                // Handle deprecated options.
                if (args.break_on_reset) {
                    vector_catch += "r";
                }
                if (args.no_break_at_hardfault) {
                    // Must handle all case specially since we can't just filter 'h'.
                    if (vector_catch == "all" || vector_catch.Contains("a")) {
                        vector_catch = "bmiscpr";
                    } else {
                        vector_catch = vector_catch.replace("h", "");
                    }
                }
                try {
                    return convert_vector_catch(vector_catch);
                } catch (ValueError) {
                    // Reraise as an invalid argument error.
                    throw InvalidArgumentError(e.message);
                }
            }
            
            public virtual object get_gdb_server_settings(object args) {
                // Set gdb server settings
                return new Dictionary<object, object> {
                    {
                        "step_into_interrupt",
                        args.step_into_interrupt},
                    {
                        "persist",
                        args.persist},
                    {
                        "soft_bkpt_as_hard",
                        args.soft_bkpt_as_hard},
                    {
                        "chip_erase",
                        this.get_chip_erase(args)},
                    {
                        "hide_programming_progress",
                        args.hide_progress},
                    {
                        "fast_program",
                        args.fast_program},
                    {
                        "server_listening_callback",
                        this.server_listening},
                    {
                        "enable_semihosting",
                        args.enable_semihosting},
                    {
                        "telnet_port",
                        args.telnet_port},
                    {
                        "semihost_use_syscalls",
                        args.semihost_use_syscalls},
                    {
                        "serve_local_only",
                        args.serve_local_only},
                    {
                        "vector_catch",
                        this.get_vector_catch(args)}};
            }
            
            public virtual object setup_logging(object args) {
                var format = "%(relativeCreated)07d:%(levelname)s:%(module)s:%(message)s";
                var level = LEVELS.get(args.debug_level, logging.NOTSET);
                logging.basicConfig(level: level, format: format);
            }
            
            //# @brief Handle OpenOCD commands for compatibility.
            public virtual object process_commands(object commands) {
                if (commands == null) {
                    return;
                }
                foreach (var cmd_list in commands) {
                    try {
                        var cmd_list = split_command_line(cmd_list);
                        var cmd = cmd_list[0];
                        if (cmd == "gdb_port") {
                            if (cmd_list.Count < 2) {
                                Console.WriteLine("Missing port argument");
                            } else {
                                this.args.port_number = Convert.ToInt32(cmd_list[1], @base: 0);
                            }
                        } else if (cmd == "telnet_port") {
                            if (cmd_list.Count < 2) {
                                Console.WriteLine("Missing port argument");
                            } else {
                                this.gdb_server_settings["telnet_port"] = Convert.ToInt32(cmd_list[1], @base: 0);
                            }
                        } else if (cmd == "echo") {
                            this.echo_msg = " ".join(cmd_list[1]);
                        } else {
                            Console.WriteLine(String.Format("Unsupported command: %s", " ".join(cmd_list)));
                        }
                    } catch (IndexError) {
                    }
                }
            }
            
            public virtual object server_listening(object server) {
                if (this.echo_msg != null) {
                    sys.stderr.WriteLine(this.echo_msg);
                    sys.stderr.flush();
                }
            }
            
            public virtual object disable_logging() {
                logging.getLogger().setLevel(logging.FATAL);
            }
            
            public virtual object list_boards() {
                object error;
                object status;
                object all_mbeds;
                this.disable_logging();
                try {
                    all_mbeds = MbedBoard.getAllConnectedBoards(close: true, blocking: false);
                    status = 0;
                    error = "";
                } catch (Exception) {
                    all_mbeds = new List<object>();
                    status = 1;
                    error = str(e);
                    if (!this.args.output_json) {
                        throw;
                    }
                }
                if (this.args.output_json) {
                    var boards = new List<object>();
                    var obj = new Dictionary<object, object> {
                        {
                            "pyocd_version",
                            @__version__},
                        {
                            "version",
                            new Dictionary<object, object> {
                                {
                                    "major",
                                    1},
                                {
                                    "minor",
                                    0}}},
                        {
                            "status",
                            status},
                        {
                            "boards",
                            boards}};
                    if (status != 0) {
                        obj["error"] = error;
                    }
                    foreach (var mbed in all_mbeds) {
                        var d = new Dictionary<object, object> {
                            {
                                "unique_id",
                                mbed.unique_id},
                            {
                                "info",
                                mbed.getInfo()},
                            {
                                "board_name",
                                mbed.getBoardName()},
                            {
                                "target",
                                mbed.getTargetType()},
                            {
                                "vendor_name",
                                ""},
                            {
                                "product_name",
                                ""}};
                        // Reopen the link so we can access the USB vendor and product names from the inteface.
                        // If it's not a USB based link, then we don't attempt this.
                        if (mbed.link is DAPAccessCMSISDAP) {
                            try {
                                mbed.link.open();
                                d["vendor_name"] = mbed.link._interface.vendor_name;
                                d["product_name"] = mbed.link._interface.product_name;
                                mbed.link.close();
                            } catch (Exception) {
                            }
                        }
                        boards.append(d);
                    }
                    Console.WriteLine(json.dumps(obj, indent: 4));
                } else {
                    var index = 0;
                    if (all_mbeds.Count > 0) {
                        foreach (var mbed in all_mbeds) {
                            Console.WriteLine(String.Format("%d => %s boardId => %s", index, mbed.getInfo().encode("ascii", "ignore"), mbed.unique_id));
                            index += 1;
                        }
                    } else {
                        Console.WriteLine("No available boards are connected");
                    }
                }
            }
            
            public virtual object list_targets() {
                this.disable_logging();
                if (this.args.output_json) {
                    var targets = new List<object>();
                    var obj = new Dictionary<object, object> {
                        {
                            "pyocd_version",
                            @__version__},
                        {
                            "version",
                            new Dictionary<object, object> {
                                {
                                    "major",
                                    1},
                                {
                                    "minor",
                                    0}}},
                        {
                            "status",
                            0},
                        {
                            "targets",
                            targets}};
                    foreach (var name in supported_targets) {
                        var t = pyOCD.target.TARGET[name](null);
                        var d = new Dictionary<object, object> {
                            {
                                "name",
                                name},
                            {
                                "part_number",
                                t.part_number}};
                        if (t._svd_location != null && isCmsisSvdAvailable) {
                            if (t._svd_location.is_local) {
                                d["svd_path"] = t._svd_location.filename;
                            } else {
                                var resource = "data/{vendor}/{filename}".format(vendor: t._svd_location.vendor, filename: t._svd_location.filename);
                                d["svd_path"] = pkg_resources.resource_filename("cmsis_svd", resource);
                            }
                        }
                        targets.append(d);
                    }
                    Console.WriteLine(json.dumps(obj, indent: 4));
                } else {
                    foreach (var t in supported_targets) {
                        Console.WriteLine(t);
                    }
                }
            }
            
            public virtual object run(object args = null) {
                try {
                    this.args = this.build_parser().parse_args(args);
                    this.gdb_server_settings = this.get_gdb_server_settings(this.args);
                    this.setup_logging(this.args);
                    DAPAccess.set_args(this.args.daparg);
                    this.process_commands(this.args.commands);
                    object gdb = null;
                    if (this.args.list_all == true) {
                        this.list_boards();
                    } else if (this.args.list_targets == true) {
                        this.list_targets();
                    } else {
                        try {
                            var board_selected = MbedBoard.chooseBoard(board_id: this.args.board_id, target_override: this.args.target_override, frequency: this.args.frequency);
                            using (var board = board_selected) {
                                gdb = GDBServer(board, this.args.port_number, this.gdb_server_settings);
                                while (gdb.isAlive()) {
                                    gdb.join(timeout: 0.5);
                                }
                            }
                        } catch (KeyboardInterrupt) {
                            if (gdb != null) {
                                gdb.stop();
                            }
                        } catch (Exception) {
                            Console.WriteLine(String.Format("uncaught exception: %s", e));
                            traceback.print_exc();
                            if (gdb != null) {
                                gdb.stop();
                            }
                            return 1;
                        }
                    }
                    // Successful exit.
                    return 0;
                } catch (InvalidArgumentError) {
                    this.parser.error(e);
                    return 1;
                }
            }
        }
        
        public static object main() {
            sys.exit(GDBServerTool().run());
        }
    }
}
