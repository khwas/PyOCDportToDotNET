namespace tools {
    
    using argparse;
    
    using os;
    
    using sys;
    
    using logging;
    
    using itertools;
    
    using unpack = @struct.unpack;
    
    using IntelHex = intelhex.IntelHex;
    
    using pyOCD;
    
    using @@__version__ = @pyOCD.@@__version__;
    
    using MbedBoard = pyOCD.board.MbedBoard;
    
    using DAPAccess = pyOCD.pyDAPAccess.DAPAccess;
    
    using System.Collections.Generic;
    
    using System;
    
    using System.Linq;
    
    public static class flash_tool {
        
        static flash_tool() {
            @"
 mbed CMSIS-DAP debugger
 Copyright (c) 2006-2015 ARM Limited

 Licensed under the Apache License, Version 2.0 (the ""License"");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an ""AS IS"" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
";
            supported_targets.remove("cortex_m");
            parser.add_argument("file", nargs: "?", @default: null, help: "File to program");
            parser.add_argument("format", nargs: "?", choices: supported_formats, @default: null, help: "File format. Default is to use the file extension (.bin or .hex)");
            parser.add_argument("--version", action: "version", version: @__version__);
            parser.add_argument("-b", "--board", dest: "board_id", @default: null, help: "Connect to board by board id.  Use -l to list all connected boards.");
            parser.add_argument("-l", "--list", action: "store_true", dest: "list_all", @default: false, help: "List all connected boards.");
            parser.add_argument("-d", "--debug", dest: "debug_level", choices: debug_levels, @default: "info", help: "Set the level of system logging output. Supported choices are: " + ", ".join(debug_levels), metavar: "LEVEL");
            parser.add_argument("-t", "--target", dest: "target_override", choices: supported_targets, @default: null, help: "Override target to debug.  Supported targets are: " + ", ".join(supported_targets), metavar: "TARGET");
            parser.add_argument("-f", "--frequency", dest: "frequency", @default: 1000000, type: @int, help: "Set the SWD clock frequency in Hz.");
            group.add_argument("-ce", "--chip_erase", action: "store_true", help: "Use chip erase when programming.");
            group.add_argument("-se", "--sector_erase", action: "store_true", help: "Use sector erase when programming.");
            parser.add_argument("-u", "--unlock", action: "store_true", @default: false, help: "Unlock the device.");
            parser.add_argument("-a", "--address", @default: null, type: int_base_0, help: "Address. Used for the sector address with sector erase, and for the address where to flash a binary.");
            parser.add_argument("-n", "--count", @default: 1, type: int_base_0, help: "Number of sectors to erase. Only applies to sector erase. Default is 1.");
            parser.add_argument("-s", "--skip", @default: 0, type: int_base_0, help: "Skip programming the first N bytes.  This can only be used with binary files");
            parser.add_argument("-hp", "--hide_progress", action: "store_true", help: "Don't display programming progress.");
            parser.add_argument("-fp", "--fast_program", action: "store_true", help: "Use only the CRC of each page to determine if it already has the same data.");
            parser.add_argument("-da", "--daparg", dest: "daparg", nargs: "+", help: "Send setting to DAPAccess layer.");
            parser.add_argument("--mass-erase", action: "store_true", help: "Mass erase the target device.");
            main();
        }
        
        public static object intelhex_available = true;
        
        public static object intelhex_available = false;
        
        public static object LEVELS = new Dictionary<object, object> {
            {
                "debug",
                logging.DEBUG},
            {
                "info",
                logging.INFO},
            {
                "warning",
                logging.WARNING},
            {
                "error",
                logging.ERROR},
            {
                "critical",
                logging.CRITICAL}};
        
        public static object board = null;
        
        public static object supported_formats = new List<object> {
            "bin",
            "hex"
        };
        
        public static object supported_targets = pyOCD.target.TARGET.keys();
        
        public static object debug_levels = LEVELS.keys();
        
        public static object int_base_0(object x) {
            return Convert.ToInt32(x, @base: 0);
        }
        
        public static object epi = @"--chip_erase and --sector_erase can be used alone as individual commands, or they
can be used in conjunction with flashing a binary or hex file. For the former, only the erase option
will be performed. With a file, the erase options specify whether to erase the entire chip before
flashing the file, or just to erase only those sectors occupied by the file. For a standalone
sector erase, the --address and --count options are used to specify the start address of the
sector to erase and the number of sectors to erase.
";
        
        public static object parser = argparse.ArgumentParser(description: "Flash utility", epilog: epi);
        
        public static object group = parser.add_mutually_exclusive_group();
        
        // Notes
        // -Currently "--unlock" does nothing since kinetis parts will automatically get unlocked
        public static object setup_logging(object args) {
            // Set logging level
            var level = LEVELS.get(args.debug_level, logging.NOTSET);
            logging.basicConfig(level: level);
        }
        
        public static object ranges(object i) {
            foreach (var _tup_1 in itertools.groupby(i.Select((_p_1,_p_2) => Tuple.Create(_p_2, _p_1)), Tuple.Create(x, y) => y - x)) {
                var a = _tup_1.Item1;
                var b = _tup_1.Item2;
                b = b.ToList();
                yield return Tuple.Create(b[0][1], b[-1][1]);
            }
        }
        
        public static object print_progress(object progress) {
            // Reset state on 0.0
            if (progress == 0.0) {
                print_progress.done = false;
            }
            // print progress bar
            if (!print_progress.done) {
                sys.stdout.write("\r");
                var i = Convert.ToInt32(progress * 20.0);
                sys.stdout.write(String.Format("[%-20s] %3d%%", "=" * i, round(progress * 100)));
                sys.stdout.flush();
            }
            // Finish on 1.0
            if (progress >= 1.0) {
                if (!print_progress.done) {
                    print_progress.done = true;
                    sys.stdout.write("\n");
                }
            }
        }
        
        public static object main() {
            var args = parser.parse_args();
            setup_logging(args);
            DAPAccess.set_args(args.daparg);
            // Sanity checks before attaching to board
            if (args.format == "hex" && !intelhex_available) {
                Console.WriteLine("Unable to program hex file");
                Console.WriteLine("Module 'intelhex' must be installed first");
                exit();
            }
            if (args.list_all) {
                MbedBoard.listConnectedBoards();
            } else {
                var board_selected = MbedBoard.chooseBoard(board_id: args.board_id, target_override: args.target_override, frequency: args.frequency, blocking: false);
                if (board_selected == null) {
                    Console.WriteLine("Error: There is no board connected.");
                    sys.exit(1);
                }
                using (var board = board_selected) {
                    flash = board.flash;
                    link = board.link;
                    progress = print_progress;
                    if (args.hide_progress) {
                        progress = null;
                    }
                    has_file = args.file != null;
                    chip_erase = null;
                    if (args.chip_erase) {
                        chip_erase = true;
                    } else if (args.sector_erase) {
                        chip_erase = false;
                    }
                    if (args.mass_erase) {
                        Console.WriteLine("Mass erasing device...");
                        if (board.target.massErase()) {
                            Console.WriteLine("Successfully erased.");
                        } else {
                            Console.WriteLine("Failed.");
                        }
                        return;
                    }
                    if (!has_file) {
                        if (chip_erase) {
                            Console.WriteLine("Erasing chip...");
                            flash.init();
                            flash.eraseAll();
                            Console.WriteLine("Done");
                        } else if (args.sector_erase && args.address != null) {
                            flash.init();
                            page_addr = args.address;
                            foreach (var i in range(args.count)) {
                                page_info = flash.getPageInfo(page_addr);
                                if (!page_info) {
                                    break;
                                }
                                // Align page address on first time through.
                                if (i == 0) {
                                    delta = page_addr % page_info.size;
                                    if (delta) {
                                        Console.WriteLine(String.Format("Warning: sector address 0x%08x is unaligned", page_addr));
                                        page_addr -= delta;
                                    }
                                }
                                Console.WriteLine(String.Format("Erasing sector 0x%08x", page_addr));
                                flash.erasePage(page_addr);
                                page_addr += page_info.size;
                            }
                        } else {
                            Console.WriteLine("No operation performed");
                        }
                        return;
                    }
                    // If no format provided, use the file's extension.
                    if (!args.format) {
                        args.format = os.path.splitext(args.file)[1][1];
                    }
                    // Binary file format
                    if (args.format == "bin") {
                        // If no address is specified use the start of rom
                        if (args.address == null) {
                            args.address = board.flash.getFlashInfo().rom_start;
                        }
                        using (var f = open(args.file, "rb")) {
                            f.seek(args.skip, 0);
                            data = f.read();
                        }
                        args.address += args.skip;
                        data = unpack(str(data.Count) + "B", data);
                        flash.flashBlock(args.address, data, chip_erase: chip_erase, progress_cb: progress, fast_verify: args.fast_program);
                    } else if (args.format == "hex") {
                        // Intel hex file format
                        hex = IntelHex(args.file);
                        addresses = hex.addresses();
                        addresses.sort();
                        flash_builder = flash.getFlashBuilder();
                        data_list = ranges(addresses).ToList();
                        foreach (var _tup_1 in data_list) {
                            start = _tup_1.Item1;
                            end = _tup_1.Item2;
                            size = end - start + 1;
                            data = hex.tobinarray(start: start, size: size).ToList();
                            flash_builder.addData(start, data);
                        }
                        flash_builder.program(chip_erase: chip_erase, progress_cb: progress, fast_verify: args.fast_program);
                    } else {
                        Console.WriteLine(String.Format("Unknown file format '%s'", args.format));
                    }
                }
            }
        }
    }
}
